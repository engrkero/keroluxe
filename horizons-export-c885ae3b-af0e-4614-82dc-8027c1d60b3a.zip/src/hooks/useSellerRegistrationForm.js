import { useState, useRef } from 'react';
    import { useToast } from '@/components/ui/use-toast';

    const useSellerRegistrationForm = () => {
      const { toast } = useToast();
      const videoRef = useRef(null);
      const canvasRef = useRef(null);

      const [step, setStep] = useState(1);
      const [formData, setFormData] = useState({
        email: '', password: '', confirmPassword: '',
        storeName: '', storeDescription: '', contactPhone: '',
        bankName: 'Moniepoint MFB', accountNumber: '', accountName: '',
        ninNumber: '', ninFrontFile: null, ninBackFile: null,
        bvnNumber: '', passportPhotoFile: null, cacFile: null,
        facialVerificationPhoto: null,
      });
      const [filePreviews, setFilePreviews] = useState({
        ninFrontFile: null, ninBackFile: null, passportPhotoFile: null, cacFile: null, facialVerificationPhoto: null
      });
      const [isCameraOn, setIsCameraOn] = useState(false);

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
      };

      const handleFileChange = (e) => {
        const { name, files } = e.target;
        if (files[0]) {
          setFormData(prev => ({ ...prev, [name]: files[0] }));
          setFilePreviews(prev => ({...prev, [name]: URL.createObjectURL(files[0])}));
          toast({ title: "File Selected", description: `${files[0].name} ready.`});
        }
      };
      
      const startCamera = async () => {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 320, height: 240 }, audio: false });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            setIsCameraOn(true);
            console.log("Function Tracking: Camera started for facial verification");
          }
        } catch (err) {
          console.error("Error accessing camera:", err);
          toast({ title: "Camera Error", description: "Could not access camera. Please ensure permissions are granted.", variant: "destructive"});
          setIsCameraOn(false);
        }
      };

      const capturePhoto = () => {
        if (videoRef.current && canvasRef.current) {
          const video = videoRef.current;
          const canvas = canvasRef.current;
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          const context = canvas.getContext('2d');
          context.drawImage(video, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/png');
          
          fetch(dataUrl)
            .then(res => res.blob())
            .then(blob => {
              const file = new File([blob], "facial_verification.png", { type: "image/png" });
              setFormData(prev => ({ ...prev, facialVerificationPhoto: file }));
              setFilePreviews(prev => ({...prev, facialVerificationPhoto: dataUrl }));
              console.log("Function Tracking: Facial verification photo captured");
            });
          
          stopCamera();
        }
      };
      
      const stopCamera = () => {
        if (videoRef.current && videoRef.current.srcObject) {
          videoRef.current.srcObject.getTracks().forEach(track => track.stop());
        }
        setIsCameraOn(false);
        console.log("Function Tracking: Camera stopped");
      };

      const validateCurrentStep = () => {
        if (step === 1) { 
          if (!formData.email || !formData.password || !formData.confirmPassword) {
            toast({ title: "Missing Fields", description: "Please fill all account fields.", variant: "destructive" }); return false;
          }
          if (formData.password.length < 6) {
             toast({ title: "Weak Password", description: "Password must be at least 6 characters.", variant: "destructive" }); return false;
          }
          if (formData.password !== formData.confirmPassword) {
            toast({ title: "Password Mismatch", description: "Passwords do not match.", variant: "destructive" }); return false;
          }
        }
        if (step === 2) { 
           if (!formData.storeName || !formData.contactPhone) {
            toast({ title: "Missing Fields", description: "Please fill store name and contact phone.", variant: "destructive" }); return false;
          }
        }
         if (step === 3) { 
           if (!formData.accountNumber || !formData.accountName) {
            toast({ title: "Missing Fields", description: "Please fill all banking details.", variant: "destructive" }); return false;
          }
        }
        return true;
      };

      const nextStep = () => {
        if (validateCurrentStep()) {
          setStep(prev => prev + 1);
          console.log(`Function Tracking: Seller registration moved to step ${step + 1}`);
        }
      };
      const prevStep = () => {
        setStep(prev => prev - 1);
        console.log(`Function Tracking: Seller registration moved back to step ${step - 1}`);
      };

      return {
        step,
        formData,
        filePreviews,
        isCameraOn,
        videoRef,
        canvasRef,
        handleInputChange,
        handleFileChange,
        startCamera,
        capturePhoto,
        stopCamera,
        nextStep,
        prevStep,
        setFormData, 
        setFilePreviews,
      };
    };

    export default useSellerRegistrationForm;