import { useState, useEffect } from 'react';

    // Modified to accept authLoading state
    const useGlobalLoading = (location, session, authLoading) => {
      const [isLoading, setIsLoading] = useState(true);
      const [initialAuthCheckDone, setInitialAuthCheckDone] = useState(false);

      useEffect(() => {
        // This effect tracks when the initial auth check (session load and profile fetch) is complete.
        if (!authLoading && !initialAuthCheckDone) {
          setInitialAuthCheckDone(true);
        }
      }, [authLoading, initialAuthCheckDone]);
    
      useEffect(() => {
        // Only start showing page transition loading *after* the initial auth state is resolved.
        if (!initialAuthCheckDone) {
          setIsLoading(true); // Keep loading true until initial auth is done
          return;
        }
    
        setIsLoading(true); // Start loading for page transition
        const timer = setTimeout(() => {
          setIsLoading(false); // Stop loading after a short delay
        }, 300); // Adjust delay as needed
    
        return () => clearTimeout(timer);
      }, [location.pathname, initialAuthCheckDone]); // Depend on location and initialAuthCheckDone
    
      return { isLoading, setIsLoading };
    };

    export default useGlobalLoading;