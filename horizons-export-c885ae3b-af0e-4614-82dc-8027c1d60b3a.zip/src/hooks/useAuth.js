import { useState, useEffect, useCallback } from 'react';

    const useAuth = (supabase, toast, navigate) => {
      const [session, setSession] = useState(null);
      const [userProfile, setUserProfile] = useState(null);
      const [isLoadingAuth, setIsLoadingAuth] = useState(true); // Changed from isLoading

      const fetchUserProfile = useCallback(async (userId) => {
        if (!userId) {
          setUserProfile(null);
          setIsLoadingAuth(false);
          return null;
        }
        setIsLoadingAuth(true);
        try {
            const { data, error } = await supabase
              .from('profiles')
              .select('*')
              .eq('id', userId)
              .single();
            
            if (error && error.code !== 'PGRST116') { // PGRST116: "Actual row count of 0 rows does not match LIMIT 1." (means profile not found)
              console.error('Error fetching user profile:', error);
              toast({ title: "Error fetching profile", description: error.message, variant: "destructive"});
              setUserProfile(null);
            } else {
              setUserProfile(data); // data will be null if not found, which is fine
            }
            return data;
        } catch (e) {
            console.error('Exception fetching user profile:', e);
            toast({ title: "Error fetching profile", description: "An unexpected error occurred.", variant: "destructive"});
            setUserProfile(null);
            return null;
        } finally {
            setIsLoadingAuth(false);
        }
      }, [supabase, toast]);

      useEffect(() => {
        setIsLoadingAuth(true);
        const getSessionAndProfile = async () => {
          const { data: { session: currentSession } } = await supabase.auth.getSession();
          setSession(currentSession);
          if (currentSession?.user) {
            await fetchUserProfile(currentSession.user.id);
          } else {
            setUserProfile(null); // No user, so no profile
            setIsLoadingAuth(false); // Explicitly set loading to false
          }
        };
        getSessionAndProfile();

        const { data: { subscription: authListener } } = supabase.auth.onAuthStateChange(
          async (_event, newSession) => {
            setIsLoadingAuth(true);
            setSession(newSession);
            if (newSession?.user) {
              await fetchUserProfile(newSession.user.id);
            } else {
              setUserProfile(null);
              setIsLoadingAuth(false); // Explicitly set loading to false if no new session/user
            }
          }
        );
        return () => {
          authListener?.unsubscribe();
        };
      }, [supabase, fetchUserProfile]);


      const login = async (email, password) => {
        setIsLoadingAuth(true);
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        
        if (error) {
          toast({ title: "Login Failed", description: error.message, variant: "destructive" });
          setIsLoadingAuth(false);
          return false;
        }

        // Session change will trigger onAuthStateChange, which handles profile fetching and sets isLoadingAuth
        // So, we don't need to call fetchUserProfile or setIsLoadingAuth(false) here explicitly for the success case.
        // Navigation logic will be based on the updated userProfile from onAuthStateChange.

        if (data.user) {
            // The onAuthStateChange listener will handle fetching profile and setting loading states
            // For immediate navigation, we might still need to fetch profile here if onAuthStateChange is too slow for UI needs
            // However, to avoid duplicate fetches and ensure consistent state, relying on onAuthStateChange is better.
            // The navigation logic will then use the updated userProfile.
            // We can temporarily fetch here for navigation purposes and let onAuthStateChange reconcile state.
            const profile = await fetchUserProfile(data.user.id); // Re-fetch for immediate role check for navigation
            setIsLoadingAuth(false); // Make sure loading is false after this direct fetch
            if (profile?.role === 'admin') {
                navigate('/admin/dashboard');
                toast({ title: "Admin Login Successful!", description: "Welcome back, Admin!", className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold"});
            } else if (profile?.role === 'seller') {
                navigate('/seller/dashboard');
                toast({ title: "Seller Login Successful!", description: "Welcome to your dashboard!", className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold"});
            } else {
                navigate('/');
                toast({ title: "Login Successful!", description: `Welcome back!`, className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold"});
            }
            return true;
        }
        setIsLoadingAuth(false); // If no data.user for some reason
        return false;
      };

      const signUp = async (email, password, metadata = { role: 'user', username: email.split('@')[0] }) => {
        setIsLoadingAuth(true);
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: metadata 
          }
        });
        setIsLoadingAuth(false);
        if (error) {
          toast({ title: "Sign Up Failed", description: error.message, variant: "destructive" });
          return null;
        }
        if (data.user) {
           toast({ title: "Sign Up Successful!", description: "Please check your email to confirm your account.", className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold"});
        }
        return data.user;
      };
      
      const logout = async () => {
        setIsLoadingAuth(true);
        const { error } = await supabase.auth.signOut();
        setIsLoadingAuth(false);
        if (error) {
          toast({ title: "Logout Failed", description: error.message, variant: "destructive" });
        } else {
          setSession(null);
          setUserProfile(null);
          toast({ title: "Logged out successfully." });
          navigate('/');
        }
      };
      
      const isAdminAuthenticated = !!session?.user && userProfile?.role === 'admin';
      const isSellerAuthenticated = !!session?.user && userProfile?.role === 'seller';
      const isAuthenticated = !!session?.user;

      return {
        session,
        user: session?.user,
        userProfile,
        isLoadingAuth, // Use this specific loading state
        isAdminAuthenticated,
        isSellerAuthenticated,
        isAuthenticated,
        login,
        signUp,
        logout,
        fetchUserProfile,
      };
    };

    export default useAuth;
