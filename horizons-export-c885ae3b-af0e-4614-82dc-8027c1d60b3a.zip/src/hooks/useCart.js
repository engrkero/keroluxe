import { useState, useEffect } from 'react';

    const useCart = (toast) => {
      const [cart, setCart] = useState(() => {
        const localCart = localStorage.getItem('keroluxeCart');
        return localCart ? JSON.parse(localCart) : [];
      });

      useEffect(() => {
        localStorage.setItem('keroluxeCart', JSON.stringify(cart));
      }, [cart]);

      const addToCart = (product, quantity = 1, selectedSize = null, selectedColor = null) => {
        setCart(prevCart => {
          // Try to find an item with the same ID, size, and color
          const existingProductIndex = prevCart.findIndex(item => 
            item.id === product.id && 
            item.selectedSize === selectedSize && 
            item.selectedColor === selectedColor
          );

          if (existingProductIndex > -1) {
            // If found, update its quantity
            const updatedCart = [...prevCart];
            updatedCart[existingProductIndex].quantity += quantity;
            return updatedCart;
          } else {
            // If not found, add as a new item
            return [...prevCart, { ...product, quantity, selectedSize, selectedColor }];
          }
        });
        toast({
          title: `${product.name} added to cart!`,
          description: `Quantity: ${quantity}${selectedSize ? `, Size: ${selectedSize}` : ''}${selectedColor ? `, Color: ${selectedColor}` : ''}`,
          className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold",
        });
      };

      const removeFromCart = (productId, size, color) => {
        setCart(prevCart => prevCart.filter(item => 
            !(item.id === productId && item.selectedSize === size && item.selectedColor === color)
        ));
      };

      const updateCartQuantity = (productId, size, color, newQuantity) => {
        const numQuantity = Number(newQuantity);
        if (isNaN(numQuantity) || numQuantity < 0) {
          console.error("Invalid quantity:", newQuantity);
          toast({title: "Invalid Quantity", description: "Quantity must be a positive number.", variant: "destructive"});
          return; // Do nothing if newQuantity is not a valid positive number
        }

        if (numQuantity === 0) {
          removeFromCart(productId, size, color);
        } else {
          setCart(prevCart =>
            prevCart.map(item =>
              (item.id === productId && item.selectedSize === size && item.selectedColor === color)
                ? { ...item, quantity: numQuantity }
                : item
            )
          );
        }
      };
      
      const clearCart = () => {
        setCart([]);
      };

      return {
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
      };
    };

    export default useCart;