import { useState, useEffect } from 'react';

    const useWishlist = (toast) => {
      const [wishlist, setWishlist] = useState(() => {
        const localWishlist = localStorage.getItem('keroluxeWishlist');
        return localWishlist ? JSON.parse(localWishlist) : [];
      });

      useEffect(() => {
        localStorage.setItem('keroluxeWishlist', JSON.stringify(wishlist));
      }, [wishlist]);

      const addToWishlist = (product) => {
        setWishlist(prevWishlist => {
          if (prevWishlist.find(item => item.id === product.id)) {
            toast({ title: `${product.name} is already in your wishlist.`, variant: "default" });
            return prevWishlist;
          }
          toast({ title: `${product.name} added to wishlist!`, className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold" });
          return [...prevWishlist, product];
        });
      };

      const removeFromWishlist = (productId) => {
        setWishlist(prevWishlist => prevWishlist.filter(item => item.id !== productId));
        toast({ title: "Item removed from wishlist", variant: "destructive" });
      };
      
      const clearWishlist = () => {
        setWishlist([]);
      }

      return {
        wishlist,
        addToWishlist,
        removeFromWishlist,
        clearWishlist,
      };
    };

    export default useWishlist;