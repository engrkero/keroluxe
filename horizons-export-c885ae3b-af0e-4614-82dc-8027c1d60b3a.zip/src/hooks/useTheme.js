import { useState, useEffect } from 'react';

    const useTheme = () => {
      const [theme, setTheme] = useState(() => {
        const localTheme = localStorage.getItem('keroluxeTheme') || 'light';
        if (localTheme === 'dark') {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
        return localTheme;
      });

      useEffect(() => {
        localStorage.setItem('keroluxeTheme', theme);
        if (theme === 'dark') {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }, [theme]);

      const toggleTheme = () => {
        setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light');
      };

      return {
        theme,
        toggleTheme,
      };
    };

    export default useTheme;