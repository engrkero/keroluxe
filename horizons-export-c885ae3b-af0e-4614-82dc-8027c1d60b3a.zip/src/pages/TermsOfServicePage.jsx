import React from 'react';
    import { motion } from 'framer-motion';
    import { FileText, Gavel, UserCheck, ShoppingBag, Users } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

    const TermsOfServicePage = () => {
      const sections = [
        {
          title: "1. Agreement to Terms",
          icon: <FileText className="h-8 w-8 text-keroluxe-gold" />,
          content: "By accessing or using our website and services ('Service'), you agree to be bound by these Terms of Service ('Terms') and our Privacy Policy. These Terms apply to all visitors, users (buyers), sellers, and others who wish to access or use the Service. If you sell items on KeroLuxe, additional Seller Terms may apply."
        },
        {
          title: "2. Use of Our Service",
          icon: <UserCheck className="h-8 w-8 text-keroluxe-gold" />,
          content: (
            <>
              <p className="mb-2">KeroLuxe provides an online platform for selling and buying clothing (stock and bale/foreign used), watches, fragrances/perfumes, and other fashion items. KeroLuxe itself sells items and also facilitates sales for third-party sellers.</p>
              <p className="mb-2">You agree not to use the Service:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>In any way that violates any applicable national or international law or regulation.</li>
                <li>To engage in fraudulent activities, including misrepresenting items or failing to deliver purchased goods.</li>
                <li>To infringe upon the intellectual property rights of others.</li>
                <li>To transmit, or procure the sending of, any advertising or promotional material not authorized by KeroLuxe.</li>
                <li>To impersonate or attempt to impersonate KeroLuxe, a KeroLuxe employee, another user, or any other person or entity.</li>
              </ul>
            </>
          )
        },
        {
          title: "3. Accounts",
          content: "When you create an account with us, you guarantee that you are above the age of 18 and that the information you provide is accurate, complete, and current. You are responsible for maintaining the confidentiality of your account and password. Sellers are subject to additional verification processes."
        },
        {
          title: "4. Purchases & Sales",
          icon: <ShoppingBag className="h-8 w-8 text-keroluxe-gold" />,
          content: (
            <>
            <p className="mb-2">Buyers: If you wish to purchase any product, you may be asked to supply payment and shipping information. You represent that you have the legal right to use any payment method(s) utilized.</p>
            <p className="mb-2">Sellers: By listing items on KeroLuxe, you agree to accurately describe your products, fulfill orders promptly, and adhere to KeroLuxe's quality and pricing guidelines. KeroLuxe charges a commission (e.g., 5% of profit margin) on sales made by third-party sellers. Payouts are typically made weekly to your registered Moniepoint account, after deduction of KeroLuxe's commission. KeroLuxe reserves the right to approve or reject seller applications and product listings.</p>
            </>
          )
        },
        {
          title: "5. Content and Intellectual Property",
          content: "The Service and its original content (excluding Content provided by users/sellers), features, and functionality are and will remain the exclusive property of KeroLuxe. Sellers grant KeroLuxe a license to use the content they upload (e.g., product images, descriptions) for the purpose of promoting and operating the Service."
        },
         {
          title: "6. Seller Responsibilities & KeroLuxe Role",
          icon: <Users className="h-8 w-8 text-keroluxe-gold" />,
          content: (
            <>
            <p className="mb-2">KeroLuxe provides the platform for transactions. For items sold by third-party sellers, KeroLuxe is not the seller of record unless explicitly stated ('Official Store' items). KeroLuxe may facilitate dispute resolution but is not responsible for the quality, safety, or legality of items sold by third-party sellers, nor the truth or accuracy of their listings.</p>
            <p className="mb-2">Sellers are responsible for ensuring their items are authentic, accurately described, and comply with all applicable laws. KeroLuxe may implement verification processes for sellers and items, and may remove listings or suspend accounts for violations of these Terms.</p>
            <p className="mb-2">Parcel Pickup & Delivery: Sellers are responsible for preparing items for dispatch. KeroLuxe may offer a pickup and delivery service, the terms of which will be communicated separately. Notifications regarding parcel status (ready for pickup, in transit, delivered) will be provided through the platform.</p>
            </>
          )
        },
        {
          title: "7. Limitation of Liability",
          content: "In no event shall KeroLuxe, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service, or any conduct or content of any third party on the Service."
        },
        {
          title: "8. Governing Law",
          icon: <Gavel className="h-8 w-8 text-keroluxe-gold" />,
          content: "These Terms shall be governed and construed in accordance with the laws of Nigeria, without regard to its conflict of law provisions."
        },
        {
          title: "9. Changes to Terms",
          content: "We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will provide notice of material changes. By continuing to access or use our Service after any revisions become effective, you agree to be bound by the revised terms."
        },
        {
          title: "10. Contact Us",
          content: "If you have any questions about these Terms, please contact us at legal@keroluxe.com."
        }
      ];

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-12 px-4 text-keroluxe-black dark:text-keroluxe-white"
        >
          <header className="text-center mb-12">
            <Gavel className="h-16 w-16 text-keroluxe-gold mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold font-serif text-keroluxe-gold mb-4">Terms of Service</h1>
            <p className="text-lg text-keroluxe-grey dark:text-keroluxe-off-white max-w-2xl mx-auto">
              Please read these Terms of Service carefully before using the KeroLuxe website and services. Effective Date: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}.
            </p>
          </header>

          <div className="space-y-8">
            {sections.map((section, index) => (
              <motion.section 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.1 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
              >
                <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/20">
                  <CardHeader>
                     <div className="flex items-center">
                      {section.icon || <FileText className="h-8 w-8 text-keroluxe-gold" />}
                      <CardTitle className="ml-3 text-2xl md:text-3xl font-serif text-keroluxe-black dark:text-keroluxe-white">{section.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="prose prose-sm sm:prose-base max-w-none text-keroluxe-grey dark:text-neutral-300 leading-relaxed p-6">
                     {typeof section.content === 'string' ? <p>{section.content}</p> : section.content}
                  </CardContent>
                </Card>
              </motion.section>
            ))}
          </div>
        </motion.div>
      );
    };

    export default TermsOfServicePage;
