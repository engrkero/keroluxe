import React, { useState } from 'react';
    import { Link, useNavigate } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { useAppContext } from '@/contexts/AppContext';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label'; // Added this line
    import { Separator } from '@/components/ui/separator';
    import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
    import ProductCard from '@/components/ProductCard';
    import { products as allProductsData } from '@/data/products';
    import { ShoppingBag, ArrowLeft, Trash2, Plus, Minus } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';

    const CartPage = () => {
      const { cart, removeFromCart, updateCartQuantity, clearCart } = useAppContext();
      const navigate = useNavigate();
      const { toast } = useToast();
      const [promoCode, setPromoCode] = useState('');

      const handleQuantityChange = (productId, size, color, newQuantity) => {
        const numericQuantity = Number(newQuantity);
        if (!isNaN(numericQuantity) && numericQuantity >= 0) {
            updateCartQuantity(productId, size, color, numericQuantity);
        } else if (newQuantity === '') {
            // Allow clearing input, then maybe default to 1 or keep as is for user to correct
        } else {
            toast({ title: "Invalid Quantity", description: "Please enter a valid number.", variant: "destructive"});
        }
      };

      const handleRemoveItem = (productId, size, color) => {
        const product = cart.find(item => item.id === productId && item.selectedSize === size && item.selectedColor === color);
        removeFromCart(productId, size, color);
        toast({
          title: "Item Removed",
          description: `${product?.name || 'Item'} has been removed from your cart.`,
          variant: "destructive",
          className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold",
        });
      };
      
      const handleClearCart = () => {
        clearCart();
        toast({
          title: "Cart Cleared",
          description: "All items have been removed from your cart.",
          variant: "destructive",
          className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold",
        });
      };

      const subtotal = cart.reduce((sum, item) => {
        const price = Number(item.price);
        const quantity = Number(item.quantity);
        if (isNaN(price) || isNaN(quantity)) return sum;
        return sum + price * quantity;
      }, 0);
      
      const shippingCost = subtotal > 25000 || subtotal === 0 ? 0 : 2500; 
      const total = subtotal + shippingCost;

      const upsellItems = allProductsData.filter(p => p.category === 'Underwears (Male)').slice(0, 2);

      const pageVariants = {
        initial: { opacity: 0, y: 20 },
        animate: { opacity: 1, y: 0, transition: { duration: 0.5 } },
        exit: { opacity: 0, y: -20, transition: { duration: 0.3 } }
      };

      const itemVariants = {
        initial: { opacity: 0, x: -20 },
        animate: { opacity: 1, x: 0, transition: { duration: 0.3 } },
        exit: { opacity: 0, x: 20, transition: { duration: 0.2 } }
      };

      return (
        <motion.div 
          variants={pageVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          className="container mx-auto py-8 px-4 text-keroluxe-black dark:text-keroluxe-white"
        >
          <div className="flex flex-col sm:flex-row items-center justify-between mb-8 gap-4">
            <h1 className="text-3xl md:text-4xl font-bold font-serif">Your Shopping Cart</h1>
            <Button variant="outline" onClick={() => navigate('/')} className="btn-outline-gold">
              <ArrowLeft className="mr-2 h-4 w-4" /> Continue Shopping
            </Button>
          </div>

          {cart.length === 0 ? (
            <motion.div 
              variants={itemVariants} 
              className="text-center py-16 bg-keroluxe-off-white dark:bg-neutral-800 rounded-lg shadow-md"
            >
              <ShoppingBag className="mx-auto h-24 w-24 text-keroluxe-grey dark:text-neutral-500 mb-6" />
              <h2 className="text-2xl font-semibold mb-2">Your cart is empty.</h2>
              <p className="text-keroluxe-grey dark:text-neutral-400 mb-6">Looks like you haven't added anything to your cart yet.</p>
              <Button asChild size="lg" className="btn-primary">
                <Link to="/">Start Shopping</Link>
              </Button>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                {cart.map((item) => {
                  const itemPrice = Number(item.price);
                  const itemQuantity = Number(item.quantity);
                  const itemTotal = (isNaN(itemPrice) || isNaN(itemQuantity)) ? 0 : itemPrice * itemQuantity;

                  return (
                    <motion.div key={`${item.id}-${item.selectedSize}-${item.selectedColor}`} variants={itemVariants}>
                      <Card className="overflow-hidden shadow-lg bg-keroluxe-white dark:bg-neutral-800 border-keroluxe-grey/20 dark:border-neutral-700">
                        <CardContent className="p-4 flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-6">
                          <div className="w-full sm:w-24 h-32 sm:h-24 rounded-md overflow-hidden bg-keroluxe-off-white dark:bg-neutral-700 flex-shrink-0">
                            <img  alt={item.name} className="w-full h-full object-cover" src={item.images?.[0] || `https://source.unsplash.com/random/100x100/?${item.name?.replace(/\s/g, ',') || 'fashion'}`} />
                          </div>
                          <div className="flex-grow">
                            <Link to={`/product/${item.id}`} className="hover:text-keroluxe-gold">
                              <h3 className="text-lg font-semibold">{item.name}</h3>
                            </Link>
                            {item.selectedSize && <p className="text-sm text-keroluxe-grey dark:text-neutral-400">Size: {item.selectedSize}</p>}
                            {item.selectedColor && <p className="text-sm text-keroluxe-grey dark:text-neutral-400">Color: {item.selectedColor}</p>}
                            <p className="text-md font-medium text-keroluxe-gold mt-1">₦{itemPrice.toFixed(2)}</p>
                          </div>
                          <div className="flex items-center space-x-2 sm:space-x-3">
                            <Button variant="outline" size="icon" className="h-8 w-8 border-keroluxe-grey/50 text-keroluxe-grey dark:border-neutral-600 dark:text-neutral-400 hover:bg-keroluxe-off-white dark:hover:bg-neutral-700" onClick={() => handleQuantityChange(item.id, item.selectedSize, item.selectedColor, itemQuantity - 1)} disabled={itemQuantity <= 0}>
                              <Minus className="h-4 w-4" />
                            </Button>
                            <Input 
                                type="number" 
                                value={itemQuantity} 
                                onChange={(e) => handleQuantityChange(item.id, item.selectedSize, item.selectedColor, e.target.value === '' ? '' : parseInt(e.target.value, 10))}
                                min="0"
                                className="w-12 h-8 text-center bg-transparent border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold" 
                            />
                            <Button variant="outline" size="icon" className="h-8 w-8 border-keroluxe-grey/50 text-keroluxe-grey dark:border-neutral-600 dark:text-neutral-400 hover:bg-keroluxe-off-white dark:hover:bg-neutral-700" onClick={() => handleQuantityChange(item.id, item.selectedSize, item.selectedColor, itemQuantity + 1)}>
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                          <p className="text-lg font-semibold w-full sm:w-auto text-right sm:text-left">
                            ₦{itemTotal.toFixed(2)}
                          </p>
                          <Button variant="ghost" size="icon" className="text-red-500 hover:bg-red-100 dark:hover:bg-red-500/20" onClick={() => handleRemoveItem(item.id, item.selectedSize, item.selectedColor)}>
                            <Trash2 className="h-5 w-5" />
                          </Button>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
                 <Button variant="outline" onClick={handleClearCart} className="btn-destructive mt-4">
                    Clear Cart
                  </Button>
              </div>

              <div className="lg:col-span-1">
                <Card className="sticky top-24 shadow-xl bg-keroluxe-off-white dark:bg-neutral-800 border-keroluxe-grey/20 dark:border-neutral-700">
                  <CardHeader>
                    <CardTitle className="text-2xl font-serif">Order Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span>₦{subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Shipping</span>
                      <span>{shippingCost === 0 ? 'Free' : `₦${shippingCost.toFixed(2)}`}</span>
                    </div>
                    <Separator className="bg-keroluxe-grey/30 dark:bg-neutral-700 my-2" />
                    <div className="flex justify-between text-xl font-semibold">
                      <span>Total</span>
                      <span>₦{total.toFixed(2)}</span>
                    </div>
                    <div className="pt-2">
                      <Label htmlFor="promo-code" className="text-keroluxe-grey dark:text-neutral-400">Promo Code</Label>
                      <div className="flex space-x-2 mt-1">
                        <Input id="promo-code" placeholder="Enter code" value={promoCode} onChange={(e) => setPromoCode(e.target.value)} className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold" />
                        <Button variant="outline" className="btn-outline-gold">Apply</Button>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button size="lg" className="w-full btn-primary text-lg py-3" onClick={() => navigate('/checkout')}>
                      Proceed to Checkout
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </div>
          )}

          {cart.length > 0 && upsellItems.length > 0 && (
            <motion.section 
              variants={pageVariants}
              className="mt-16"
            >
              <h2 className="text-3xl font-semibold font-serif mb-8 text-center">Complete The Look</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                {upsellItems.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </motion.section>
          )}
        </motion.div>
      );
    };

    export default CartPage;