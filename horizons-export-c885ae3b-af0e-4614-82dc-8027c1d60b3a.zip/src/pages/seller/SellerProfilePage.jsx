import React, { useState } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
    import { UserCircle, Banknote, UploadCloud, ShieldCheck, Save } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';

    const SellerProfilePage = () => {
      const { toast } = useToast();
      const [profileData, setProfileData] = useState({
        storeName: 'My KeroLuxe Boutique',
        contactEmail: 'seller@example.com',
        phone: '08012345678',
        storeDescription: 'Selling unique vintage and first-class bale items.',
        bankName: 'Moniepoint MFB',
        accountNumber: '1234567890',
        accountName: 'My Boutique Store',
        nin: '',
        bvn: '',
        cac: '',
      });
      const [isEditing, setIsEditing] = useState(false);

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setProfileData(prev => ({ ...prev, [name]: value }));
      };

      const handleFileChange = (e) => {
        const { name, files } = e.target;
        if (files[0]) {
          setProfileData(prev => ({ ...prev, [`${name}File`]: files[0].name }));
           toast({ title: "File Selected", description: `${files[0].name} ready for upload.`});
        }
      };
      
      const handleSubmit = (e) => {
        e.preventDefault();
        setIsEditing(false);
        toast({
          title: "Profile Updated!",
          description: "Your seller profile has been saved.",
          className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold",
        });
        // Here you would typically send data to a backend
        console.log("Profile data to save:", profileData);
      };

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="p-4 md:p-6 space-y-6"
        >
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-keroluxe-black dark:text-keroluxe-white">Seller Profile</h1>
            <Button onClick={() => setIsEditing(!isEditing)} variant={isEditing ? "destructive" : "outline"} className={isEditing ? "" : "btn-outline-gold"}>
              {isEditing ? 'Cancel Edit' : 'Edit Profile'}
            </Button>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Store Information */}
              <Card className="lg:col-span-2 bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-xl text-keroluxe-black dark:text-keroluxe-white flex items-center">
                    <UserCircle className="mr-2 h-6 w-6 text-keroluxe-gold" /> Store Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="storeName" className="text-keroluxe-black dark:text-keroluxe-off-white">Store Name</Label>
                    <Input id="storeName" name="storeName" value={profileData.storeName} onChange={handleInputChange} disabled={!isEditing} className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700"/>
                  </div>
                  <div>
                    <Label htmlFor="contactEmail" className="text-keroluxe-black dark:text-keroluxe-off-white">Contact Email</Label>
                    <Input id="contactEmail" name="contactEmail" type="email" value={profileData.contactEmail} onChange={handleInputChange} disabled={!isEditing} className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700"/>
                  </div>
                  <div>
                    <Label htmlFor="phone" className="text-keroluxe-black dark:text-keroluxe-off-white">Phone Number</Label>
                    <Input id="phone" name="phone" type="tel" value={profileData.phone} onChange={handleInputChange} disabled={!isEditing} className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700"/>
                  </div>
                  <div>
                    <Label htmlFor="storeDescription" className="text-keroluxe-black dark:text-keroluxe-off-white">Store Description</Label>
                    <Textarea id="storeDescription" name="storeDescription" value={profileData.storeDescription} onChange={handleInputChange} disabled={!isEditing} rows={3} className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700"/>
                  </div>
                </CardContent>
              </Card>

              {/* Banking Details */}
              <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-xl text-keroluxe-black dark:text-keroluxe-white flex items-center">
                    <Banknote className="mr-2 h-6 w-6 text-keroluxe-gold" /> Banking Details (Moniepoint)
                  </CardTitle>
                  <CardDescription className="text-keroluxe-grey dark:text-neutral-400">For weekly payouts. KeroLuxe charges 5% on your profit margin.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="bankName" className="text-keroluxe-black dark:text-keroluxe-off-white">Bank Name</Label>
                    <Input id="bankName" name="bankName" value={profileData.bankName} disabled className="mt-1 bg-neutral-200 dark:bg-neutral-600 cursor-not-allowed"/>
                  </div>
                  <div>
                    <Label htmlFor="accountNumber" className="text-keroluxe-black dark:text-keroluxe-off-white">Account Number</Label>
                    <Input id="accountNumber" name="accountNumber" value={profileData.accountNumber} onChange={handleInputChange} disabled={!isEditing} className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700"/>
                  </div>
                   <div>
                    <Label htmlFor="accountName" className="text-keroluxe-black dark:text-keroluxe-off-white">Account Name</Label>
                    <Input id="accountName" name="accountName" value={profileData.accountName} onChange={handleInputChange} disabled={!isEditing} className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700"/>
                  </div>
                </CardContent>
              </Card>

              {/* Verification Documents */}
              <Card className="lg:col-span-3 bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-xl text-keroluxe-black dark:text-keroluxe-white flex items-center">
                    <ShieldCheck className="mr-2 h-6 w-6 text-keroluxe-gold" /> Verification Documents
                  </CardTitle>
                  <CardDescription className="text-keroluxe-grey dark:text-neutral-400">Upload your government-issued IDs for verification.</CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="nin" className="text-keroluxe-black dark:text-keroluxe-off-white">NIN (National Identification Number)</Label>
                    <div className="mt-1 flex items-center">
                      <Input id="nin" name="nin" type="file" onChange={handleFileChange} disabled={!isEditing} className="file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-keroluxe-gold/20 file:text-keroluxe-gold hover:file:bg-keroluxe-gold/30 flex-grow bg-keroluxe-off-white dark:bg-neutral-700"/>
                      {profileData.ninFile && <span className="ml-2 text-xs text-green-500">Uploaded</span>}
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="bvn" className="text-keroluxe-black dark:text-keroluxe-off-white">BVN (Bank Verification Number)</Label>
                     <div className="mt-1 flex items-center">
                      <Input id="bvn" name="bvn" type="file" onChange={handleFileChange} disabled={!isEditing} className="file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-keroluxe-gold/20 file:text-keroluxe-gold hover:file:bg-keroluxe-gold/30 flex-grow bg-keroluxe-off-white dark:bg-neutral-700"/>
                      {profileData.bvnFile && <span className="ml-2 text-xs text-green-500">Uploaded</span>}
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="cac" className="text-keroluxe-black dark:text-keroluxe-off-white">CAC Certificate (Optional)</Label>
                     <div className="mt-1 flex items-center">
                        <Input id="cac" name="cac" type="file" onChange={handleFileChange} disabled={!isEditing} className="file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-keroluxe-gold/20 file:text-keroluxe-gold hover:file:bg-keroluxe-gold/30 flex-grow bg-keroluxe-off-white dark:bg-neutral-700"/>
                        {profileData.cacFile && <span className="ml-2 text-xs text-green-500">Uploaded</span>}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            {isEditing && (
              <CardFooter className="mt-6 flex justify-end p-0">
                <Button type="submit" className="btn-primary">
                  <Save className="mr-2 h-5 w-5"/> Save Changes
                </Button>
              </CardFooter>
            )}
          </form>
        </motion.div>
      );
    };

    export default SellerProfilePage;