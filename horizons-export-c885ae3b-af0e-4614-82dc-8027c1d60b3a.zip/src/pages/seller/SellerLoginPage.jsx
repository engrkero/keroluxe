import React, { useState } from 'react';
    import { useNavigate, Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
    import { LogIn, Store, UserPlus } from 'lucide-react';
    import { useAppContext } from '@/contexts/AppContext';
    import { useToast } from '@/components/ui/use-toast';

    const SellerLoginPage = () => {
      const [email, setEmail] = useState('');
      const [password, setPassword] = useState('');
      const { login, isLoading } = useAppContext(); 
      const navigate = useNavigate();
      const { toast } = useToast();

      const handleSubmit = async (e) => {
        e.preventDefault();
        const success = await login(email, password);
        if (success) {
          // Navigation and success toast are handled by AppContext's login function
        } else {
          // Error toast is handled by AppContext's login function
        }
      };

      return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-keroluxe-black via-neutral-800 to-keroluxe-black p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="w-full max-w-md bg-keroluxe-white dark:bg-neutral-900 shadow-2xl border-keroluxe-gold/30">
              <CardHeader className="text-center space-y-2">
                <Store className="h-12 w-12 text-keroluxe-gold mx-auto" />
                <CardTitle className="text-3xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Seller Login</CardTitle>
                <CardDescription className="text-keroluxe-grey dark:text-neutral-400">Access your KeroLuxe Seller Dashboard.</CardDescription>
              </CardHeader>
              <form onSubmit={handleSubmit}>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-keroluxe-black dark:text-keroluxe-off-white">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="yourstore@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="bg-keroluxe-off-white dark:bg-neutral-800 border-keroluxe-grey/30 dark:border-neutral-700 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-keroluxe-black dark:text-keroluxe-off-white">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="bg-keroluxe-off-white dark:bg-neutral-800 border-keroluxe-grey/30 dark:border-neutral-700 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white"
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col space-y-4">
                  <Button type="submit" className="w-full bg-keroluxe-gold text-keroluxe-black hover:bg-keroluxe-gold/90 dark:bg-keroluxe-gold dark:text-keroluxe-black dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black" disabled={isLoading}>
                    {isLoading ? 'Logging In...' : 'Log In'}
                    {!isLoading && <LogIn className="ml-2 h-5 w-5" />}
                  </Button>
                  <p className="text-xs text-keroluxe-grey dark:text-neutral-500 text-center">
                    Don't have a seller account? 
                    <Link to="/sell-with-us" className="font-medium text-keroluxe-gold hover:underline ml-1">
                       Register here <UserPlus className="inline h-3 w-3"/>
                    </Link>
                  </p>
                   <p className="text-xs text-keroluxe-grey dark:text-neutral-500 text-center pt-2">
                    Are you a customer? 
                    <Link to="/login" className="font-medium text-keroluxe-gold hover:underline ml-1">
                       Login here
                    </Link>
                  </p>
                </CardFooter>
              </form>
            </Card>
          </motion.div>
        </div>
      );
    };

    export default SellerLoginPage;