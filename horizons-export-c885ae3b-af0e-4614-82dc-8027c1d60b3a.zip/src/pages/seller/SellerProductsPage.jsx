import React from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { PlusCircle, PackageSearch, Edit, Trash2 } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

    const SellerProductsPage = () => {
      const mockProducts = [
        { id: 'p1', name: 'Vintage Silk Scarf', category: 'Accessories', price: '₦15,000', stock: 12, status: 'Active' },
        { id: 'p2', name: 'Designer Leather Handbag', category: 'Female Hand Bags', price: '₦75,000', stock: 5, status: 'Active' },
        { id: 'p3', name: 'Retro Denim Jacket', category: 'Bale - Jeans', price: '₦22,000', stock: 0, status: 'Out of Stock' },
      ];

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="p-4 md:p-6 space-y-6"
        >
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h1 className="text-3xl font-bold text-keroluxe-black dark:text-keroluxe-white">My Products</h1>
            <Button className="btn-primary">
              <PlusCircle className="mr-2 h-5 w-5" /> Add New Product
            </Button>
          </div>

          <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl text-keroluxe-black dark:text-keroluxe-white flex items-center">
                <PackageSearch className="mr-2 h-6 w-6 text-keroluxe-gold" /> Product Listings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Input 
                  placeholder="Search products..."
                  className="bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white focus:border-keroluxe-gold"
                />
              </div>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent dark:hover:bg-transparent">
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Name</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Category</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Price</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Stock</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Status</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockProducts.map((product) => (
                      <TableRow key={product.id} className="border-keroluxe-grey/20 dark:border-neutral-700 hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50">
                        <TableCell className="font-medium text-keroluxe-black dark:text-keroluxe-white">{product.name}</TableCell>
                        <TableCell className="text-keroluxe-grey dark:text-neutral-400">{product.category}</TableCell>
                        <TableCell className="text-keroluxe-grey dark:text-neutral-400">{product.price}</TableCell>
                        <TableCell className="text-keroluxe-grey dark:text-neutral-400">{product.stock}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${product.status === 'Active' ? 'bg-green-100 text-green-700 dark:bg-green-700 dark:text-green-100' : 'bg-red-100 text-red-700 dark:bg-red-700 dark:text-red-100'}`}>
                            {product.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button variant="ghost" size="icon" className="text-keroluxe-grey hover:text-keroluxe-gold">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-700">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
               {mockProducts.length === 0 && (
                 <p className="text-center py-8 text-keroluxe-grey dark:text-neutral-500">You haven't added any products yet.</p>
              )}
            </CardContent>
          </Card>
        </motion.div>
      );
    };

    export default SellerProductsPage;