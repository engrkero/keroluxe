import React, { useState } from 'react';
    import { Navigate, Outlet, Link, NavLink } from 'react-router-dom';
    import { useAppContext } from '@/contexts/AppContext';
    import { Button } from '@/components/ui/button';
    import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
    import { Menu, LogOut, Home, Package, ShoppingCart, User, Settings, BarChart2, Scissors } from 'lucide-react';
    import { cn } from '@/lib/utils';

    const SidebarNavItem = ({ to, icon, children, onLinkClick }) => (
      <NavLink
        to={to}
        onClick={onLinkClick}
        className={({ isActive }) =>
          cn(
            "flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
            isActive
              ? "bg-keroluxe-gold text-keroluxe-black"
              : "text-neutral-300 hover:bg-neutral-700 hover:text-keroluxe-white"
          )
        }
      >
        {React.cloneElement(icon, { className: "mr-3 h-5 w-5" })}
        {children}
      </NavLink>
    );

    const SellerLayout = () => {
      const { isAdminAuthenticated, adminLogout } = useAppContext(); // Using admin auth for now
      const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

      // For demo, we assume if an admin is logged in, they can access seller.
      // In a real app, this would be a separate seller authentication.
      // For now, if not admin authenticated, redirect to main login. A real seller app would have its own login.
      if (!isAdminAuthenticated) {
        return <Navigate to="/login" replace />; 
      }

      const closeMobileMenu = () => setMobileMenuOpen(false);

      const sidebarContent = (
        <div className="flex flex-col h-full">
          <div className="p-4 border-b border-neutral-700">
            <Link to="/seller/dashboard" className="flex items-center text-keroluxe-white" onClick={closeMobileMenu}>
              <Scissors className="h-8 w-8 text-keroluxe-gold" />
              <span className="ml-2 text-xl font-bold font-serif">KeroLuxe Seller</span>
            </Link>
          </div>
          <nav className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
            <SidebarNavItem to="/seller/dashboard" icon={<Home />} onLinkClick={closeMobileMenu}>Dashboard</SidebarNavItem>
            <SidebarNavItem to="/seller/products" icon={<Package />} onLinkClick={closeMobileMenu}>Products</SidebarNavItem>
            <SidebarNavItem to="/seller/orders" icon={<ShoppingCart />} onLinkClick={closeMobileMenu}>Orders</SidebarNavItem>
            <SidebarNavItem to="/seller/profile" icon={<User />} onLinkClick={closeMobileMenu}>Profile</SidebarNavItem>
            <SidebarNavItem to="/seller/analytics" icon={<BarChart2 />} onLinkClick={() => {closeMobileMenu(); alert("Seller Analytics Coming Soon!")}}>Analytics</SidebarNavItem>
            <SidebarNavItem to="/seller/settings" icon={<Settings />} onLinkClick={() => {closeMobileMenu(); alert("Seller Settings Coming Soon!")}}>Settings</SidebarNavItem>
          </nav>
          <div className="p-4 border-t border-neutral-700">
            <Button variant="ghost" className="w-full justify-start text-neutral-300 hover:bg-neutral-700 hover:text-keroluxe-white" onClick={() => { adminLogout(); closeMobileMenu(); /*navigate to main page or seller login*/ }}>
              <LogOut className="mr-3 h-5 w-5" /> Logout
            </Button>
          </div>
        </div>
      );


      return (
        <div className="flex h-screen bg-neutral-900 text-keroluxe-white">
          {/* Desktop Sidebar */}
          <aside className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 bg-neutral-800 border-r border-neutral-700">
            {sidebarContent}
          </aside>

          {/* Mobile Sidebar */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild className="md:hidden fixed top-4 left-4 z-50">
              <Button variant="outline" size="icon" className="bg-neutral-800 border-neutral-700 text-keroluxe-white hover:bg-neutral-700">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 bg-neutral-800 p-0 border-r-0">
              {sidebarContent}
            </SheetContent>
          </Sheet>

          <main className="flex-1 md:pl-64 flex flex-col">
            <div className="flex-1 p-4 md:p-8 overflow-y-auto bg-keroluxe-off-white dark:bg-neutral-900">
              <Outlet />
            </div>
          </main>
        </div>
      );
    };

    export default SellerLayout;