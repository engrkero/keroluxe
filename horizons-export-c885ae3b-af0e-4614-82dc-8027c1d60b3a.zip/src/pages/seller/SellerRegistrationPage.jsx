import React, { useState } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Link, useNavigate } from 'react-router-dom';
    import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
    import { Store, CheckCircle, AlertTriangle } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';
    import { useAppContext } from '@/contexts/AppContext';
    import { supabase } from '@/lib/supabaseClient';

    import AccountStep from '@/components/seller/registration/AccountStep';
    import StoreStep from '@/components/seller/registration/StoreStep';
    import BankingStep from '@/components/seller/registration/BankingStep';
    import VerificationStep from '@/components/seller/registration/VerificationStep';
    import useSellerRegistrationForm from '@/hooks/useSellerRegistrationForm';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';


    const SellerRegistrationPage = () => {
      const { toast } = useToast();
      const navigate = useNavigate();
      const { signUp } = useAppContext();

      const {
        step,
        formData,
        filePreviews,
        isCameraOn,
        videoRef,
        canvasRef,
        handleInputChange,
        handleFileChange,
        startCamera,
        capturePhoto,
        stopCamera,
        nextStep,
        prevStep,
        setFormData,
        setFilePreviews,
      } = useSellerRegistrationForm();

      const [registrationLoading, setRegistrationLoading] = useState(false);
      const [showSuccessModal, setShowSuccessModal] = useState(false);

      const uploadFile = async (file, bucket, userId, pathPrefix = '') => {
        if (!file) return null;
        const fileName = `${userId}/${pathPrefix}${Date.now()}_${file.name.replace(/\s/g, '_')}`;
        const { data, error } = await supabase.storage.from(bucket).upload(fileName, file);
        if (error) {
          console.error(`Error uploading ${file.name}:`, error);
          toast({title: `Upload Error: ${file.name}`, description: error.message, variant: "destructive"});
          return null;
        }
        const { data: { publicUrl } } = supabase.storage.from(bucket).getPublicUrl(fileName);
        return publicUrl;
      };

      const handleSubmit = async (e) => {
        e.preventDefault();
        if (step !== 4) return; // Ensure submission only on final step

        if (!formData.ninNumber || !formData.bvnNumber || !formData.passportPhotoFile || !formData.ninFrontFile || !formData.ninBackFile || !formData.facialVerificationPhoto) {
           toast({ title: "Missing Fields", description: "Please fill all required verification fields and complete facial verification.", variant: "destructive" });
           return;
        }
        setRegistrationLoading(true);
        console.log("Function Tracking: Seller registration submit initiated", formData.email);

        const newUser = await signUp(formData.email, formData.password, { role: 'seller', username: formData.email.split('@')[0] || formData.storeName.replace(/\s/g, '') });
        
        if (!newUser || !newUser.id) {
          toast({ title: "Account Creation Failed", description: "Could not create user account. Please try again.", variant: "destructive" });
          setRegistrationLoading(false);
          return; 
        }

        const userId = newUser.id;

        const ninFrontUrl = await uploadFile(formData.ninFrontFile, 'verification_documents', userId, 'nin_front_');
        const ninBackUrl = await uploadFile(formData.ninBackFile, 'verification_documents', userId, 'nin_back_');
        const passportPhotoUrl = await uploadFile(formData.passportPhotoFile, 'verification_documents', userId, 'passport_');
        const cacFileUrl = await uploadFile(formData.cacFile, 'verification_documents', userId, 'cac_');
        const facialVerificationPhotoUrl = await uploadFile(formData.facialVerificationPhoto, 'verification_documents', userId, 'facial_');

        if (!ninFrontUrl || !ninBackUrl || !passportPhotoUrl || !facialVerificationPhotoUrl) {
          toast({title: "Document Upload Failed", description: "One or more verification documents failed to upload. Please try again.", variant: "destructive"});
          // Consider cleanup of created user if docs fail, or allow re-upload later
          setRegistrationLoading(false);
          return;
        }
        
        const sellerData = {
          id: userId, 
          store_name: formData.storeName,
          store_description: formData.storeDescription,
          contact_phone: formData.contactPhone,
          contact_email: formData.email, // Ensure this is the same as auth email
          bank_name: formData.bankName,
          bank_account_number: formData.accountNumber,
          bank_account_name: formData.accountName,
          nin_number: formData.ninNumber,
          bvn_number: formData.bvnNumber,
          nin_front_url: ninFrontUrl,
          nin_back_url: ninBackUrl,
          passport_photo_url: passportPhotoUrl,
          cac_document_url: cacFileUrl,
          facial_verification_photo_url: facialVerificationPhotoUrl,
          status: 'Pending', 
        };

        const { error: sellerError } = await supabase.from('sellers').insert(sellerData);

        setRegistrationLoading(false);
        if (sellerError) {
           toast({ title: "Seller Profile Creation Failed", description: sellerError.message, variant: "destructive" });
           console.error("Seller profile error:", sellerError);
        } else {
          console.log("Function Tracking: Seller registration successful", userId);
          setShowSuccessModal(true);
          // Toast for email confirmation is handled by signUp in useAuth
        }
      };
      
      const handleModalClose = () => {
        setShowSuccessModal(false);
        navigate('/seller/login');
      }

      const renderStepContent = () => {
        switch (step) {
          case 1: return <AccountStep formData={formData} handleInputChange={handleInputChange} />;
          case 2: return <StoreStep formData={formData} handleInputChange={handleInputChange} />;
          case 3: return <BankingStep formData={formData} handleInputChange={handleInputChange} />;
          case 4: return <VerificationStep 
                            formData={formData} 
                            handleInputChange={handleInputChange} 
                            handleFileChange={handleFileChange} 
                            filePreviews={filePreviews}
                            isCameraOn={isCameraOn}
                            videoRef={videoRef}
                            canvasRef={canvasRef}
                            startCamera={startCamera}
                            capturePhoto={capturePhoto}
                            stopCamera={stopCamera}
                          />;
          default: return null;
        }
      };

      return (
        <>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-keroluxe-black via-neutral-800 to-keroluxe-black p-4 md:p-6 text-keroluxe-white"
        >
          <Card className="w-full max-w-lg bg-keroluxe-white dark:bg-neutral-800 shadow-2xl border-keroluxe-gold/20">
            <CardHeader className="text-center">
                <Store className="h-10 w-10 text-keroluxe-gold mx-auto mb-2" />
                <CardTitle className="text-2xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Become a KeroLuxe Seller</CardTitle>
                <CardDescription className="text-keroluxe-grey dark:text-neutral-400">Step {step} of 4</CardDescription>
            </CardHeader>
            <CardContent className="px-4 py-3 sm:px-6 sm:py-4">
              <form onSubmit={handleSubmit}>
                {renderStepContent()}
                <CardFooter className="flex justify-between mt-4 p-0">
                  {step > 1 && (
                    <Button type="button" variant="outline" onClick={prevStep} className="border-keroluxe-gold text-keroluxe-gold hover:bg-keroluxe-gold/10 dark:text-keroluxe-off-white dark:border-keroluxe-gold dark:hover:bg-keroluxe-gold/20" disabled={registrationLoading}>
                      Previous
                    </Button>
                  )}
                  {step < 4 && (
                    <Button type="button" onClick={nextStep} className="btn-primary ml-auto" disabled={registrationLoading}>
                      Next
                    </Button>
                  )}
                  {step === 4 && (
                    <Button type="submit" className="btn-primary ml-auto" disabled={registrationLoading}>
                      {registrationLoading ? 'Submitting...' : 'Submit Application'}
                    </Button>
                  )}
                </CardFooter>
              </form>
            </CardContent>
          </Card>
          <p className="mt-4 text-center text-xs text-keroluxe-off-white/70">
            Already have a seller account? <Link to="/seller/login" className="font-medium text-keroluxe-gold hover:underline">Log In Here</Link>
          </p>
        </motion.div>

        <Dialog open={showSuccessModal} onOpenChange={setShowSuccessModal}>
          <DialogContent className="bg-keroluxe-white dark:bg-neutral-800 border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white">
            <DialogHeader>
              <DialogTitle className="flex items-center text-2xl text-keroluxe-gold">
                <CheckCircle className="h-8 w-8 mr-3 text-green-500" />
                Registration Submitted!
              </DialogTitle>
            </DialogHeader>
            <DialogDescription className="py-4 text-keroluxe-grey dark:text-neutral-300">
              Congratulations! Your seller application has been successfully submitted. 
              Please check your email (<strong className="text-keroluxe-gold">{formData.email}</strong>) to confirm your account.
              <br/><br/>
              Our team will review your application, and you'll be notified of the approval status soon. You can log in to check your status.
            </DialogDescription>
            <DialogFooter>
              <Button onClick={handleModalClose} className="btn-primary">
                Okay, Got It!
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        </>
      );
    };

    export default SellerRegistrationPage;