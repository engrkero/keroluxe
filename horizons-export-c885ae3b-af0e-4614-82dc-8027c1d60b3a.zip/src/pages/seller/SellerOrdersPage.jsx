import React from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { ListOrdered, Search, Filter } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

    const SellerOrdersPage = () => {
       const mockOrders = [
        { id: 'ORD001', date: '2024-05-20', customer: 'Ada Okoro', total: '₦15,000', status: 'Pending Shipment', items: 1 },
        { id: 'ORD002', date: '2024-05-18', customer: 'Bayo Adekunle', total: '₦75,000', status: 'Shipped', items: 1 },
        { id: 'ORD003', date: '2024-05-15', customer: 'Chidi Eze', total: '₦37,500', status: 'Delivered', items: 2 },
      ];

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="p-4 md:p-6 space-y-6"
        >
          <h1 className="text-3xl font-bold text-keroluxe-black dark:text-keroluxe-white">My Orders</h1>
          
          <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl text-keroluxe-black dark:text-keroluxe-white flex items-center">
                <ListOrdered className="mr-2 h-6 w-6 text-keroluxe-gold" /> Order History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div className="relative flex-grow">
                  <Input 
                    placeholder="Search by Order ID or Customer Name..."
                    className="pl-10 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white focus:border-keroluxe-gold"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-keroluxe-grey dark:text-neutral-400" />
                </div>
                <Select>
                  <SelectTrigger className="w-full sm:w-[180px] bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white focus:border-keroluxe-gold">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent className="bg-keroluxe-white dark:bg-neutral-700">
                    <SelectItem value="all" className="text-keroluxe-black dark:text-keroluxe-off-white">All Statuses</SelectItem>
                    <SelectItem value="pending" className="text-keroluxe-black dark:text-keroluxe-off-white">Pending Shipment</SelectItem>
                    <SelectItem value="shipped" className="text-keroluxe-black dark:text-keroluxe-off-white">Shipped</SelectItem>
                    <SelectItem value="delivered" className="text-keroluxe-black dark:text-keroluxe-off-white">Delivered</SelectItem>
                    <SelectItem value="cancelled" className="text-keroluxe-black dark:text-keroluxe-off-white">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent dark:hover:bg-transparent">
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Order ID</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Date</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Customer</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Items</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Total</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Status</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-off-white">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockOrders.map((order) => (
                      <TableRow key={order.id} className="border-keroluxe-grey/20 dark:border-neutral-700 hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50">
                        <TableCell className="font-medium text-keroluxe-gold hover:underline cursor-pointer">{order.id}</TableCell>
                        <TableCell className="text-keroluxe-grey dark:text-neutral-400">{order.date}</TableCell>
                        <TableCell className="text-keroluxe-grey dark:text-neutral-400">{order.customer}</TableCell>
                        <TableCell className="text-keroluxe-grey dark:text-neutral-400">{order.items}</TableCell>
                        <TableCell className="text-keroluxe-grey dark:text-neutral-400">{order.total}</TableCell>
                        <TableCell>
                           <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                            order.status === 'Delivered' ? 'bg-green-100 text-green-700 dark:bg-green-700 dark:text-green-100' :
                            order.status === 'Shipped' ? 'bg-blue-100 text-blue-700 dark:bg-blue-700 dark:text-blue-100' :
                            order.status === 'Pending Shipment' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-700 dark:text-yellow-100' :
                            'bg-red-100 text-red-700 dark:bg-red-700 dark:text-red-100'
                          }`}>
                            {order.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Button variant="outline" size="sm" className="btn-outline-gold text-xs">View Details</Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              {mockOrders.length === 0 && (
                 <p className="text-center py-8 text-keroluxe-grey dark:text-neutral-500">You have no orders yet.</p>
              )}
            </CardContent>
          </Card>
        </motion.div>
      );
    };
    export default SellerOrdersPage;