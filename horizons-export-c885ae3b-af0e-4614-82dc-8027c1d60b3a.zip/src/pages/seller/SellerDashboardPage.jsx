import React from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { DollarSign, ShoppingBag, Users, Activity, BarChartBig } from 'lucide-react';

    const SellerDashboardPage = () => {
      const stats = [
        { title: "Total Sales", value: "₦125,670", icon: <DollarSign className="h-6 w-6 text-green-500" />, change: "+12% this month" },
        { title: "Active Listings", value: "72", icon: <ShoppingBag className="h-6 w-6 text-blue-500" />, change: "+5 new" },
        { title: "Pending Orders", value: "8", icon: <Activity className="h-6 w-6 text-yellow-500" />, change: "2 overdue" },
        { title: "Customer Reviews", value: "4.8/5 (120)", icon: <Users className="h-6 w-6 text-purple-500" />, change: "+10 new reviews" },
      ];

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="p-4 md:p-6 space-y-6"
        >
          <h1 className="text-3xl font-bold text-keroluxe-black dark:text-keroluxe-white">Seller Dashboard</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <Card key={index} className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-keroluxe-grey dark:text-neutral-400">{stat.title}</CardTitle>
                  {stat.icon}
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-keroluxe-black dark:text-keroluxe-white">{stat.value}</div>
                  <p className="text-xs text-muted-foreground dark:text-neutral-500">{stat.change}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl text-keroluxe-black dark:text-keroluxe-white flex items-center">
                  <BarChartBig className="mr-2 h-5 w-5 text-keroluxe-gold" /> Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-keroluxe-grey dark:text-neutral-400">Activity chart placeholder. Your recent sales and product views will appear here.</p>
                 <img  alt="Placeholder chart for recent activity" className="mt-4 w-full h-48 object-contain opacity-50" src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=500" />
              </CardContent>
            </Card>
            <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl text-keroluxe-black dark:text-keroluxe-white">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <button className="w-full text-left p-2 rounded hover:bg-keroluxe-off-white dark:hover:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white">Add New Product</button>
                <button className="w-full text-left p-2 rounded hover:bg-keroluxe-off-white dark:hover:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white">View All Orders</button>
                <button className="w-full text-left p-2 rounded hover:bg-keroluxe-off-white dark:hover:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white">Manage Inventory</button>
              </CardContent>
            </Card>
          </div>
          <p className="text-center text-sm text-keroluxe-grey dark:text-neutral-500 mt-8">
            Welcome to your KeroLuxe seller portal. More features coming soon!
          </p>
        </motion.div>
      );
    };

    export default SellerDashboardPage;