import React, { useState, useEffect } from 'react';
    import { motion } from 'framer-motion';
    import { useAppContext } from '@/contexts/AppContext';
    import { Link, useNavigate } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
    import { User, ShoppingBag, Heart, Settings, LogOut, Edit3, Save } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';

    const UserProfilePage = () => {
      const { user, userProfile, logout, supabase, fetchUserProfile, isLoading: authLoading } = useAppContext();
      const navigate = useNavigate();
      const { toast } = useToast();

      const [isEditing, setIsEditing] = useState(false);
      const [profileData, setProfileData] = useState({
        username: '',
        full_name: '',
        avatar_url: '',
      });
      const [newAvatarFile, setNewAvatarFile] = useState(null);
      const [avatarPreview, setAvatarPreview] = useState(null);
      const [isUploading, setIsUploading] = useState(false);

      useEffect(() => {
        if (!authLoading && !user) {
          navigate('/login');
          toast({ title: "Not Authenticated", description: "Please log in to view your profile.", variant: "destructive" });
        } else if (userProfile) {
          setProfileData({
            username: userProfile.username || '',
            full_name: userProfile.full_name || '',
            avatar_url: userProfile.avatar_url || '',
          });
          setAvatarPreview(userProfile.avatar_url || `https://source.unsplash.com/128x128/?${encodeURIComponent(userProfile.username || 'person')}`);
        } else if (user && !userProfile) {
           setAvatarPreview(`https://source.unsplash.com/128x128/?${encodeURIComponent(user.email.split('@')[0] || 'person')}`);
        }
      }, [user, userProfile, navigate, toast, authLoading]);

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setProfileData(prev => ({ ...prev, [name]: value }));
      };

      const handleAvatarChange = (e) => {
        if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          setNewAvatarFile(file);
          setAvatarPreview(URL.createObjectURL(file));
        }
      };

      const handleProfileUpdate = async () => {
        if (!user) return;
        setIsUploading(true);

        let newAvatarPublicUrl = profileData.avatar_url;

        if (newAvatarFile) {
          const fileExt = newAvatarFile.name.split('.').pop();
          const fileName = `${user.id}-${Date.now()}.${fileExt}`;
          const filePath = `avatars/${fileName}`;

          const { error: uploadError } = await supabase.storage
            .from('avatars')
            .upload(filePath, newAvatarFile);

          if (uploadError) {
            toast({ title: "Avatar Upload Failed", description: uploadError.message, variant: "destructive" });
            setIsUploading(false);
            return;
          }
          const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(filePath);
          newAvatarPublicUrl = publicUrl;
        }

        const updates = {
          id: user.id,
          username: profileData.username,
          full_name: profileData.full_name,
          avatar_url: newAvatarPublicUrl,
          updated_at: new Date(),
        };

        const { error } = await supabase.from('profiles').upsert(updates);

        setIsUploading(false);
        if (error) {
          toast({ title: "Profile Update Failed", description: error.message, variant: "destructive" });
        } else {
          toast({ title: "Profile Updated!", description: "Your profile has been successfully updated.", className: "bg-keroluxe-gold text-keroluxe-black" });
          setIsEditing(false);
          fetchUserProfile(user.id); // Re-fetch to update context
        }
      };

      if (authLoading || (!userProfile && user)) { // Show loading if auth is loading OR if user exists but profile hasn't loaded yet
        return (
          <div className="container mx-auto py-12 px-4 text-center">
            <p className="text-lg text-keroluxe-black dark:text-keroluxe-white">Loading profile...</p>
          </div>
        );
      }
      
      if (!user) { // If no user after loading, means not logged in.
         return (
          <div className="container mx-auto py-12 px-4 text-center">
            <p className="text-lg text-keroluxe-black dark:text-keroluxe-white">Please log in to view your profile.</p>
            <Button asChild className="mt-4 btn-primary"><Link to="/login">Login</Link></Button>
          </div>
        );
      }


      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-12 px-4 text-keroluxe-black dark:text-keroluxe-white"
        >
          <div className="flex flex-col md:flex-row items-center justify-between mb-10">
            <h1 className="text-4xl font-bold font-serif text-keroluxe-gold">My Profile</h1>
            <Button variant="outline" onClick={logout} className="mt-4 md:mt-0 btn-outline-destructive">
              <LogOut className="mr-2 h-4 w-4" /> Logout
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Profile Card & Edit Form */}
            <Card className="md:col-span-2 bg-keroluxe-off-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/10">
              <CardHeader className="flex flex-row items-center justify-between space-x-2">
                <div>
                  <CardTitle className="text-2xl font-serif text-keroluxe-black dark:text-keroluxe-white">
                    Welcome, {profileData.username || user.email.split('@')[0]}!
                  </CardTitle>
                  <CardDescription className="text-keroluxe-grey dark:text-neutral-400">Manage your account details.</CardDescription>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setIsEditing(!isEditing)} className="text-keroluxe-gold hover:text-keroluxe-rose-gold">
                  {isEditing ? <Save className="h-5 w-5" /> : <Edit3 className="h-5 w-5" />}
                </Button>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col items-center sm:flex-row sm:items-start space-y-4 sm:space-y-0 sm:space-x-6">
                  <div className="relative">
                    <Avatar className="w-24 h-24 md:w-32 md:h-32 border-2 border-keroluxe-gold">
                      <AvatarImage src={avatarPreview} alt={profileData.username} />
                      <AvatarFallback className="text-3xl bg-keroluxe-gold text-keroluxe-black">{profileData.username?.charAt(0).toUpperCase() || user.email.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    {isEditing && (
                       <Label htmlFor="avatar-upload" className="absolute bottom-0 right-0 bg-keroluxe-gold text-keroluxe-black p-1.5 rounded-full cursor-pointer hover:bg-keroluxe-rose-gold transition-colors">
                         <Edit3 size={16} />
                         <Input id="avatar-upload" type="file" accept="image/*" onChange={handleAvatarChange} className="sr-only" />
                       </Label>
                    )}
                  </div>
                  <div className="flex-1 text-center sm:text-left">
                    {isEditing ? (
                      <>
                        <div className="mb-4">
                          <Label htmlFor="username" className="text-sm font-medium text-keroluxe-grey dark:text-neutral-300">Username</Label>
                          <Input type="text" name="username" id="username" value={profileData.username} onChange={handleInputChange} className="mt-1 bg-white dark:bg-neutral-700 border-keroluxe-gold/50 text-keroluxe-black dark:text-keroluxe-white" />
                        </div>
                        <div className="mb-4">
                          <Label htmlFor="full_name" className="text-sm font-medium text-keroluxe-grey dark:text-neutral-300">Full Name</Label>
                          <Input type="text" name="full_name" id="full_name" value={profileData.full_name} onChange={handleInputChange} className="mt-1 bg-white dark:bg-neutral-700 border-keroluxe-gold/50 text-keroluxe-black dark:text-keroluxe-white" />
                        </div>
                      </>
                    ) : (
                      <>
                        <h2 className="text-2xl font-semibold text-keroluxe-black dark:text-keroluxe-white">{profileData.full_name || profileData.username}</h2>
                        <p className="text-keroluxe-grey dark:text-neutral-400">{user.email}</p>
                      </>
                    )}
                    <p className="text-xs text-keroluxe-grey dark:text-neutral-500 mt-1">Joined: {new Date(user.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
                {isEditing && (
                  <div className="flex justify-end">
                    <Button onClick={handleProfileUpdate} disabled={isUploading} className="btn-primary">
                      {isUploading ? <><Save className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="mr-2 h-4 w-4" /> Save Changes</>}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Links Card */}
            <Card className="bg-keroluxe-off-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/10">
              <CardHeader>
                <CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white">Quick Links</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button asChild variant="ghost" className="w-full justify-start text-keroluxe-black dark:text-keroluxe-white hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20 hover:text-keroluxe-gold">
                  <Link to="/profile/orders"><ShoppingBag className="mr-3 h-5 w-5 text-keroluxe-gold" /> My Orders</Link>
                </Button>
                <Button asChild variant="ghost" className="w-full justify-start text-keroluxe-black dark:text-keroluxe-white hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20 hover:text-keroluxe-gold">
                  <Link to="/wishlist"><Heart className="mr-3 h-5 w-5 text-keroluxe-gold" /> My Wishlist</Link>
                </Button>
                <Button asChild variant="ghost" className="w-full justify-start text-keroluxe-black dark:text-keroluxe-white hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20 hover:text-keroluxe-gold">
                  <Link to="/profile#settings"><Settings className="mr-3 h-5 w-5 text-keroluxe-gold" /> Account Settings</Link>
                </Button>
                 <Button asChild variant="ghost" className="w-full justify-start text-keroluxe-black dark:text-keroluxe-white hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20 hover:text-keroluxe-gold">
                  <Link to="/track-order"><User className="mr-3 h-5 w-5 text-keroluxe-gold" /> Track Order</Link>
                </Button>
              </CardContent>
            </Card>
          </div>

          <div id="settings" className="mt-12">
             <Card className="bg-keroluxe-off-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/10">
                <CardHeader>
                    <CardTitle className="text-2xl font-serif text-keroluxe-black dark:text-keroluxe-white">Account Settings</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-keroluxe-grey dark:text-neutral-400">Further account settings like address book, saved payment methods, and notification preferences will be available here soon.</p>
                </CardContent>
             </Card>
          </div>
        </motion.div>
      );
    };

    export default UserProfilePage;