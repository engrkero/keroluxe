import React from 'react';
    import { Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import HeroCarousel from '@/components/HeroCarousel';
    import ProductCard from '@/components/ProductCard';
    import { Button } from '@/components/ui/button';
    import { products } from '@/data/products';
    import { ArrowRight } from 'lucide-react';

    const HomePage = () => {
      const newArrivals = products.filter(p => p.labels && p.labels.includes('New Arrival')).slice(0, 4);
      const bestSellers = products.filter(p => p.labels && p.labels.includes('Bestseller')).slice(0, 6);

      const sectionVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
      };

      return (
        <div className="space-y-16 bg-background text-foreground">
          <HeroCarousel />

          <motion.section
            variants={sectionVariants}
            initial="hidden"
            animate="visible"
            className="text-center container mx-auto px-4"
          >
            <h1 className="text-4xl md:text-5xl font-bold font-serif text-keroluxe-gold mb-4">Welcome to KeroLuxe</h1>
            <p className="text-lg text-keroluxe-grey dark:text-keroluxe-off-white/80 max-w-2xl mx-auto">
              Discover timeless elegance and unparalleled comfort. Our curated collections blend luxury with everyday wearability.
            </p>
          </motion.section>

          <motion.section
            variants={sectionVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            className="container mx-auto px-4"
          >
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-semibold font-serif text-keroluxe-gold">New Arrivals</h2>
              <Button variant="link" asChild className="text-keroluxe-gold hover:text-keroluxe-dark-gold dark:text-keroluxe-gold dark:hover:text-keroluxe-off-white">
                <Link to="/new-arrivals">View All <ArrowRight className="ml-2 h-4 w-4" /></Link>
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
              {(newArrivals.length > 0 ? newArrivals : products.slice(0,4)).map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <ProductCard product={product} />
                </motion.div>
              ))}
            </div>
          </motion.section>

          <motion.section
            variants={sectionVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            className="bg-keroluxe-off-white dark:bg-neutral-800 p-8 md:p-12 rounded-lg shadow-xl container mx-auto"
          >
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-semibold font-serif text-keroluxe-gold">Best Sellers</h2>
              <Button variant="link" asChild className="text-keroluxe-gold hover:text-keroluxe-dark-gold dark:text-keroluxe-gold dark:hover:text-keroluxe-off-white">
                <Link to="/best-sellers">View All <ArrowRight className="ml-2 h-4 w-4" /></Link>
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 md:gap-8">
              {(bestSellers.length > 0 ? bestSellers : products.slice(0,3)).map((product, index) => (
                 <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <ProductCard product={product} />
                </motion.div>
              ))}
            </div>
            <div className="md:hidden mt-6 -mx-4 px-4 overflow-x-auto pb-4">
              <div className="flex space-x-4">
                {(bestSellers.length > 0 ? bestSellers : products.slice(0,6)).map((product) => (
                  <div key={product.id} className="min-w-[280px]">
                    <ProductCard product={product} />
                  </div>
                ))}
              </div>
            </div>
          </motion.section>

          <motion.section
            variants={sectionVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            className="py-12 container mx-auto px-4"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="text-center md:text-left">
                <h3 className="text-3xl font-semibold font-serif text-keroluxe-gold mb-4">Explore Nightwear Collection</h3>
                <p className="text-keroluxe-grey dark:text-keroluxe-off-white/80 mb-6">
                  Indulge in our exquisite range of nightwear, crafted for ultimate comfort and sophisticated style. Perfect for serene nights and leisurely mornings.
                </p>
                <Button size="lg" asChild className="btn-primary">
                  <Link to="/category/nightwears-female">Shop Nightwear</Link>
                </Button>
              </div>
              <div className="rounded-lg overflow-hidden shadow-xl aspect-video">
                <img  alt="Model in luxurious KeroLuxe nightwear" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1701017718943-996aa586e955" />
              </div>
            </div>
          </motion.section>

          <motion.section
            variants={sectionVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            className="py-12 bg-keroluxe-off-white dark:bg-neutral-800 rounded-lg shadow-xl container mx-auto"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="rounded-lg overflow-hidden shadow-xl aspect-video md:order-last">
                <img  alt="Unisex apparel by KeroLuxe" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1623683945420-f0f890b59b6b" />
              </div>
              <div className="text-center md:text-left md:order-first">
                <h3 className="text-3xl font-semibold font-serif text-keroluxe-gold mb-4">Shop Unisex Essentials</h3>
                <p className="text-keroluxe-grey dark:text-keroluxe-off-white/80 mb-6">
                  Discover versatile pieces designed for everyone. Our unisex collection offers comfort, style, and inclusivity.
                </p>
                <Button size="lg" asChild className="btn-primary">
                  <Link to="/category/t-shirts">Explore Unisex</Link>
                </Button>
              </div>
            </div>
          </motion.section>
        </div>
      );
    };

    export default HomePage;