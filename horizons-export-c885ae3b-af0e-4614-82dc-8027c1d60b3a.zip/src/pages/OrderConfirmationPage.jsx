import React, { useEffect } from 'react';
    import { Link, useLocation, useNavigate } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Separator } from '@/components/ui/separator';
    import { CheckCircle, ShoppingBag, Gift, Package } from 'lucide-react'; // Added Package icon

    const OrderConfirmationPage = () => {
      const location = useLocation();
      const navigate = useNavigate();
      const orderDetails = location.state?.orderDetails;

      useEffect(() => {
        if (!orderDetails) {
          // If no order details are passed, redirect to home or cart
          navigate('/');
        }
      }, [orderDetails, navigate]);

      if (!orderDetails) {
        return (
          <div className="container mx-auto py-12 text-center">
            <h1 className="text-2xl font-semibold text-keroluxe-black dark:text-keroluxe-white">Loading order details...</h1>
            <p className="text-keroluxe-grey dark:text-neutral-400">If you are not redirected, please <Link to="/" className="text-keroluxe-gold hover:underline">click here</Link>.</p>
          </div>
        );
      }

      const { cart, formData } = orderDetails;
      const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
      const shippingCost = subtotal > 25000 || subtotal === 0 ? 0 : 2500;
      const total = subtotal + shippingCost;
      // Generate a mock order ID
      const orderId = `KLX${Math.random().toString(36).substr(2, 9).toUpperCase()}`;


      return (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, type: "spring" }}
          className="container mx-auto py-12 px-4 flex flex-col items-center"
        >
          <Card className="w-full max-w-2xl bg-keroluxe-white dark:bg-neutral-800 shadow-2xl overflow-hidden">
            <CardHeader className="bg-keroluxe-gold text-keroluxe-black p-8 text-center relative">
              <div className="absolute top-4 left-4 text-4xl animate-celebrate-wiggle">🎉</div>
              <div className="absolute top-8 right-6 text-3xl animate-celebrate-wiggle animation-delay-200">🎊</div>
              <CheckCircle className="mx-auto h-20 w-20 mb-4" />
              <CardTitle className="text-3xl md:text-4xl font-bold font-serif">Thank You For Your Order!</CardTitle>
              <p className="text-lg mt-2">Your KeroLuxe treasures are on their way!</p>
              <div className="absolute bottom-4 left-6 text-3xl animate-celebrate-wiggle animation-delay-400">🥳</div>
              <div className="absolute bottom-8 right-4 text-4xl animate-celebrate-wiggle animation-delay-600">🎁</div>
            </CardHeader>
            <CardContent className="p-6 md:p-8 space-y-6 text-keroluxe-black dark:text-keroluxe-off-white">
              <p className="text-center text-lg">Your Order ID: <span className="font-semibold text-keroluxe-gold">{orderId}</span></p>
              <p className="text-center text-keroluxe-grey dark:text-neutral-400">
                We've received your order and are getting it ready. You'll receive an email confirmation shortly with tracking details.
              </p>
              
              <Separator className="bg-keroluxe-grey/20 dark:bg-neutral-700" />

              <div>
                <h3 className="text-xl font-semibold mb-3 font-serif flex items-center"><Package className="mr-2 h-6 w-6 text-keroluxe-gold"/>Order Summary</h3>
                {cart.map(item => (
                  <div key={`${item.id}-${item.selectedSize}-${item.selectedColor}`} className="flex justify-between items-center py-2 border-b border-keroluxe-off-white dark:border-neutral-700 last:border-b-0">
                    <div>
                      <p className="font-medium">{item.name} (x{item.quantity})</p>
                      <p className="text-sm text-keroluxe-grey dark:text-neutral-400">
                        {item.selectedSize && `Size: ${item.selectedSize}`} {item.selectedColor && ` Color: ${item.selectedColor}`}
                      </p>
                    </div>
                    <p className="font-medium">₦{(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                ))}
                <div className="mt-3 pt-3 border-t border-keroluxe-grey/30 dark:border-neutral-600">
                    <div className="flex justify-between"><span className="text-keroluxe-grey dark:text-neutral-400">Subtotal:</span> <span>₦{subtotal.toFixed(2)}</span></div>
                    <div className="flex justify-between"><span className="text-keroluxe-grey dark:text-neutral-400">Shipping:</span> <span>{shippingCost === 0 ? 'Free' : `₦${shippingCost.toFixed(2)}`}</span></div>
                    <div className="flex justify-between font-bold text-lg mt-1"><span >Total:</span> <span>₦{total.toFixed(2)}</span></div>
                </div>
              </div>

              <Separator className="bg-keroluxe-grey/20 dark:bg-neutral-700" />
              
              <div>
                <h3 className="text-xl font-semibold mb-2 font-serif">Shipping To:</h3>
                <p>{formData.firstName} {formData.lastName}</p>
                <p>{formData.address}{formData.apartment ? `, ${formData.apartment}` : ''}</p>
                <p>{formData.city}, {formData.state} {formData.zipCode}</p>
                <p>{formData.country}</p>
                <p>Email: {formData.email}</p>
                 {formData.phone && <p>Phone: {formData.phone}</p>}
              </div>

              <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" className="bg-keroluxe-black text-keroluxe-white hover:bg-keroluxe-gold hover:text-keroluxe-black dark:bg-keroluxe-gold dark:text-keroluxe-black dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black">
                  <Link to="/">Continue Shopping</Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="border-keroluxe-gold text-keroluxe-gold hover:bg-keroluxe-gold hover:text-keroluxe-black dark:hover:text-keroluxe-black">
                  <Link to="/track-order">Track Your Order</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      );
    };

    export default OrderConfirmationPage;