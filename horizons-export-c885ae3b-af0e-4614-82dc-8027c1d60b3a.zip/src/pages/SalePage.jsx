import React, { useState, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { products as allProducts, categories } from '@/data/products';
    import ProductCard from '@/components/ProductCard';
    import { Slider } from '@/components/ui/slider';
    import { Checkbox } from '@/components/ui/checkbox';
    import { Label } from '@/components/ui/label';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Filter, Search, XCircle, Percent } from 'lucide-react';

    const SalePage = () => {
      const saleProducts = useMemo(() => 
        allProducts.map(p => ({...p, originalPrice: p.price, price: parseFloat((p.price * (1 - (Math.random() * 0.3 + 0.1))).toFixed(2)) })) // 10-40% off
        .sort((a,b) => (a.originalPrice - a.price) / a.originalPrice > (b.originalPrice - b.price) / b.originalPrice ? -1 : 1) // Sort by discount %
        .slice(0, 12), // Get top 12 discounted items
      []);

      const [filteredProducts, setFilteredProducts] = useState(saleProducts);
      const [priceRange, setPriceRange] = useState([0, Math.max(...saleProducts.map(p => p.price), 200)]);
      const [selectedCategories, setSelectedCategories] = useState([]);
      const [searchTerm, setSearchTerm] = useState('');
      const [sortOption, setSortOption] = useState('discount-desc');

      const maxPrice = useMemo(() => Math.max(...saleProducts.map(p => p.price), 200), [saleProducts]);

      React.useEffect(() => {
        let tempProducts = [...saleProducts];

        // Filter by search term
        if (searchTerm) {
          tempProducts = tempProducts.filter(product =>
            product.name.toLowerCase().includes(searchTerm.toLowerCase())
          );
        }

        // Filter by category
        if (selectedCategories.length > 0) {
          tempProducts = tempProducts.filter(product =>
            selectedCategories.includes(product.category)
          );
        }

        // Filter by price range
        tempProducts = tempProducts.filter(
          product => product.price >= priceRange[0] && product.price <= priceRange[1]
        );
        
        // Sorting
        switch (sortOption) {
          case 'price-asc':
            tempProducts.sort((a, b) => a.price - b.price);
            break;
          case 'price-desc':
            tempProducts.sort((a, b) => b.price - a.price);
            break;
          case 'name-asc':
            tempProducts.sort((a, b) => a.name.localeCompare(b.name));
            break;
          case 'discount-desc':
             tempProducts.sort((a,b) => (a.originalPrice - a.price) / a.originalPrice > (b.originalPrice - b.price) / b.originalPrice ? -1 : 1);
            break;
          default:
            break;
        }


        setFilteredProducts(tempProducts);
      }, [searchTerm, selectedCategories, priceRange, sortOption, saleProducts]);


      const handleCategoryChange = (categoryName) => {
        setSelectedCategories(prev =>
          prev.includes(categoryName)
            ? prev.filter(c => c !== categoryName)
            : [...prev, categoryName]
        );
      };
      
      const clearFilters = () => {
        setSearchTerm('');
        setSelectedCategories([]);
        setPriceRange([0, maxPrice]);
        setSortOption('discount-desc');
      };

      return (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-8 px-4"
        >
          <header className="text-center mb-10">
            <Percent className="h-16 w-16 text-keroluxe-gold mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold font-serif text-keroluxe-gold">KeroLuxe Sale</h1>
            <p className="text-lg text-keroluxe-black dark:text-keroluxe-white mt-2">Don't miss out on these amazing deals!</p>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Filters Sidebar */}
            <aside className="md:col-span-1 space-y-8 p-6 bg-keroluxe-white dark:bg-neutral-800 rounded-lg shadow-xl border-keroluxe-grey/20 dark:border-neutral-700 self-start sticky top-24">
              <h2 className="text-2xl font-semibold font-serif text-keroluxe-black dark:text-keroluxe-white flex items-center">
                <Filter className="mr-2 h-6 w-6 text-keroluxe-gold" /> Filters
              </h2>

              {/* Search Filter */}
              <div>
                <Label htmlFor="search-sale" className="text-md font-medium text-keroluxe-black dark:text-keroluxe-off-white">Search</Label>
                <div className="relative mt-1">
                  <Input
                    type="text"
                    id="search-sale"
                    placeholder="Search sale items..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-keroluxe-grey dark:text-neutral-400" />
                </div>
              </div>
              
              {/* Category Filter */}
              <div>
                <h3 className="text-lg font-medium text-keroluxe-black dark:text-keroluxe-off-white mb-2">Categories</h3>
                <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                  {categories.map(category => (
                    <div key={category.slug} className="flex items-center space-x-2">
                      <Checkbox
                        id={`cat-${category.slug}-sale`}
                        checked={selectedCategories.includes(category.name)}
                        onCheckedChange={() => handleCategoryChange(category.name)}
                        className="border-keroluxe-grey/50 dark:border-neutral-500 data-[state=checked]:bg-keroluxe-gold data-[state=checked]:border-keroluxe-gold data-[state=checked]:text-keroluxe-black"
                      />
                      <Label htmlFor={`cat-${category.slug}-sale`} className="text-sm text-keroluxe-black dark:text-keroluxe-off-white cursor-pointer">{category.name}</Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Price Range Filter */}
              <div>
                <h3 className="text-lg font-medium text-keroluxe-black dark:text-keroluxe-off-white mb-2">Price Range</h3>
                <Slider
                  min={0}
                  max={maxPrice}
                  step={10}
                  value={priceRange}
                  onValueChange={setPriceRange}
                  className="[&>span:first-child]:h-1 [&>span:first-child]:bg-keroluxe-grey/30 dark:[&>span:first-child]:bg-neutral-600 [&_[role=slider]]:bg-keroluxe-gold [&_[role=slider]]:border-keroluxe-gold/50"
                />
                <div className="flex justify-between text-sm text-keroluxe-grey dark:text-neutral-400 mt-2">
                  <span>₦{priceRange[0]}</span>
                  <span>₦{priceRange[1]}</span>
                </div>
              </div>
              
              {/* Sort Options */}
              <div>
                <Label htmlFor="sort-orders" className="text-md font-medium text-keroluxe-black dark:text-keroluxe-off-white">Sort by</Label>
                <Select value={sortOption} onValueChange={setSortOption}>
                    <SelectTrigger id="sort-orders" className="w-full mt-1 bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 text-keroluxe-black dark:text-keroluxe-off-white focus:border-keroluxe-gold dark:focus:border-keroluxe-gold">
                        <SelectValue placeholder="Select sorting" />
                    </SelectTrigger>
                    <SelectContent className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600">
                        <SelectItem value="discount-desc" className="text-keroluxe-black dark:text-keroluxe-off-white hover:!bg-keroluxe-gold/10 dark:hover:!bg-keroluxe-gold/20">Best Discount</SelectItem>
                        <SelectItem value="price-asc" className="text-keroluxe-black dark:text-keroluxe-off-white hover:!bg-keroluxe-gold/10 dark:hover:!bg-keroluxe-gold/20">Price: Low to High</SelectItem>
                        <SelectItem value="price-desc" className="text-keroluxe-black dark:text-keroluxe-off-white hover:!bg-keroluxe-gold/10 dark:hover:!bg-keroluxe-gold/20">Price: High to Low</SelectItem>
                        <SelectItem value="name-asc" className="text-keroluxe-black dark:text-keroluxe-off-white hover:!bg-keroluxe-gold/10 dark:hover:!bg-keroluxe-gold/20">Name: A to Z</SelectItem>
                    </SelectContent>
                </Select>
              </div>

              <Button onClick={clearFilters} variant="outline" className="w-full btn-outline-gold">
                <XCircle className="mr-2 h-4 w-4"/> Clear All Filters
              </Button>
            </aside>

            {/* Products Grid */}
            <main className="md:col-span-3">
              {filteredProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                  {filteredProducts.map(product => (
                    <ProductCard key={product.id} product={product} isSale={true}/>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <img  alt="No sale products found" src="https://images.unsplash.com/photo-1580377968131-bac075a3e7ab?w=500" className="mx-auto h-48 w-48 opacity-60 mb-4 rounded-lg" />
                  <h2 className="text-2xl font-semibold text-keroluxe-black dark:text-keroluxe-white mb-2">No Products Found</h2>
                  <p className="text-keroluxe-grey dark:text-neutral-400">Try adjusting your filters or check back later for more sale items!</p>
                </div>
              )}
            </main>
          </div>
        </motion.div>
      );
    };

    export default SalePage;
