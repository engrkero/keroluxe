import React from 'react';
    import { motion } from 'framer-motion';
    import { Ruler, Scaling, Info, Link as LinkIcon } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { cn } from '@/lib/utils';
    import { Link } from 'react-router-dom';

    const SizeGuidePage = () => {
      const generalTips = [
        "All measurements are in centimeters (cm) and inches (in) for approximation.",
        "Measure yourself directly on your body, not over tight clothing.",
        "If your measurements fall between two sizes, consider the desired fit: choose the smaller size for a tighter fit or the larger size for a looser fit.",
        "Bale/Vintage items are often unique; pay close attention to any provided specific measurements on the product page.",
        "These are general guidelines. Some brands or styles may vary. Always check product-specific size charts if available."
      ];

      const measurementGuides = [
        { title: "Bust/Chest", description: "Measure around the fullest part of your bust/chest, keeping the tape measure horizontal and snug but not tight." },
        { title: "Waist", description: "Measure around your natural waistline, which is typically the narrowest part of your torso, above your navel and below your rib cage." },
        { title: "Hips", description: "Stand with your feet together and measure around the fullest part of your hips and seat." },
        { title: "Inseam (Trousers/Jeans/Shorts)", description: "Measure from the top of your inner thigh (crotch) down to your desired D or ankle bone for trousers, or mid-thigh/knee for shorts." },
        { title: "Sleeve Length (Shirts)", description: "With your arm slightly bent, measure from the center back of your neck, across your shoulder, and down your arm to your wrist bone." },
        { title: "Shoulder Width (Shirts/Tops)", description: "Measure across your back from the tip of one shoulder to the tip of the other." }
      ];

      const sizeCharts = {
        unisexTops: {
          name: "Unisex Tops (T-Shirts, Shirts)",
          headers: ["Size", "Chest (cm)", "Chest (in)", "Length (cm)", "Length (in)"],
          data: [
            ["XS", "86-91", "34-36", "66-69", "26-27"],
            ["S", "91-96", "36-38", "69-71", "27-28"],
            ["M", "96-101", "38-40", "71-74", "28-29"],
            ["L", "101-106", "40-42", "74-76", "29-30"],
            ["XL", "106-111", "42-44", "76-79", "30-31"],
            ["XXL", "111-116", "44-46", "79-81", "31-32"]
          ]
        },
        femaleNightwear: {
          name: "Female Nightwear",
          headers: ["Size", "UK Equiv.", "Bust (cm)", "Bust (in)", "Waist (cm)", "Waist (in)", "Hips (cm)", "Hips (in)"],
          data: [
            ["S", "8-10", "82-87", "32-34", "65-70", "25.5-27.5", "90-95", "35.5-37.5"],
            ["M", "12-14", "88-93", "34.5-36.5", "71-76", "28-30", "96-101", "38-40"],
            ["L", "16-18", "94-100", "37-39.5", "77-83", "30.5-32.5", "102-108", "40-42.5"],
            ["XL", "20-22", "101-108", "40-42.5", "84-91", "33-36", "109-116", "43-45.5"]
          ]
        },
        maleUnderwear: {
          name: "Male Underwear",
          headers: ["Size", "Waist (cm)", "Waist (in)"],
          data: [
            ["S", "71-76", "28-30"],
            ["M", "81-86", "32-34"],
            ["L", "91-97", "36-38"],
            ["XL", "102-107", "40-42"]
          ]
        },
        unisexBottoms: {
            name: "Unisex Bottoms (Trousers, Shorts, Jeans)",
            headers: ["Size", "Waist (cm)", "Waist (in)", "Hip (cm)", "Hip (in)", "Inseam (cm)", "Inseam (in)"],
            data: [
              ["XS", "66-71", "26-28", "89-94", "35-37", "76-79", "30-31"],
              ["S", "72-77", "28-30", "95-100", "37.5-39.5", "79-81", "31-32"],
              ["M", "78-83", "31-33", "101-106", "40-42", "81-83", "32-33"],
              ["L", "84-89", "33-35", "107-112", "42-44", "83-85", "33-33.5"],
              ["XL", "90-95", "35.5-37.5", "113-118", "44.5-46.5", "85-87", "33.5-34"]
            ]
        },
        baleGeneral: {
          name: "Bale Items (Vintage/Used)",
          headers: ["Note"],
          data: [
            ["Bale items are unique and often don't conform to standard modern sizing."],
            ["Always check the product description for specific measurements (e.g., pit-to-pit, waist flat, length)."],
            ["Compare these measurements to a similar garment you own that fits well."],
            ["Don't hesitate to contact us if you need more sizing details for a specific bale item."]
          ],
          isNote: true
        }
      };

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-12 px-4"
        >
          <header className="text-center mb-12">
            <Ruler className="h-16 w-16 text-keroluxe-gold mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white mb-4">Size Guide</h1>
            <p className="text-lg text-keroluxe-grey dark:text-neutral-400 max-w-3xl mx-auto">
              Find your perfect KeroLuxe fit. Our guides help you measure accurately for clothing, including unique bale items.
            </p>
          </header>

          <Card className="mb-10 bg-keroluxe-off-white dark:bg-neutral-800 border-keroluxe-gold/30 shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl font-serif text-keroluxe-black dark:text-keroluxe-white flex items-center">
                <Info className="mr-3 h-7 w-7 text-keroluxe-gold" />
                Important Sizing Notes
              </CardTitle>
            </CardHeader>
            <CardContent className="text-keroluxe-black dark:text-keroluxe-off-white/90 space-y-3">
              {generalTips.map((tip, index) => (
                <p key={index} className="flex items-start text-sm sm:text-base">
                  <Scaling className="h-5 w-5 mr-2.5 mt-0.5 flex-shrink-0 text-keroluxe-gold/80" />
                  {tip}
                </p>
              ))}
            </CardContent>
          </Card>
          
          <Card className="mb-10 bg-keroluxe-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/30">
            <CardHeader>
                <CardTitle className="text-2xl font-serif text-keroluxe-black dark:text-keroluxe-white">How to Measure Yourself</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6 text-keroluxe-grey dark:text-neutral-300">
                {measurementGuides.map(guide => (
                    <div key={guide.title}>
                        <h3 className="font-semibold text-lg text-keroluxe-black dark:text-keroluxe-white mb-1.5">{guide.title}</h3>
                        <p className="text-sm sm:text-base leading-relaxed">{guide.description}</p>
                    </div>
                ))}
            </CardContent>
          </Card>


          <Tabs defaultValue="unisexTops" className="w-full">
            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 bg-keroluxe-off-white dark:bg-neutral-800 p-1.5 rounded-lg mb-6 border border-keroluxe-grey/30 dark:border-neutral-700 shadow-sm">
              {Object.keys(sizeCharts).map(key => (
                <TabsTrigger 
                  key={key} 
                  value={key} 
                  className={cn(
                    "px-3 py-2.5 rounded-md transition-all duration-200 ease-out text-xs sm:text-sm font-medium focus-visible:ring-2 focus-visible:ring-keroluxe-gold focus-visible:ring-offset-2 focus-visible:ring-offset-keroluxe-off-white dark:focus-visible:ring-offset-neutral-800",
                    "data-[state=active]:bg-keroluxe-gold data-[state=active]:text-keroluxe-black data-[state=active]:shadow-lg data-[state=active]:transform data-[state=active]:scale-105",
                    "text-keroluxe-grey dark:text-neutral-300 hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20 hover:text-keroluxe-black dark:hover:text-keroluxe-white"
                  )}
                >
                  {sizeCharts[key].name.split('(')[0].trim()}
                </TabsTrigger>
              ))}
            </TabsList>

            {Object.entries(sizeCharts).map(([key, chart]) => (
              <TabsContent key={key} value={key}>
                <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/30 overflow-hidden">
                  <CardHeader>
                    <CardTitle className="text-2xl font-serif text-keroluxe-black dark:text-keroluxe-white">{chart.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="overflow-x-auto">
                    {chart.isNote ? (
                      <div className="prose dark:prose-invert max-w-none text-keroluxe-black dark:text-keroluxe-off-white">
                        {chart.data.map((row, idx) => <p key={idx}>{row[0]}</p>)}
                      </div>
                    ) : (
                    <Table>
                      <TableHeader>
                        <TableRow className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b border-keroluxe-grey/20 dark:border-neutral-700">
                          {chart.headers.map(header => <TableHead key={header} className="text-keroluxe-black dark:text-keroluxe-white font-semibold whitespace-nowrap px-3 py-2 text-xs sm:text-sm">{header}</TableHead>)}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {chart.data.map((row, rowIndex) => (
                          <TableRow key={rowIndex} className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b border-keroluxe-grey/10 dark:border-neutral-700/50 last:border-b-0">
                            {row.map((cell, cellIndex) => <TableCell key={cellIndex} className="text-keroluxe-grey dark:text-neutral-300 whitespace-nowrap px-3 py-2 text-xs sm:text-sm">{cell}</TableCell>)}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
          
          <motion.div 
            initial={{ opacity:0 }} whileInView={{ opacity:1 }} viewport={{once: true}} transition={{delay:0.4, duration:0.5}}
            className="mt-12 text-center text-sm text-keroluxe-grey dark:text-neutral-400 p-6 bg-keroluxe-off-white dark:bg-neutral-800 rounded-lg shadow border border-keroluxe-gold/20"
          >
            <p className="flex items-center justify-center">
              <LinkIcon className="h-4 w-4 mr-2 text-keroluxe-gold" />
              Still unsure? For specific item queries or further assistance with sizing, please don't hesitate to <Link to="/contact" className="text-keroluxe-gold hover:underline font-medium ml-1">contact our support team</Link>.
            </p>
          </motion.div>

        </motion.div>
      );
    };

    export default SizeGuidePage;