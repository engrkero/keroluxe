import React, { useState, useEffect } from 'react';
    import { useNavigate } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Progress } from '@/components/ui/progress';
    import { useAppContext } from '@/contexts/AppContext';
    import DeliveryInfoStep from '@/components/checkout/DeliveryInfoStep';
    import PaymentStep from '@/components/checkout/PaymentStep';
    import ReviewOrderStep from '@/components/checkout/ReviewOrderStep';
    import OrderSummaryCard from '@/components/checkout/OrderSummaryCard';
    import { useToast } from '@/components/ui/use-toast';
    import { ShoppingBag, Truck, CreditCard, CheckCircle, AlertTriangle } from 'lucide-react';

    const steps = [
      { id: 1, name: 'Delivery Information', icon: <Truck className="h-5 w-5" /> },
      { id: 2, name: 'Payment Method', icon: <CreditCard className="h-5 w-5" /> },
      { id: 3, name: 'Review Order', icon: <CheckCircle className="h-5 w-5" /> },
    ];

    const CheckoutPage = () => {
      const { cart, clearCart, user, userProfile, supabase, fetchUserProfile } = useAppContext();
      const navigate = useNavigate();
      const { toast } = useToast();
      const [currentStep, setCurrentStep] = useState(1);
      const [isProcessing, setIsProcessing] = useState(false);
      
      const [formData, setFormData] = useState({
        email: '',
        firstName: '',
        lastName: '',
        address: '',
        apartment: '',
        city: '',
        state: '',
        zipCode: '',
        phone: '',
        saveInfo: false,
        paymentMethod: 'creditCard',
        cardName: '',
        cardNumber: '',
        cardExpiry: '',
        cardCVC: '',
      });

      useEffect(() => {
        if (cart.length === 0 && !isProcessing) {
          toast({ title: "Your cart is empty!", description: "Please add items to your cart before proceeding to checkout.", variant: "destructive" });
          navigate('/');
        }
        if (user && userProfile) {
          setFormData(prev => ({ 
            ...prev, 
            email: user.email || '',
            firstName: userProfile.full_name?.split(' ')[0] || '',
            lastName: userProfile.full_name?.split(' ').slice(1).join(' ') || '',
            // You might want to load address from userProfile if available
            // address: userProfile.address || '', 
            // phone: userProfile.phone || '',
          }));
        } else if (user && !userProfile) {
           setFormData(prev => ({ ...prev, email: user.email || '' }));
        }
      }, [cart, navigate, toast, user, userProfile, isProcessing]);

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
      };
      
      const handlePaymentMethodChange = (value) => {
        setFormData(prev => ({ ...prev, paymentMethod: value }));
      };

      const validateStep = () => {
        if (currentStep === 1) {
          const { email, firstName, lastName, address, city, state, zipCode } = formData;
          if (!email || !firstName || !lastName || !address || !city || !state || !zipCode) {
            toast({ title: "Missing Delivery Information", description: "Please fill all required delivery fields.", variant: "destructive" });
            return false;
          }
        }
        if (currentStep === 2 && formData.paymentMethod === 'creditCard') {
          const { cardName, cardNumber, cardExpiry, cardCVC } = formData;
          if (!cardName || !cardNumber || !cardExpiry || !cardCVC) {
            toast({ title: "Missing Payment Information", description: "Please fill all card details.", variant: "destructive" });
            return false;
          }
        }
        return true;
      };

      const nextStep = () => {
        if (validateStep()) {
          setCurrentStep(prev => Math.min(prev + 1, steps.length));
        }
      };

      const prevStep = () => setCurrentStep(prev => Math.max(prev - 1, 1));

      const totalAmount = cart.reduce((sum, item) => {
        const price = Number(item.price);
        const quantity = Number(item.quantity);
        return sum + (isNaN(price) || isNaN(quantity) ? 0 : price * quantity);
      }, 0);

      const shippingCost = totalAmount > 25000 || totalAmount === 0 ? 0 : 2500;
      const grandTotal = totalAmount + shippingCost;

      const handleSaveInfo = async () => {
        if (!user || !formData.saveInfo) return;

        console.log("Function Tracking: Attempting to save delivery info for user", user.id);
        const profileUpdates = {
            id: user.id,
            full_name: `${formData.firstName} ${formData.lastName}`,
            // Potentially save address parts to a structured address field in profiles
            // Or a dedicated 'addresses' table if user can have multiple.
            // For now, just logging.
            // address_line1: formData.address,
            // city: formData.city,
            // state: formData.state,
            // zip_code: formData.zipCode,
            // phone: formData.phone,
            updated_at: new Date(),
        };
        
        const { error } = await supabase.from('profiles').upsert(profileUpdates);
        if (error) {
            toast({ title: "Failed to Save Info", description: error.message, variant: "destructive" });
        } else {
            toast({ title: "Information Saved", description: "Your delivery information has been updated in your profile." });
            fetchUserProfile(user.id); // Re-fetch to update context
        }
      };


      const handlePlaceOrder = async () => {
        if (!validateStep()) return;
        
        if (formData.saveInfo) {
            await handleSaveInfo(); 
        }

        setIsProcessing(true);
        console.log("Function Tracking: Place order initiated", formData);

        if (!user) {
          toast({ title: "Authentication Error", description: "You must be logged in to place an order.", variant: "destructive" });
          setIsProcessing(false);
          navigate('/login');
          return;
        }

        try {
          const shippingAddress = {
            fullName: `${formData.firstName} ${formData.lastName}`,
            address: formData.address,
            apartment: formData.apartment,
            city: formData.city,
            state: formData.state,
            zipCode: formData.zipCode,
            phone: formData.phone,
          };

          const { data: orderData, error: orderError } = await supabase
            .from('orders')
            .insert({
              user_id: user.id,
              total_amount: grandTotal,
              status: 'Pending',
              shipping_address: shippingAddress,
              payment_method: formData.paymentMethod,
              payment_status: 'Pending',
            })
            .select()
            .single();

          if (orderError) throw orderError;

          const orderItemsData = cart.map(item => ({
            order_id: orderData.id,
            product_id: item.id,
            seller_id: item.seller_id || null,
            quantity: Number(item.quantity),
            price_at_purchase: Number(item.price),
          }));

          const { error: orderItemsError } = await supabase
            .from('order_items')
            .insert(orderItemsData);

          if (orderItemsError) throw orderItemsError;
          
          await new Promise(resolve => setTimeout(resolve, 1500)); 

          const { error: updateOrderError } = await supabase
            .from('orders')
            .update({ status: 'Processing', payment_status: 'Paid' })
            .eq('id', orderData.id);

          if (updateOrderError) throw updateOrderError;

          console.log("Function Tracking: Order placed successfully", orderData);
          toast({
            title: "Order Placed Successfully!",
            description: `Your order #${orderData.id} has been confirmed.`,
            className: "bg-keroluxe-gold text-keroluxe-black dark:bg-keroluxe-gold dark:text-keroluxe-black",
          });
          clearCart();
          navigate('/order-confirmation', { state: { orderId: orderData.id, orderDetails: { ...orderData, items: cart, grandTotal } } });

        } catch (error) {
          console.error("Error placing order:", error);
          toast({ title: "Order Placement Failed", description: error.message || "An unexpected error occurred.", variant: "destructive" });
        } finally {
          setIsProcessing(false);
        }
      };

      const progressPercentage = (currentStep / steps.length) * 100;

      return (
        <div className="min-h-screen bg-keroluxe-off-white dark:bg-neutral-900 py-8 px-4 md:px-8 text-keroluxe-black dark:text-keroluxe-white">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="container mx-auto max-w-5xl"
          >
            <header className="text-center mb-10">
              <ShoppingBag className="h-16 w-16 text-keroluxe-gold mx-auto mb-4" />
              <h1 className="text-4xl md:text-5xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Secure Checkout</h1>
              <p className="text-lg text-keroluxe-grey dark:text-neutral-400 mt-2">Complete your purchase with confidence.</p>
            </header>

            <div className="mb-8 px-4">
              <Progress value={progressPercentage} className="w-full h-3 bg-keroluxe-gold/20 [&>div]:bg-keroluxe-gold" />
              <ol className="mt-3 grid grid-cols-3 text-xs font-medium text-keroluxe-grey dark:text-neutral-500">
                {steps.map(step => (
                  <li key={step.id} className={`flex items-center justify-start sm:justify-center ${currentStep >= step.id ? 'text-keroluxe-gold dark:text-keroluxe-gold' : ''} ${step.id === 2 ? 'sm:text-center' : ''} ${step.id === 3 ? 'sm:text-right' : ''}`}>
                    <span className={`mr-2 sm:hidden ${currentStep >= step.id ? 'text-keroluxe-gold' : 'text-keroluxe-grey dark:text-neutral-500'}`}> {React.cloneElement(step.icon, { className: `h-4 w-4 ${currentStep >= step.id ? 'text-keroluxe-gold' : 'text-keroluxe-grey dark:text-neutral-500'}` })} </span>
                    <span className="hidden sm:inline mr-1.5"> {React.cloneElement(step.icon, { className: `h-4 w-4 ${currentStep >= step.id ? 'text-keroluxe-gold' : 'text-keroluxe-grey dark:text-neutral-500'}` })} </span>
                    {step.name}
                  </li>
                ))}
              </ol>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 bg-keroluxe-white dark:bg-neutral-800 p-6 md:p-8 rounded-xl shadow-xl border border-keroluxe-gold/10">
                {currentStep === 1 && <DeliveryInfoStep formData={formData} handleInputChange={handleInputChange} setFormData={setFormData} />}
                {currentStep === 2 && <PaymentStep formData={formData} handleInputChange={handleInputChange} handlePaymentMethodChange={handlePaymentMethodChange} />}
                {currentStep === 3 && <ReviewOrderStep formData={formData} cart={cart} totalAmount={totalAmount} shippingCost={shippingCost} grandTotal={grandTotal} />}
                
                <div className="mt-8 flex justify-between items-center">
                  <Button variant="outline" onClick={prevStep} disabled={currentStep === 1 || isProcessing} className="btn-outline-gold">
                    Previous
                  </Button>
                  {currentStep < steps.length ? (
                    <Button onClick={nextStep} disabled={isProcessing} className="btn-primary">
                      Next: {steps[currentStep].name}
                    </Button>
                  ) : (
                    <Button onClick={handlePlaceOrder} disabled={isProcessing || cart.length === 0} className="btn-primary">
                      {isProcessing ? 'Processing Order...' : 'Place Order'}
                    </Button>
                  )}
                </div>
              </div>

              <div className="lg:col-span-1">
                <OrderSummaryCard cart={cart} totalAmount={totalAmount} shippingCost={shippingCost} grandTotal={grandTotal} />
              </div>
            </div>
          </motion.div>
        </div>
      );
    };

    export default CheckoutPage;