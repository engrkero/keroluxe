import React from 'react';
    import { Link, useParams } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { MessageSquare, Construction, ArrowLeft } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

    const MessageSellerPage = () => {
      const { sellerId } = useParams(); // Potentially use sellerId if available

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-12 px-4 flex flex-col items-center text-center"
        >
          <Construction className="h-24 w-24 text-keroluxe-gold mb-8" />
          <h1 className="text-3xl md:text-4xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white mb-4">
            Message Seller {sellerId ? `(ID: ${sellerId})` : ''} - Coming Soon!
          </h1>
          <p className="text-lg text-keroluxe-grey dark:text-neutral-400 max-w-xl mb-8">
            We're working hard to bring you a seamless way to connect with our sellers. This feature is currently under construction.
          </p>
          <Card className="w-full max-w-md bg-keroluxe-off-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/30">
            <CardHeader>
              <CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white flex items-center justify-center">
                <MessageSquare className="mr-2 h-6 w-6 text-keroluxe-gold" />
                Stay Tuned!
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-keroluxe-grey dark:text-neutral-300">
                Soon you'll be able to ask questions, get product details, and more, directly from our trusted sellers.
              </p>
            </CardContent>
          </Card>
          <Button asChild variant="outline" className="mt-8 border-keroluxe-gold text-keroluxe-gold hover:bg-keroluxe-gold hover:text-keroluxe-black dark:hover:text-keroluxe-black">
            <Link to="/">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Go Back to Homepage
            </Link>
          </Button>
        </motion.div>
      );
    };

    export default MessageSellerPage;