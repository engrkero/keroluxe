import React from 'react';
    import { motion } from 'framer-motion';
    import { ShieldAlert, FileText, Database, LockKeyhole } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

    const PrivacyPolicyPage = () => {
      const sections = [
        {
          title: "Introduction",
          icon: <FileText className="h-8 w-8 text-keroluxe-gold" />,
          content: "Welcome to KeroLuxe. We are committed to protecting your personal information and your right to privacy. If you have any questions or concerns about our policy, or our practices with regards to your personal information, please contact us at privacy@keroluxe.com."
        },
        {
          title: "Information We Collect",
          icon: <Database className="h-8 w-8 text-keroluxe-gold" />,
          content: (
            <>
              <p className="mb-2">We collect personal information that you voluntarily provide to us when you register on the website, express an interest in obtaining information about us or our products and services, when you participate in activities on the website or otherwise when you contact us.</p>
              <p className="mb-2">The personal information that we collect depends on the context of your interactions with us and the website, the choices you make and the products and features you use. The personal information we collect may include the following:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Personal Information Provided by You: Names; phone numbers; email addresses; mailing addresses; usernames; passwords; contact preferences; billing addresses; debit/credit card numbers.</li>
                <li>For Sellers: In addition to the above, we may collect business information, bank account details (for payouts), and government-issued identification for verification purposes.</li>
                <li>Payment Data: We may collect data necessary to process your payment if you make purchases, such as your payment instrument number (such as a credit card number), and the security code associated with your payment instrument. All payment data is stored by our payment processor and you should review its privacy policies and contact the payment processor directly to respond to your questions.</li>
              </ul>
            </>
          )
        },
        {
          title: "How We Use Your Information",
          icon: <LockKeyhole className="h-8 w-8 text-keroluxe-gold" />,
          content: (
            <>
              <p className="mb-2">We use personal information collected via our website for a variety of business purposes described below. We process your personal information for these purposes in reliance on our legitimate business interests, in order to enter into or perform a contract with you, with your consent, and/or for compliance with our legal obligations. We indicate the specific processing grounds we rely on next to each purpose listed below.</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>To facilitate account creation and logon process (for users and sellers).</li>
                <li>To post testimonials (with your consent).</li>
                <li>Request feedback.</li>
                <li>To enable user-to-user and user-to-seller communications (with user consent).</li>
                <li>To manage user and seller accounts.</li>
                <li>To send administrative information to you.</li>
                <li>To protect our Services (e.g., for fraud monitoring and prevention, seller verification).</li>
                <li>To enforce our terms, conditions and policies for business purposes, to comply with legal and regulatory requirements or in connection with our contract.</li>
                <li>To respond to legal requests and prevent harm.</li>
                <li>Fulfill and manage your orders, including coordinating with sellers for items not sold directly by KeroLuxe.</li>
                <li>To deliver and facilitate delivery of services to the user.</li>
                <li>To respond to user inquiries/offer support to users.</li>
                <li>To send you marketing and promotional communications (with your consent).</li>
                <li>To process payments to sellers.</li>
              </ul>
            </>
          )
        },
        {
          title: "Sharing Your Information",
          content: "We only share information with your consent, to comply with laws, to provide you with services, to protect your rights, or to fulfill business obligations. This may include sharing necessary information with sellers for order fulfillment if you purchase from a third-party seller on our platform, or with payment processors for payouts to sellers. We may process or share your data that we hold based on the following legal basis: Consent, Legitimate Interests, Performance of a Contract, Legal Obligations."
        },
        {
          title: "Data Security",
          content: "We have implemented appropriate technical and organizational security measures designed to protect the security of any personal information we process. However, despite our safeguards and efforts to secure your information, no electronic transmission over the Internet or information storage technology can be guaranteed to be 100% secure."
        },
        {
          title: "Your Privacy Rights",
          content: "In some regions (like the European Economic Area), you have rights that allow you greater access to and control over your personal information. You may review, change, or terminate your account at any time. You can unsubscribe from our marketing email list at any time by clicking on the unsubscribe link in the emails that we send or by contacting us."
        },
        {
          title: "Policy Updates",
          content: "We may update this privacy policy from time to time. The updated version will be indicated by an updated “Revised” date and the updated version will be effective as soon as it is accessible. We encourage you to review this privacy policy frequently to be informed of how we are protecting your information."
        }
      ];

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-12 px-4 text-keroluxe-black dark:text-keroluxe-white"
        >
          <header className="text-center mb-12">
            <ShieldAlert className="h-16 w-16 text-keroluxe-gold mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold font-serif text-keroluxe-gold mb-4">Privacy Policy</h1>
            <p className="text-lg text-keroluxe-grey dark:text-keroluxe-off-white max-w-2xl mx-auto">
              Your privacy is important to us. This policy outlines how KeroLuxe collects, uses, and protects your personal information. Last Revised: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}.
            </p>
          </header>

          <div className="space-y-8">
            {sections.map((section, index) => (
              <motion.section 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.1 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
              >
                <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/20">
                  <CardHeader>
                    <div className="flex items-center">
                      {section.icon || <FileText className="h-8 w-8 text-keroluxe-gold" />}
                      <CardTitle className="ml-3 text-2xl md:text-3xl font-serif text-keroluxe-black dark:text-keroluxe-white">{section.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="prose prose-sm sm:prose-base max-w-none text-keroluxe-grey dark:text-neutral-300 leading-relaxed p-6">
                    {typeof section.content === 'string' ? <p>{section.content}</p> : section.content}
                  </CardContent>
                </Card>
              </motion.section>
            ))}
          </div>
        </motion.div>
      );
    };

    export default PrivacyPolicyPage;
