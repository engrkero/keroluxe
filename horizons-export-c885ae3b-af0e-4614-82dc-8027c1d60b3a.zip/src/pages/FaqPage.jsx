import React from 'react';
    import { motion } from 'framer-motion';
    import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
    import { HelpCircle, ShoppingCart, Truck, User, ShieldQuestion, Package } from 'lucide-react';
    import { Link } from 'react-router-dom';
    import { Button } from '@/components/ui/button';

    const FaqPage = () => {
      const faqData = [
        {
          category: "General",
          icon: <HelpCircle className="h-6 w-6 text-keroluxe-gold" />,
          questions: [
            { q: "What is KeroLuxe?", a: "KeroLuxe is a premium apparel brand specializing in luxurious and comfortable clothing, including nightwear, unisex essentials, and a curated selection of 'Bale (First Class)' items." },
            { q: "What are 'Bale (First Class)' items?", a: "'Bale (First Class)' items are high-quality, foreign-used clothing or bags, often referred to as Grade A thrift or vintage pieces. These are carefully selected for their excellent condition and style." },
            { q: "Where are you located?", a: "Our main operations are based in Lagos, Nigeria. We currently ship to various locations domestically and internationally." },
            { q: "How can I contact customer support?", a: "You can reach our customer support team via email at support@keroluxe.com or by visiting our <Link to='/contact' class='text-keroluxe-gold hover:underline'>Contact Us</Link> page." }
          ]
        },
        {
          category: "Orders & Products",
          icon: <ShoppingCart className="h-6 w-6 text-keroluxe-gold" />,
          questions: [
            { q: "How do I place an order?", a: "Simply browse our collections, select your desired items, choose your size and quantity (if applicable), and add them to your cart. Proceed to checkout to complete your purchase." },
            { q: "Can I modify or cancel my order after placing it?", a: "Once an order is placed, modifications or cancellations may be limited. Please contact our customer support as soon as possible for assistance." },
            { q: "What materials are your clothes made from?", a: "We use high-quality materials such as silk, cotton, linen, and premium blends for our new items. 'Bale' items will have varied compositions, typical of their original make." },
            { q: "How do I find the right size?", a: "Please refer to our <Link to='/size-guide' class='text-keroluxe-gold hover:underline'>Size Guide</Link> page for detailed measurements and fitting information for each category. For 'Bale' items, specific measurements will be provided if standard sizing doesn't apply." }
          ]
        },
        {
          category: "Shipping & Returns",
          icon: <Truck className="h-6 w-6 text-keroluxe-gold" />,
          questions: [
            { q: "What are your shipping options?", a: "We offer standard and express shipping. Details can be found on our <Link to='/shipping-returns' class='text-keroluxe-gold hover:underline'>Shipping & Returns</Link> page." },
            { q: "Do you ship internationally?", a: "Yes, we ship to select international destinations. Shipping costs and times vary by location." },
            { q: "What is your return policy?", a: "We accept returns within 14 days for eligible new items. 'Bale (First Class)' items are typically sold as-is and may have a different return policy; please check the product description or contact us. See our <Link to='/shipping-returns' class='text-keroluxe-gold hover:underline'>Shipping & Returns</Link> page for full details." }
          ]
        },
        {
          category: "Account & Security",
          icon: <User className="h-6 w-6 text-keroluxe-gold" />,
          questions: [
            { q: "Do I need an account to place an order?", a: "No, you can checkout as a guest. However, creating an account allows you to track orders, save addresses, and manage your wishlist." },
            { q: "Is my personal information secure?", a: "Yes, we take your privacy and security seriously. Please review our <Link to='/privacy-policy' class='text-keroluxe-gold hover:underline'>Privacy Policy</Link> for more information." }
          ]
        }
      ];

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-12 px-4"
        >
          <header className="text-center mb-12">
            <ShieldQuestion className="h-16 w-16 text-keroluxe-gold mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white mb-4">Frequently Asked Questions</h1>
            <p className="text-lg text-keroluxe-grey dark:text-neutral-400 max-w-2xl mx-auto">
              Find answers to common questions about KeroLuxe products, orders, shipping, and more.
            </p>
          </header>

          <div className="space-y-8">
            {faqData.map((categoryItem) => (
              <motion.section 
                key={categoryItem.category}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.5 }}
                className="bg-keroluxe-off-white dark:bg-neutral-800 p-6 md:p-8 rounded-xl shadow-xl border border-keroluxe-grey/20 dark:border-neutral-700"
              >
                <div className="flex items-center mb-6">
                  {React.cloneElement(categoryItem.icon, { className: "h-6 w-6 text-keroluxe-gold" })}
                  <h2 className="ml-3 text-2xl md:text-3xl font-semibold font-serif text-keroluxe-black dark:text-keroluxe-white">{categoryItem.category}</h2>
                </div>
                <Accordion type="single" collapsible className="w-full">
                  {categoryItem.questions.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${categoryItem.category}-${index}`} className="border-b border-keroluxe-grey/20 dark:border-neutral-700 last:border-b-0">
                      <AccordionTrigger className="text-left text-lg font-medium text-keroluxe-black dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold py-4">
                        {faq.q}
                      </AccordionTrigger>
                      <AccordionContent className="text-keroluxe-grey dark:text-neutral-300 prose prose-sm sm:prose-base pt-2 pb-4" dangerouslySetInnerHTML={{ __html: faq.a.replace(/class='text-keroluxe-vibrant-red hover:underline'/g, "class='text-keroluxe-gold hover:underline'") }} />
                    </AccordionItem>
                  ))}
                </Accordion>
              </motion.section>
            ))}
          </div>

          <motion.div 
            initial={{ opacity:0, y:30 }} whileInView={{ opacity:1, y:0 }} viewport={{once: true, amount:0.5}} transition={{delay: 0.5, duration:0.6}}
            className="mt-16 text-center p-8 bg-keroluxe-off-white dark:bg-neutral-800 rounded-lg shadow-lg border border-keroluxe-grey/20 dark:border-neutral-700"
          >
            <h2 className="text-2xl font-semibold text-keroluxe-black dark:text-keroluxe-white mb-3">Still have questions?</h2>
            <p className="text-keroluxe-grey dark:text-neutral-300 mb-6">Our customer support team is ready to assist you. Get in touch with us!</p>
            <Button asChild size="lg" className="bg-keroluxe-black text-keroluxe-white hover:bg-keroluxe-gold hover:text-keroluxe-black dark:bg-keroluxe-gold dark:text-keroluxe-black dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black">
              <Link to="/contact">Contact Support</Link>
            </Button>
          </motion.div>

        </motion.div>
      );
    };

    export default FaqPage;