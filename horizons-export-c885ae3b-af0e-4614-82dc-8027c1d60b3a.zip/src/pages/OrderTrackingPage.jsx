import React, { useState, useEffect } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Separator } from '@/components/ui/separator';
    import { PackageSearch, CheckCircle, Truck, Package, MapPin, AlertTriangle } from 'lucide-react';
    import { useAppContext } from '@/contexts/AppContext';
    import { useToast } from '@/components/ui/use-toast';

    const OrderTrackingPage = () => {
      const [orderIdInput, setOrderIdInput] = useState('');
      const [orderDetails, setOrderDetails] = useState(null);
      const [error, setError] = useState('');
      const [isLoading, setIsLoading] = useState(false);
      const { supabase, user } = useAppContext();
      const { toast } = useToast();

      const fetchOrderDetails = async (orderIdToFetch) => {
        setIsLoading(true);
        setError('');
        setOrderDetails(null);

        try {
          const { data: orderData, error: orderError } = await supabase
            .from('orders')
            .select(`
              *,
              order_items (
                quantity,
                price_at_purchase,
                products (
                  name,
                  images
                )
              )
            `)
            .eq('id', orderIdToFetch)
            // Optionally, ensure the user owns this order if not an admin
            // .eq('user_id', user.id) 
            .single();

          if (orderError || !orderData) {
            console.error("Order fetch error:", orderError);
            setError(`Order ID ${orderIdToFetch} not found or you do not have permission to view it.`);
            toast({ title: "Order Not Found", description: `Could not retrieve details for order ${orderIdToFetch}.`, variant: "destructive" });
            setOrderDetails(null);
            setIsLoading(false);
            return;
          }
          
          // Mocking history for now as it's not in the schema
          const mockHistory = [
            { status: 'Order Placed', date: new Date(orderData.created_at).toLocaleDateString(), location: 'Online Store' },
            { status: 'Processing', date: new Date(orderData.created_at).toLocaleDateString(), location: 'KeroLuxe Warehouse' },
          ];
          if (orderData.status === 'Shipped' || orderData.status === 'Delivered') {
            mockHistory.push({ status: 'Shipped', date: new Date(orderData.updated_at).toLocaleDateString(), location: 'KeroLuxe Dispatch Center' });
          }
           if (orderData.status === 'Delivered') {
            mockHistory.push({ status: 'Delivered', date: new Date(orderData.updated_at).toLocaleDateString(), location: 'Customer Address' });
          }

          setOrderDetails({ ...orderData, history: mockHistory });
          console.log("Function Tracking: Order details fetched for", orderIdToFetch);

        } catch (e) {
          console.error("Unexpected error fetching order:", e);
          setError('An unexpected error occurred while fetching your order.');
          toast({ title: "Error", description: "An unexpected error occurred.", variant: "destructive" });
        } finally {
          setIsLoading(false);
        }
      };
      
      const handleTrackOrder = (e) => {
        e.preventDefault();
        if (!orderIdInput.trim()) {
          setError('Please enter an order ID.');
          return;
        }
        fetchOrderDetails(orderIdInput.trim());
      };

      const getStatusIcon = (status) => {
        switch (status?.toLowerCase()) {
          case 'order placed':
          case 'processing':
          case 'pending':
            return <Package className="h-5 w-5 text-yellow-500" />;
          case 'shipped':
          case 'out for delivery':
            return <Truck className="h-5 w-5 text-blue-500" />;
          case 'delivered':
            return <CheckCircle className="h-5 w-5 text-green-500" />;
          default:
            return <Package className="h-5 w-5 text-gray-500" />;
        }
      };
      
      // TODO: Fetch user's orders if logged in and no specific ID is searched yet
      // useEffect(() => {
      //   if (user && !orderIdInput) {
      //     // fetch user's most recent order or list of orders
      //   }
      // }, [user, orderIdInput]);

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-12 px-4 text-keroluxe-black dark:text-keroluxe-white"
        >
          <h1 className="text-4xl font-bold font-serif text-keroluxe-gold text-center mb-10">Track Your Order</h1>
          
          <Card className="max-w-2xl mx-auto mb-10 p-6 md:p-8 bg-keroluxe-beige/50 dark:bg-neutral-800/50 shadow-xl border-keroluxe-gold/20">
            <form onSubmit={handleTrackOrder} className="space-y-4">
              <Label htmlFor="orderIdInput" className="text-lg font-medium text-keroluxe-black dark:text-keroluxe-white">Enter Your Order ID</Label>
              <div className="flex space-x-2">
                <Input 
                  type="text" 
                  id="orderIdInput" 
                  value={orderIdInput} 
                  onChange={(e) => setOrderIdInput(e.target.value)} 
                  placeholder="e.g., 123" 
                  className="bg-white/80 dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold text-lg"
                />
                <Button type="submit" size="lg" className="btn-primary" disabled={isLoading}>
                  {isLoading ? 'Tracking...' : <><PackageSearch className="mr-2 h-5 w-5" /> Track</>}
                </Button>
              </div>
              {error && <p className="text-sm text-red-500 flex items-center"><AlertTriangle className="h-4 w-4 mr-1"/>{error}</p>}
            </form>
          </Card>

          {orderDetails && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="max-w-3xl mx-auto shadow-2xl bg-keroluxe-white dark:bg-neutral-800 border-keroluxe-gold/10">
                <CardHeader className="bg-keroluxe-gold/5 dark:bg-neutral-700/50 p-6">
                  <CardTitle className="text-2xl font-serif text-keroluxe-gold">Order Details: #{orderDetails.id}</CardTitle>
                  <CardDescription className="text-keroluxe-grey dark:text-neutral-300">Current Status: <span className="font-semibold text-keroluxe-rose-gold">{orderDetails.status}</span></CardDescription>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-keroluxe-black dark:text-keroluxe-white mb-1">Estimated Delivery</h3>
                    <p className="text-keroluxe-grey dark:text-neutral-300">{new Date(orderDetails.updated_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })} (approx.)</p>
                  </div>
                  {orderDetails.shipping_address?.city && (
                    <div>
                      <h3 className="text-lg font-semibold text-keroluxe-black dark:text-keroluxe-white mb-1">Shipping To</h3>
                      <p className="text-keroluxe-grey dark:text-neutral-300 flex items-center"><MapPin className="mr-2 h-5 w-5 text-keroluxe-rose-gold" /> {orderDetails.shipping_address.address}, {orderDetails.shipping_address.city}</p>
                    </div>
                  )}
                  
                  <Separator className="bg-keroluxe-grey/20 dark:bg-neutral-700" />

                  <div>
                    <h3 className="text-lg font-semibold text-keroluxe-black dark:text-keroluxe-white mb-3">Order Items</h3>
                    <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                      {orderDetails.order_items.map((item, index) => (
                        <div key={index} className="flex items-center space-x-3 p-2 bg-keroluxe-off-white/50 dark:bg-neutral-700/50 rounded-md">
                          <div className="w-16 h-16 rounded bg-gray-200 overflow-hidden">
                            <img  alt={item.products.name} className="w-full h-full object-cover" src={item.products.images?.[0] || `https://source.unsplash.com/random/100x100/?${item.products.name.replace(/\s/g, ',')}`} />
                          </div>
                          <div>
                            <p className="font-medium text-keroluxe-black dark:text-keroluxe-off-white">{item.products.name}</p>
                            <p className="text-sm text-keroluxe-grey dark:text-neutral-400">Qty: {item.quantity} - Price: ₦{Number(item.price_at_purchase).toFixed(2)}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator className="bg-keroluxe-grey/20 dark:bg-neutral-700" />

                  <div>
                    <h3 className="text-lg font-semibold text-keroluxe-black dark:text-keroluxe-white mb-4">Order History (Mocked)</h3>
                    <div className="space-y-4 relative">
                      <div className="absolute left-2.5 top-0 bottom-0 w-0.5 bg-keroluxe-gold/30 dark:bg-neutral-600"></div>
                      {orderDetails.history.map((event, index) => (
                        <div key={index} className="flex items-start space-x-3 pl-8 relative">
                          <div className="absolute left-0 top-1 transform -translate-x-1/2 w-5 h-5 rounded-full bg-keroluxe-white dark:bg-neutral-800 border-2 border-keroluxe-gold flex items-center justify-center">
                            {getStatusIcon(event.status)}
                          </div>
                          <div className="pt-0.5">
                            <p className="font-semibold text-keroluxe-black dark:text-keroluxe-white">{event.status}</p>
                            <p className="text-xs text-keroluxe-grey dark:text-neutral-400">{event.date}</p>
                            <p className="text-xs text-keroluxe-grey/80 dark:text-neutral-500">{event.location}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </motion.div>
      );
    };

    export default OrderTrackingPage;