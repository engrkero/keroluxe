import React from 'react';
    import { motion } from 'framer-motion';
    import { Users, Target, Sparkles } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Link } from 'react-router-dom';
    import { ShoppingBag } from 'lucide-react';


    const AboutUsPage = () => {
      const teamMembers = [
        { name: "Kemi Adewale", role: "Founder & CEO", imageUrlPlaceholder: "Portrait of Kemi Adewale, CEO, smiling confidently", imageActual: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80" },
        { name: "Chinedu Okoro", role: "Head of Curation & Style", imageUrlPlaceholder: "Portrait of Chinedu Okoro, Head of Curation, looking stylish", imageActual: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80" },
        { name: "Fatima Bello", role: "Operations & Seller Relations", imageUrlPlaceholder: "Portrait of Fatima Bello, Operations Manager, looking professional", imageActual: "https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80" },
      ];

      const coreValues = [
        { icon: <ShoppingBag className="h-10 w-10 text-keroluxe-gold" />, title: "Quality Finds", description: "We offer a curated selection of high-quality stock and bale clothing, watches, and perfumes." },
        { icon: <Users className="h-10 w-10 text-keroluxe-gold" />, title: "Seller Empowerment", description: "Providing a platform for other sellers to reach a wider audience and grow their business." },
        { icon: <Target className="h-10 w-10 text-keroluxe-gold" />, title: "Customer Delight", description: "Our customers are at the heart of everything. We strive to exceed expectations with every interaction." },
        { icon: <Sparkles className="h-10 w-10 text-keroluxe-gold" />, title: "Unique Style", description: "Discover unique pieces that help you express your individual style and confidence." },
      ];

      return (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-12 px-4 text-keroluxe-black dark:text-keroluxe-white"
        >
          <section className="relative py-20 md:py-32 rounded-xl overflow-hidden bg-gradient-to-br from-keroluxe-gold via-keroluxe-dark-gold to-keroluxe-gold/80 mb-16 shadow-2xl">
            <div className="absolute inset-0 opacity-10">
              <img  alt="Abstract elegant fashion background pattern" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1599056432016-9573e0a7f647?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1920&q=80" />
            </div>
            <div className="relative container mx-auto px-4 text-center">
              <motion.h1 
                initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.6, delay:0.2 }}
                className="text-5xl md:text-7xl font-bold font-serif mb-6 text-keroluxe-white"
              >
                About KeroLuxe
              </motion.h1>
              <motion.p 
                initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.6, delay:0.4 }}
                className="text-xl md:text-2xl max-w-3xl mx-auto text-keroluxe-off-white"
                style={{textShadow: '1px 1px 2px rgba(0,0,0,0.1)'}}
              >
                Your Destination for Curated Fashion Finds & Seller Success.
              </motion.p>
            </div>
          </section>

          <section className="mb-16">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16 items-center">
              <motion.div 
                initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ duration: 0.7 }}
                className="aspect-video md:aspect-square rounded-lg overflow-hidden shadow-xl"
              >
                <img  alt="Diverse collection of clothing, watches, and perfumes neatly arranged" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1551803091-e3e462322642?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80" />
              </motion.div>
              <div>
                <motion.h2 
                  initial={{ opacity:0, y:20 }} whileInView={{ opacity:1, y:0 }} viewport={{ once: true, amount: 0.5 }} transition={{ duration:0.6, delay:0.1 }}
                  className="text-3xl md:text-4xl font-semibold font-serif text-keroluxe-gold mb-6"
                >
                  Our Mission
                </motion.h2>
                <motion.p 
                  initial={{ opacity:0, y:20 }} whileInView={{ opacity:1, y:0 }} viewport={{ once: true, amount: 0.5 }} transition={{ duration:0.6, delay:0.2 }}
                  className="text-keroluxe-grey dark:text-neutral-300 leading-relaxed mb-4"
                >
                  At KeroLuxe, we're passionate about fashion and empowering entrepreneurs. We meticulously curate a diverse collection of high-quality items, including new stock clothing, first-class bale (foreign used) apparel, stylish watches, and captivating fragrances/perfumes. 
                </motion.p>
                <motion.p 
                  initial={{ opacity:0, y:20 }} whileInView={{ opacity:1, y:0 }} viewport={{ once: true, amount: 0.5 }} transition={{ duration:0.6, delay:0.3 }}
                  className="text-keroluxe-grey dark:text-neutral-300 leading-relaxed"
                >
                  Beyond offering unique finds for our customers, KeroLuxe is dedicated to supporting other sellers. We provide a vibrant platform for vendors to showcase their products, connect with a broader audience, and grow their businesses within a supportive and stylish community.
                </motion.p>
              </div>
            </div>
          </section>

          <section className="py-16 bg-keroluxe-off-white dark:bg-neutral-800 rounded-xl shadow-lg mb-16">
            <h2 className="text-3xl md:text-4xl font-semibold font-serif text-keroluxe-gold text-center mb-12">Our Core Values</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 px-4">
              {coreValues.map((value, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, y: 30 }} 
                  whileInView={{ opacity: 1, y: 0 }} 
                  viewport={{ once: true, amount: 0.3 }} 
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="text-center p-6 bg-keroluxe-white dark:bg-neutral-700 rounded-lg shadow-md border border-keroluxe-gold/20"
                >
                  <div className="flex justify-center mb-4">{value.icon}</div>
                  <h3 className="text-xl font-semibold text-keroluxe-gold mb-2">{value.title}</h3>
                  <p className="text-sm text-keroluxe-grey dark:text-neutral-300">{value.description}</p>
                </motion.div>
              ))}
            </div>
          </section>

          <section className="mb-16">
            <h2 className="text-3xl md:text-4xl font-semibold font-serif text-keroluxe-gold text-center mb-12">Meet The Team</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {teamMembers.map((member, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }} 
                  whileInView={{ opacity: 1, scale: 1 }} 
                  viewport={{ once: true, amount: 0.3 }} 
                  transition={{ duration: 0.5, delay: index * 0.15 }}
                  className="text-center bg-keroluxe-white dark:bg-neutral-800 p-6 rounded-xl shadow-lg border border-keroluxe-gold/20"
                >
                  <div className="w-32 h-32 rounded-full mx-auto mb-4 overflow-hidden border-2 border-keroluxe-gold">
                    <img  alt={member.imageUrlPlaceholder} className="w-full h-full object-cover" src={member.imageActual || `https://source.unsplash.com/200x200/?${encodeURIComponent(member.imageUrlPlaceholder)}`} />
                  </div>
                  <h3 className="text-xl font-semibold text-keroluxe-gold">{member.name}</h3>
                  <p className="text-keroluxe-grey dark:text-neutral-300">{member.role}</p>
                </motion.div>
              ))}
            </div>
          </section>

          <section className="text-center py-12">
             <motion.h2 
                initial={{ opacity:0, y:20 }} whileInView={{ opacity:1, y:0 }} viewport={{ once: true, amount: 0.5 }} transition={{ duration:0.6 }}
                className="text-3xl font-semibold font-serif text-keroluxe-gold mb-6"
              >
                Join the KeroLuxe Community
              </motion.h2>
              <motion.p 
                initial={{ opacity:0, y:20 }} whileInView={{ opacity:1, y:0 }} viewport={{ once: true, amount: 0.5 }} transition={{ duration:0.6, delay:0.1 }}
                className="text-lg text-keroluxe-grey dark:text-neutral-300 max-w-xl mx-auto mb-8"
              >
                Whether you're looking to discover unique fashion pieces or grow your own brand, KeroLuxe is here for you. Explore our collections or learn more about selling with us.
              </motion.p>
              <motion.div 
                initial={{ opacity:0, y:20 }} whileInView={{ opacity:1, y:0 }} viewport={{ once: true, amount: 0.5 }} transition={{ duration:0.6, delay:0.2 }}
                className="flex flex-col sm:flex-row justify-center items-center gap-4"
              >
                <Button asChild size="lg" className="btn-primary text-lg py-3 px-8">
                  <Link to="/">Shop Now</Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="btn-outline-gold text-lg py-3 px-8">
                  <Link to="/sell-with-us">Sell With KeroLuxe</Link>
                </Button>
              </motion.div>
          </section>
        </motion.div>
      );
    };

    export default AboutUsPage;