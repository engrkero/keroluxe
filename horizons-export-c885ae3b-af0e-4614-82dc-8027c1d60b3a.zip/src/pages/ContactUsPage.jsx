import React, { useState } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Textarea } from '@/components/ui/textarea';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { Mail, Phone, MapPin, Send } from 'lucide-react';

    const ContactUsPage = () => {
      const { toast } = useToast();
      const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: '',
      });

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
      };

      const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Contact form submitted:', formData);
        toast({
          title: "Message Sent!",
          description: "Thank you for contacting us. We'll get back to you soon.",
        });
        setFormData({ name: '', email: '', subject: '', message: '' });
      };

      const contactInfo = [
        { icon: <Mail className="h-6 w-6 text-keroluxe-gold" />, title: "Email Us", content: "support@keroluxe.com", href: "mailto:support@keroluxe.com" },
        { icon: <Phone className="h-6 w-6 text-keroluxe-gold" />, title: "Call Us", content: "+234 800 123 4567", href: "tel:+2348001234567" },
        { icon: <MapPin className="h-6 w-6 text-keroluxe-gold" />, title: "Visit Us", content: "123 Luxury Avenue, Lagos, Nigeria", href: "#" },
      ];

      return (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-12 px-4"
        >
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold font-serif text-keroluxe-gold mb-4">Get In Touch</h1>
            <p className="text-lg text-keroluxe-black dark:text-keroluxe-white max-w-2xl mx-auto">
              We're here to help with any questions or concerns you may have. Reach out to us through any of the methods below.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16 items-start">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="p-6 md:p-8 bg-keroluxe-white dark:bg-neutral-800 rounded-xl shadow-xl border border-keroluxe-gold/20 space-y-6"
            >
              <h2 className="text-2xl font-semibold font-serif text-keroluxe-gold mb-4">Send Us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <Label htmlFor="name" className="text-keroluxe-black dark:text-keroluxe-off-white">Full Name</Label>
                  <Input type="text" name="name" id="name" value={formData.name} onChange={handleInputChange} required className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-gold/30 focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
                </div>
                <div>
                  <Label htmlFor="email" className="text-keroluxe-black dark:text-keroluxe-off-white">Email Address</Label>
                  <Input type="email" name="email" id="email" value={formData.email} onChange={handleInputChange} required className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-gold/30 focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
                </div>
                <div>
                  <Label htmlFor="subject" className="text-keroluxe-black dark:text-keroluxe-off-white">Subject</Label>
                  <Input type="text" name="subject" id="subject" value={formData.subject} onChange={handleInputChange} required className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-gold/30 focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
                </div>
                <div>
                  <Label htmlFor="message" className="text-keroluxe-black dark:text-keroluxe-off-white">Message</Label>
                  <Textarea name="message" id="message" value={formData.message} onChange={handleInputChange} rows={5} required className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-gold/30 focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
                </div>
                <Button type="submit" size="lg" className="w-full btn-primary text-lg py-3">
                  <Send className="mr-2 h-5 w-5" /> Send Message
                </Button>
              </form>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="space-y-8"
            >
              {contactInfo.map((info, index) => (
                <div key={index} className="flex items-start space-x-4 p-6 bg-keroluxe-white dark:bg-neutral-800 rounded-lg shadow-lg border border-keroluxe-gold/10">
                  <div className="flex-shrink-0 mt-1">{info.icon}</div>
                  <div>
                    <h3 className="text-xl font-semibold text-keroluxe-gold mb-1">{info.title}</h3>
                    {info.href === "#" ? (
                       <p className="text-keroluxe-black dark:text-keroluxe-off-white">{info.content}</p>
                    ) : (
                       <a href={info.href} className="text-keroluxe-black dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold transition-colors">{info.content}</a>
                    )}
                  </div>
                </div>
              ))}
              <div className="mt-8 p-6 bg-keroluxe-white dark:bg-neutral-800 rounded-lg shadow-lg border border-keroluxe-gold/10">
                <h3 className="text-xl font-semibold text-keroluxe-gold mb-3">Business Hours</h3>
                <p className="text-keroluxe-black dark:text-keroluxe-off-white">Monday - Friday: 9:00 AM - 6:00 PM (WAT)</p>
                <p className="text-keroluxe-black dark:text-keroluxe-off-white">Saturday: 10:00 AM - 4:00 PM (WAT)</p>
                <p className="text-keroluxe-black dark:text-keroluxe-off-white">Sunday: Closed</p>
              </div>
            </motion.div>
          </div>
          
          <div className="mt-16">
            <h2 className="text-3xl font-bold font-serif text-keroluxe-gold text-center mb-6">Find Us On The Map</h2>
            <div className="aspect-video bg-gray-300 dark:bg-neutral-700 rounded-lg shadow-xl overflow-hidden border-2 border-keroluxe-gold/20">
              <iframe
                width="100%"
                height="100%"
                title="KeroLuxe Location"
                src="https://www.openstreetmap.org/export/embed.html?bbox=3.3797%2C6.5244%2C3.3897%2C6.5344&layer=mapnik&marker=6.5294%2C3.3847"
                className="border-0"
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>
        </motion.div>
      );
    };

    export default ContactUsPage;