import React from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
    import { Truck, RotateCcw, Package, ShieldCheck } from 'lucide-react';

    const ShippingReturnsPage = () => {
      const pageSections = [
        {
          icon: <Truck className="h-10 w-10 text-keroluxe-gold mb-4" />,
          title: "Shipping Information",
          content: (
            <div className="space-y-4 text-keroluxe-black dark:text-keroluxe-off-white">
              <p>We offer reliable shipping options to get your KeroLuxe items to you swiftly and securely. All orders are processed within 1-2 business days.</p>
              <div>
                <h3 className="text-lg font-semibold text-keroluxe-gold mb-1">Domestic Shipping (Nigeria):</h3>
                <ul className="list-disc list-inside space-y-1">
                  <li>Standard Shipping (3-5 business days): Starting from ₦2,500.</li>
                  <li>Express Shipping (1-2 business days): Starting from ₦5,000.</li>
                  <li>Free standard shipping on orders over ₦50,000.</li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-keroluxe-gold mb-1">International Shipping:</h3>
                <p>We ship to select international destinations. Shipping costs and times vary by location and will be calculated at checkout. Please note that customers are responsible for any applicable customs duties or taxes.</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-keroluxe-gold mb-1">Order Tracking:</h3>
                <p>Once your order is shipped, you will receive a confirmation email with a tracking number. You can track your order <a href="/track-order" className="text-keroluxe-gold hover:underline">here</a>.</p>
              </div>
            </div>
          )
        },
        {
          icon: <RotateCcw className="h-10 w-10 text-keroluxe-gold mb-4" />,
          title: "Return & Exchange Policy",
          content: (
             <Accordion type="single" collapsible className="w-full text-keroluxe-black dark:text-keroluxe-off-white">
              <AccordionItem value="item-1">
                <AccordionTrigger className="text-lg font-semibold text-keroluxe-gold hover:text-keroluxe-gold/80">Eligibility for Returns</AccordionTrigger>
                <AccordionContent>
                  We accept returns within 14 days of delivery for items that are unworn, unwashed, undamaged, and in their original packaging with all tags attached. Items marked as "Final Sale" are not eligible for return or exchange. Underwear items are non-returnable due to hygiene reasons.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger className="text-lg font-semibold text-keroluxe-gold hover:text-keroluxe-gold/80">How to Initiate a Return/Exchange</AccordionTrigger>
                <AccordionContent>
                  Please contact our customer service team at <a href="mailto:returns@keroluxe.com" className="text-keroluxe-gold hover:underline">returns@keroluxe.com</a> with your order number and reason for return/exchange. We will guide you through the process.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger className="text-lg font-semibold text-keroluxe-gold hover:text-keroluxe-gold/80">Refunds</AccordionTrigger>
                <AccordionContent>
                  Once your return is received and inspected, we will notify you of the approval or rejection of your refund. If approved, your refund will be processed, and a credit will automatically be applied to your original method of payment within 7-10 business days. Shipping costs are non-refundable.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger className="text-lg font-semibold text-keroluxe-gold hover:text-keroluxe-gold/80">Exchanges</AccordionTrigger>
                <AccordionContent>
                  If you wish to exchange an item for a different size or color, please indicate this when contacting customer service. Exchanges are subject to availability.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          )
        },
        {
          icon: <Package className="h-10 w-10 text-keroluxe-gold mb-4" />,
          title: "Damaged or Incorrect Items",
          content: (
            <p className="text-keroluxe-black dark:text-keroluxe-off-white">
              If you receive a damaged or incorrect item, please contact us within 48 hours of delivery with photos of the issue. We will arrange for a replacement or refund at no additional cost to you.
            </p>
          )
        },
        {
          icon: <ShieldCheck className="h-10 w-10 text-keroluxe-gold mb-4" />,
          title: "Our Commitment",
          content: (
            <p className="text-keroluxe-black dark:text-keroluxe-off-white">
              At KeroLuxe, we are committed to ensuring your satisfaction. If you have any questions or concerns regarding our shipping and returns policy, please do not hesitate to <a href="/contact" className="text-keroluxe-gold hover:underline">contact us</a>.
            </p>
          )
        }
      ];

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-12 px-4"
        >
          <header className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold font-serif text-keroluxe-gold mb-4">Shipping & Returns</h1>
            <p className="text-lg text-keroluxe-black dark:text-keroluxe-white max-w-2xl mx-auto">
              Everything you need to know about how we get your KeroLuxe items to you and our policy on returns and exchanges.
            </p>
          </header>

          <div className="space-y-10">
            {pageSections.map((section, index) => (
              <motion.section
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/20">
                  <CardHeader className="flex flex-col items-center text-center">
                    {section.icon}
                    <CardTitle className="text-2xl md:text-3xl font-serif text-keroluxe-gold">{section.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="prose prose-lg max-w-none text-keroluxe-black dark:text-keroluxe-off-white leading-relaxed p-6 md:p-8">
                    {section.content}
                  </CardContent>
                </Card>
              </motion.section>
            ))}
          </div>
        </motion.div>
      );
    };

    export default ShippingReturnsPage;