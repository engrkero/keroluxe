import React, { useState, useEffect } from 'react';
    import { Link, useParams, useNavigate } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Star, ArrowLeft, UploadCloud, Image as ImageIcon, Trash2 } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
    import { Input } from '@/components/ui/input';
    import { Textarea } from '@/components/ui/textarea';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { products as allProductsData } from '@/data/products'; // To get product details

    const WriteReviewPage = () => {
      const { productId } = useParams();
      const navigate = useNavigate();
      const { toast } = useToast();
      const [product, setProduct] = useState(null);
      const [rating, setRating] = useState(0);
      const [hoverRating, setHoverRating] = useState(0);
      const [reviewTitle, setReviewTitle] = useState('');
      const [reviewBody, setReviewBody] = useState('');
      const [uploadedImages, setUploadedImages] = useState([]);
      const [imagePreviews, setImagePreviews] = useState([]);

      useEffect(() => {
        const foundProduct = allProductsData.find(p => p.id === productId);
        if (foundProduct) {
          setProduct(foundProduct);
        } else {
          toast({
            title: "Product not found",
            description: "Could not find the product you're trying to review.",
            variant: "destructive",
          });
          navigate('/'); // Redirect if product not found
        }
      }, [productId, toast, navigate]);

      const handleImageUpload = (event) => {
        const files = Array.from(event.target.files);
        if (uploadedImages.length + files.length > 3) {
          toast({
            title: "Too many images",
            description: "You can upload a maximum of 3 images.",
            variant: "destructive",
          });
          return;
        }
        setUploadedImages(prev => [...prev, ...files.slice(0, 3 - prev.length)]);
        
        const newPreviews = files.slice(0, 3 - imagePreviews.length).map(file => URL.createObjectURL(file));
        setImagePreviews(prev => [...prev, ...newPreviews]);
      };

      const removeImage = (index) => {
        setUploadedImages(prev => prev.filter((_, i) => i !== index));
        setImagePreviews(prev => {
          const newPreviews = prev.filter((_, i) => i !== index);
          newPreviews.forEach(preview => URL.revokeObjectURL(preview)); // Clean up object URLs
          return newPreviews;
        });
      };

      const handleSubmitReview = (e) => {
        e.preventDefault();
        if (rating === 0) {
          toast({ title: "Rating required", description: "Please select a star rating.", variant: "destructive" });
          return;
        }
        if (!reviewTitle.trim()) {
          toast({ title: "Title required", description: "Please enter a review title.", variant: "destructive" });
          return;
        }
        if (!reviewBody.trim()) {
          toast({ title: "Review required", description: "Please write your review.", variant: "destructive" });
          return;
        }

        console.log({
          productId,
          rating,
          reviewTitle,
          reviewBody,
          images: uploadedImages.map(f => f.name) // For now, just log names
        });

        toast({
          title: "Review Submitted! 🎉",
          description: "Thank you for your feedback. Your review is pending approval.",
          className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold",
        });
        // Reset form or navigate away
        setRating(0);
        setReviewTitle('');
        setReviewBody('');
        setUploadedImages([]);
        setImagePreviews([]);
        navigate(`/product/${productId}`);
      };

      if (!product) {
        return (
          <div className="container mx-auto py-12 text-center">
            <p className="text-lg text-keroluxe-grey dark:text-neutral-400">Loading product details...</p>
          </div>
        );
      }

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-12 px-4"
        >
          <Button variant="outline" onClick={() => navigate(`/product/${productId}`)} className="mb-6 border-keroluxe-gold text-keroluxe-gold hover:bg-keroluxe-gold hover:text-keroluxe-black dark:hover:text-keroluxe-black">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Product
          </Button>

          <Card className="w-full max-w-2xl mx-auto bg-keroluxe-white dark:bg-neutral-800 shadow-2xl border-keroluxe-grey/20 dark:border-neutral-700">
            <CardHeader className="text-center">
              <img  alt={product.name} className="w-24 h-24 object-cover rounded-md mx-auto mb-4" src="https://images.unsplash.com/photo-1674027392838-d85710a5121d" />
              <CardTitle className="text-2xl md:text-3xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">
                Write a Review for <span className="text-keroluxe-gold">{product.name}</span>
              </CardTitle>
            </CardHeader>
            <form onSubmit={handleSubmitReview}>
              <CardContent className="space-y-6">
                <div>
                  <Label className="text-lg font-medium text-keroluxe-black dark:text-keroluxe-off-white mb-2 block text-center">Your Rating*</Label>
                  <div className="flex justify-center space-x-1 mb-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-8 w-8 cursor-pointer transition-colors duration-150 ${
                          (hoverRating || rating) >= star 
                          ? 'text-keroluxe-gold fill-keroluxe-gold' 
                          : 'text-keroluxe-grey/40 dark:text-neutral-600'
                        }`}
                        onClick={() => setRating(star)}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                      />
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="reviewTitle" className="text-base font-medium text-keroluxe-black dark:text-keroluxe-off-white">Review Title*</Label>
                  <Input 
                    id="reviewTitle" 
                    value={reviewTitle} 
                    onChange={(e) => setReviewTitle(e.target.value)} 
                    placeholder="e.g., Absolutely love it!" 
                    required 
                    className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold"
                  />
                </div>

                <div>
                  <Label htmlFor="reviewBody" className="text-base font-medium text-keroluxe-black dark:text-keroluxe-off-white">Your Review*</Label>
                  <Textarea 
                    id="reviewBody" 
                    value={reviewBody} 
                    onChange={(e) => setReviewBody(e.target.value)} 
                    placeholder="Tell us more about your experience..." 
                    rows={5} 
                    required 
                    className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold"
                  />
                </div>

                <div>
                  <Label htmlFor="imageUpload" className="text-base font-medium text-keroluxe-black dark:text-keroluxe-off-white">Add Photos (Optional, up to 3)</Label>
                  <div className="mt-2 flex items-center justify-center px-6 pt-5 pb-6 border-2 border-keroluxe-grey/30 dark:border-neutral-600 border-dashed rounded-md">
                    <div className="space-y-1 text-center">
                      <UploadCloud className="mx-auto h-12 w-12 text-keroluxe-grey dark:text-neutral-500" />
                      <div className="flex text-sm text-keroluxe-grey dark:text-neutral-400">
                        <label
                          htmlFor="imageUpload"
                          className="relative cursor-pointer rounded-md font-medium text-keroluxe-gold hover:text-keroluxe-dark-gold focus-within:outline-none focus-within:ring-2 focus-within:ring-keroluxe-gold focus-within:ring-offset-2"
                        >
                          <span>Upload files</span>
                          <input id="imageUpload" name="imageUpload" type="file" className="sr-only" multiple accept="image/*" onChange={handleImageUpload} />
                        </label>
                        <p className="pl-1">or drag and drop</p>
                      </div>
                      <p className="text-xs text-keroluxe-grey/70 dark:text-neutral-500">PNG, JPG, GIF up to 10MB</p>
                    </div>
                  </div>
                  {imagePreviews.length > 0 && (
                    <div className="mt-4 grid grid-cols-3 gap-2">
                      {imagePreviews.map((preview, index) => (
                        <div key={index} className="relative group">
                          <img  src={preview} alt={`Preview ${index + 1}`} className="h-24 w-full object-cover rounded-md" />
                          <Button
                            type="button"
                            variant="destructive"
                            size="icon"
                            className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => removeImage(index)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit" size="lg" className="w-full bg-keroluxe-black text-keroluxe-white hover:bg-keroluxe-gold hover:text-keroluxe-black dark:bg-keroluxe-gold dark:text-keroluxe-black dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black">
                  Submit Review
                </Button>
              </CardFooter>
            </form>
          </Card>
        </motion.div>
      );
    };

    export default WriteReviewPage;