
    import React from 'react';
    import { Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { useAppContext } from '@/contexts/AppContext';
    import ProductCard from '@/components/ProductCard';
    import { Button } from '@/components/ui/button';
    import { HeartCrack, ShoppingBag } from 'lucide-react';

    const WishlistPage = () => {
      const { wishlist, removeFromWishlist, addToCart } = useAppContext();

      const handleMoveToCart = (product) => {
        addToCart(product);
        removeFromWishlist(product.id);
        // Add toast notification if available
      };
      
      const pageVariants = {
        initial: { opacity: 0, y: 20 },
        animate: { opacity: 1, y: 0, transition: { duration: 0.5 } },
        exit: { opacity: 0, y: -20, transition: { duration: 0.3 } }
      };

      const itemVariants = {
        initial: { opacity: 0, scale: 0.95 },
        animate: { opacity: 1, scale: 1 },
        exit: { opacity: 0, scale: 0.9 }
      };


      return (
        <motion.div 
          variants={pageVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          className="container mx-auto py-8"
        >
          <h1 className="text-4xl font-bold font-serif text-keroluxe-gold mb-8 text-center">Your Wishlist</h1>

          {wishlist.length === 0 ? (
            <motion.div 
              variants={itemVariants} 
              className="text-center py-16 bg-keroluxe-beige/30 rounded-lg shadow-md"
            >
              <HeartCrack className="mx-auto h-24 w-24 text-keroluxe-gold/50 mb-6" />
              <h2 className="text-2xl font-semibold text-keroluxe-gold mb-2">Your wishlist is empty.</h2>
              <p className="text-keroluxe-gold/70 mb-6">Explore our collections and add your favorite items.</p>
              <Button asChild size="lg" className="bg-keroluxe-gold hover:bg-keroluxe-rose-gold text-white">
                <Link to="/">Discover Products</Link>
              </Button>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8">
              {wishlist.map((product, index) => (
                <motion.div 
                  key={product.id} 
                  variants={itemVariants}
                  transition={{ delay: index * 0.05 }}
                  className="relative"
                >
                  <ProductCard product={product} />
                  <div className="absolute top-2 right-10 z-10 flex flex-col space-y-1"> {/* Adjusted position */}
                     {/* Remove button is part of ProductCard's wishlist logic now */}
                  </div>
                  <Button 
                    onClick={() => handleMoveToCart(product)} 
                    className="mt-2 w-full bg-keroluxe-rose-gold hover:bg-keroluxe-gold text-white"
                  >
                    <ShoppingBag className="mr-2 h-4 w-4" /> Move to Cart
                  </Button>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      );
    };

    export default WishlistPage;
  