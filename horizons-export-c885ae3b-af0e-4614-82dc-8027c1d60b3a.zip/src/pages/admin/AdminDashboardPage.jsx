import React from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Users, ShoppingCart, DollarSign, MessageSquare, Star, UserCheck, Banknote, Truck as TruckIcon } from 'lucide-react';
    import { Link } from 'react-router-dom';
    import { products as allProductsData } from '@/data/products'; 
    import { Button } from '@/components/ui/button';

    const AdminDashboardPage = () => {
      const pendingReviewsCount = allProductsData.flatMap(p => p.reviews || []).filter(r => (r.status || 'pending') === 'pending').length;
      const mockPendingSellers = 3; 
      const mockPendingPayouts = 5;
      const mockParcelsToDispatch = 8;

      const stats = [
        { title: "Total Users", value: "1,234", icon: <Users className="h-6 w-6 text-keroluxe-gold" />, change: "+5% this month", link: "/admin/analytics" },
        { title: "Total Orders", value: "567", icon: <ShoppingCart className="h-6 w-6 text-keroluxe-gold" />, change: "+12% this month", link: "/admin/orders" },
        { title: "Total Revenue", value: "₦10,250k", icon: <DollarSign className="h-6 w-6 text-keroluxe-gold" />, change: "+8% this month", link: "/admin/analytics" },
        { title: "Pending Reviews", value: pendingReviewsCount.toString(), icon: <Star className="h-6 w-6 text-keroluxe-gold" />, change: "Awaiting approval", link: "/admin/reviews" },
        { title: "Pending Sellers", value: mockPendingSellers.toString(), icon: <UserCheck className="h-6 w-6 text-keroluxe-gold" />, change: "Awaiting approval", link: "/admin/manage-sellers" },
        { title: "Pending Payouts", value: mockPendingPayouts.toString(), icon: <Banknote className="h-6 w-6 text-keroluxe-gold" />, change: "Awaiting processing", link: "/admin/seller-payouts" },
        { title: "Parcels to Dispatch", value: mockParcelsToDispatch.toString(), icon: <TruckIcon className="h-6 w-6 text-keroluxe-gold" />, change: "Ready for pickup", link: "/admin/dispatch-center" },
      ];

      const salesByCategoryData = [
        { category: "Shirts", sales: 150 },
        { category: "T-Shirts", sales: 250 },
        { category: "Underwears (Male)", sales: 80 },
        { category: "Nightwears (Female)", sales: 120 },
        { category: "Trousers (Unisex)", sales: 90 },
        { category: "Shorts (Unisex)", sales: 70 },
        { category: "Bale - Jeans", sales: 45 },
        { category: "Bale - Female Tops", sales: 60 },
      ];
      const maxSales = Math.max(...salesByCategoryData.map(d => d.sales), 1);


      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6 md:space-y-8"
        >
          <h1 className="text-2xl sm:text-3xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Admin Dashboard</h1>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Link to={stat.link || "#"}>
                  <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg hover:shadow-xl transition-shadow border-keroluxe-gold/10 h-full">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium text-keroluxe-black dark:text-keroluxe-off-white/80">{stat.title}</CardTitle>
                      {React.cloneElement(stat.icon, { className: "h-5 w-5 text-keroluxe-gold" })}
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-keroluxe-black dark:text-keroluxe-white">{stat.value}</div>
                      <p className="text-xs text-keroluxe-grey dark:text-neutral-400">{stat.change}</p>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
            <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10">
              <CardHeader>
                <CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white">Recent Orders</CardTitle>
                <CardDescription className="text-keroluxe-grey dark:text-neutral-400">Overview of the latest customer orders.</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {[
                    {id: 'KERO123XYZ', amount: '₦55,885.75', status: 'Paid', statusColor: 'bg-green-100 text-green-700 dark:bg-green-700/30 dark:text-green-300'}, 
                    {id: 'KERO456ABC', amount: '₦25,795.00', status: 'Pending', statusColor: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-700/30 dark:text-yellow-300'}, 
                    {id: 'KERO789DEF', amount: '₦10,745.50', status: 'Shipped', statusColor: 'bg-blue-100 text-blue-700 dark:bg-blue-700/30 dark:text-blue-300'}
                  ].map((order) => (
                    <li key={order.id} className="flex justify-between items-center p-2.5 bg-keroluxe-off-white/50 dark:bg-neutral-700/30 rounded-md">
                      <span className="text-sm text-keroluxe-black dark:text-keroluxe-off-white/90">{order.id} - {order.amount}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${order.statusColor}`}>
                        {order.status}
                      </span>
                    </li>
                  ))}
                </ul>
                 <Button variant="link" asChild className="mt-3 text-keroluxe-gold hover:underline p-0 dark:text-keroluxe-gold dark:hover:text-keroluxe-off-white">
                    <Link to="/admin/orders">View All Orders</Link>
                 </Button>
              </CardContent>
            </Card>

            <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10">
              <CardHeader>
                <CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white">Sales by Category</CardTitle>
                <CardDescription className="text-keroluxe-grey dark:text-neutral-400">Number of items ordered in each category.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2.5">
                {salesByCategoryData.map(item => (
                  <div key={item.category} className="flex items-center space-x-2">
                    <span className="text-sm text-keroluxe-grey dark:text-neutral-300 w-2/5 truncate" title={item.category}>{item.category}</span>
                    <div className="w-3/5 bg-keroluxe-off-white dark:bg-neutral-700 rounded-full h-5">
                      <motion.div 
                        className="bg-keroluxe-gold h-5 rounded-full flex items-center justify-end pr-2"
                        initial={{ width: 0 }}
                        animate={{ width: `${(item.sales / maxSales) * 100}%` }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                      >
                         <span className="text-xs text-keroluxe-black font-medium">{item.sales}</span>
                      </motion.div>
                    </div>
                  </div>
                ))}
                <Button variant="link" asChild className="mt-3 text-keroluxe-gold hover:underline p-0 dark:text-keroluxe-gold dark:hover:text-keroluxe-off-white">
                    <Link to="/admin/analytics">View Full Analytics</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
          
        </motion.div>
      );
    };

    export default AdminDashboardPage;