import React, { useState, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Badge } from '@/components/ui/badge';
    import { Input } from '@/components/ui/input';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Banknote, Search, Filter, CheckCircle, Clock, TrendingUp, Download } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';

    const mockPayouts = [
      { id: 'PAY001', sellerId: 'SELLER002', storeName: 'Modern Wears Inc.', period: '2025-W20', grossSales: 55000, commissionRate: 5, commissionAmount: 2750, netPayout: 52250, status: 'Paid', payoutDate: '2025-05-20' },
      { id: 'PAY002', sellerId: 'SELLER005', storeName: 'Artisan Goods', period: '2025-W21', grossSales: 72000, commissionRate: 5, commissionAmount: 3600, netPayout: 68400, status: 'Pending', payoutDate: null },
      { id: 'PAY003', sellerId: 'SELLER002', storeName: 'Modern Wears Inc.', period: '2025-W21', grossSales: 68000, commissionRate: 5, commissionAmount: 3400, netPayout: 64600, status: 'Pending', payoutDate: null },
      { id: 'PAY004', sellerId: 'SELLER006', storeName: 'Luxe Accessories', period: '2025-W21', grossSales: 120000, commissionRate: 5, commissionAmount: 6000, netPayout: 114000, status: 'Pending', payoutDate: null },
    ];

    const AdminSellerPayoutsPage = () => {
      const [payouts, setPayouts] = useState(mockPayouts);
      const [searchTerm, setSearchTerm] = useState('');
      const [statusFilter, setStatusFilter] = useState('all');
      const { toast } = useToast();

      const handleMarkAsPaid = (payoutId) => {
        setPayouts(prevPayouts => 
          prevPayouts.map(p => p.id === payoutId ? { ...p, status: 'Paid', payoutDate: new Date().toISOString().split('T')[0] } : p)
        );
        toast({ title: "Payout Marked as Paid", description: `Payout ID ${payoutId} has been processed.` });
      };

      const filteredPayouts = useMemo(() => {
        return payouts
          .filter(payout => statusFilter === 'all' || payout.status.toLowerCase() === statusFilter.toLowerCase())
          .filter(payout => 
            payout.storeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            payout.sellerId.toLowerCase().includes(searchTerm.toLowerCase()) ||
            payout.id.toLowerCase().includes(searchTerm.toLowerCase())
          );
      }, [payouts, searchTerm, statusFilter]);

      const getStatusBadgeVariant = (status) => {
        if (status === 'Paid') return 'success';
        return 'secondary';
      };
      
      const exportPayouts = () => {
        const csvContent = "data:text/csv;charset=utf-8," 
          + "Payout ID,Seller ID,Store Name,Period,Gross Sales,Commission (%),Commission Amount,Net Payout,Status,Payout Date\n" 
          + filteredPayouts.map(p => `${p.id},${p.sellerId},"${p.storeName}",${p.period},${p.grossSales},${p.commissionRate},${p.commissionAmount},${p.netPayout},${p.status},${p.payoutDate || ''}`).join("\n");
        
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "seller_payouts.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        toast({ title: "Export Successful", description: "Seller payouts list has been downloaded." });
      };


      return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 text-keroluxe-black dark:text-keroluxe-white">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h1 className="text-2xl md:text-3xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Seller Payouts</h1>
            <Button onClick={exportPayouts} variant="outline" className="border-keroluxe-gold text-keroluxe-gold hover:bg-keroluxe-gold/10 dark:text-keroluxe-off-white dark:border-keroluxe-gold dark:hover:bg-keroluxe-gold/20">
              <Download className="mr-2 h-4 w-4" /> Export Payouts
            </Button>
          </div>
          
          <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/10">
            <CardHeader>
              <CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white">Filter & Search Payouts</CardTitle>
              <div className="flex flex-col md:flex-row gap-4 pt-2">
                <div className="flex-grow flex items-center space-x-2 p-2 bg-keroluxe-off-white dark:bg-neutral-700 rounded-md">
                  <Search className="h-5 w-5 text-keroluxe-grey dark:text-neutral-400" />
                  <Input 
                    type="text" 
                    placeholder="Search by Store Name, Seller ID, or Payout ID..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="border-0 focus:ring-0 bg-transparent flex-1 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Filter className="h-5 w-5 text-keroluxe-grey dark:text-neutral-400" />
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full md:w-[180px] bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white focus:border-keroluxe-gold">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white">
                      <SelectItem value="all" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">All Statuses</SelectItem>
                      <SelectItem value="pending" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Pending</SelectItem>
                      <SelectItem value="paid" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Paid</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b dark:border-neutral-700">
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Payout ID</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Store Name</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Period</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white text-right">Gross Sales</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white text-right">Net Payout</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Status</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPayouts.map((payout) => (
                    <TableRow key={payout.id} className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b dark:border-neutral-700 last:border-b-0">
                      <TableCell className="font-medium text-keroluxe-black dark:text-keroluxe-off-white">{payout.id}</TableCell>
                      <TableCell className="text-keroluxe-grey dark:text-neutral-300">{payout.storeName}</TableCell>
                      <TableCell className="text-keroluxe-grey dark:text-neutral-300">{payout.period}</TableCell>
                      <TableCell className="text-right text-keroluxe-grey dark:text-neutral-300">₦{payout.grossSales.toLocaleString()}</TableCell>
                      <TableCell className="text-right font-semibold text-keroluxe-black dark:text-keroluxe-off-white">₦{payout.netPayout.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(payout.status)} className="capitalize">
                          {payout.status === 'Paid' && <CheckCircle className="mr-1 h-3 w-3" />}
                          {payout.status === 'Pending' && <Clock className="mr-1 h-3 w-3" />}
                          {payout.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        {payout.status === 'Pending' ? (
                          <Button size="sm" onClick={() => handleMarkAsPaid(payout.id)} className="bg-keroluxe-gold text-keroluxe-black hover:bg-keroluxe-gold/90 dark:bg-keroluxe-gold dark:text-keroluxe-black dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black">
                            <Banknote className="mr-1 h-4 w-4" /> Mark as Paid
                          </Button>
                        ) : (
                          <span className="text-sm text-green-600 dark:text-green-400">Paid on {payout.payoutDate}</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {filteredPayouts.length === 0 && <p className="text-center text-keroluxe-grey dark:text-neutral-400 py-8">No payouts found matching your criteria.</p>}
            </CardContent>
             <CardDescription className="p-4 text-xs text-keroluxe-grey dark:text-neutral-500">
                Note: Commission is calculated at {mockPayouts[0]?.commissionRate || 5}% on gross sales. Payouts are processed for Moniepoint accounts.
             </CardDescription>
          </Card>
        </motion.div>
      );
    };

    export default AdminSellerPayoutsPage;