import React, { useState, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
    import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
    import { Badge } from '@/components/ui/badge';
    import { Trash2, Archive, Reply, Eye, Filter, Star, MessageSquare } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';
    import { Input } from '@/components/ui/input';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

    const mockMessages = [
      { id: 'MSG001', name: 'John Doe', email: 'john.doe@example.com', subject: 'Inquiry about Nightwear Collection', message: 'Hello, I would like to know more about the fabric used in your new silk nightgowns. Are they machine washable?', date: '2025-05-20', read: false, category: 'Product Inquiry', type: 'message' },
      { id: 'MSG002', name: 'Jane Smith', email: 'jane.smith@example.com', subject: 'Issue with Order KERO123XYZ', message: 'Hi, I received my order KERO123XYZ, but one item is missing. Can you please assist?', date: '2025-05-21', read: true, category: 'Order Issue', type: 'message' },
      { id: 'MSG003', name: 'Ahmed Khan', email: 'ahmed.k@example.com', subject: 'Feedback on Unisex T-Shirt', message: 'Just wanted to say I love the new unisex t-shirt! The fit and quality are excellent. Keep up the great work!', date: '2025-05-22', read: false, category: 'Feedback', type: 'feedback' },
      { id: 'MSG004', name: 'Chioma Adebayo', email: 'c.adebayo@example.com', subject: 'Bulk Order Request', message: 'We are interested in placing a bulk order for our company event. Could you provide a quote for 100 custom T-shirts?', date: '2025-05-23', read: false, category: 'Sales Inquiry', type: 'message' },
      { id: 'FDBK001', name: 'Sarah L.', email: 'sarah.l@example.com', subject: 'Great Shopping Experience!', message: 'The website is so easy to navigate and the checkout process was smooth. Loved the product quality too!', date: '2025-05-24', read: true, category: 'Positive Feedback', type: 'feedback' },
    ];

    const AdminMessagesPage = () => {
      const [messages, setMessages] = useState(mockMessages);
      const [selectedMessage, setSelectedMessage] = useState(null);
      const [searchTerm, setSearchTerm] = useState('');
      const [filterType, setFilterType] = useState('all'); 
      const { toast } = useToast();

      const filteredMessages = useMemo(() => {
        return messages
          .filter(msg => {
            if (filterType === 'all') return true;
            return msg.type === filterType;
          })
          .filter(msg => 
            msg.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            msg.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
            msg.email.toLowerCase().includes(searchTerm.toLowerCase())
          );
      }, [messages, searchTerm, filterType]);

      const handleSelectMessage = (message) => {
        setSelectedMessage(message);
        if (!message.read) {
          setMessages(prev => prev.map(m => m.id === message.id ? { ...m, read: true } : m));
        }
      };

      const handleDeleteMessage = (messageId) => {
        setMessages(prev => prev.filter(m => m.id !== messageId));
        if (selectedMessage && selectedMessage.id === messageId) {
          setSelectedMessage(null);
        }
        toast({ title: "Message Deleted", variant: "destructive" });
      };
      
      const handleArchiveMessage = (messageId) => {
        handleDeleteMessage(messageId); 
        toast({ title: "Message Archived" });
      };

      const getCategoryBadgeVariant = (category) => {
        if (category.toLowerCase().includes('issue') || category.toLowerCase().includes('complaint')) return 'destructive';
        if (category.toLowerCase().includes('feedback') && category.toLowerCase().includes('positive')) return 'success';
        if (category.toLowerCase().includes('feedback')) return 'default';
        if (category.toLowerCase().includes('inquiry')) return 'secondary';
        return 'outline';
      };

      return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="h-[calc(100vh-4rem)] md:h-[calc(100vh-6rem)] flex flex-col md:flex-row gap-4 md:gap-6 text-keroluxe-black dark:text-keroluxe-white">
          <Card className="w-full md:w-2/5 lg:w-1/3 bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10 h-full flex flex-col">
            <CardHeader className="border-b border-keroluxe-gold/10 p-3 md:p-4">
              <CardTitle className="text-lg md:text-xl font-serif text-keroluxe-black dark:text-keroluxe-white">Inbox ({filteredMessages.filter(m => !m.read).length} unread)</CardTitle>
              <div className="flex flex-col sm:flex-row gap-2 mt-2">
                <Input 
                  placeholder="Search messages..." 
                  value={searchTerm} 
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 text-sm text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"
                />
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 text-sm text-keroluxe-black dark:text-keroluxe-white">
                    <SelectValue placeholder="Filter by type" />
                  </SelectTrigger>
                  <SelectContent className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-gold/20 text-keroluxe-black dark:text-keroluxe-white">
                    <SelectItem value="all" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">All Types</SelectItem>
                    <SelectItem value="message" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Messages</SelectItem>
                    <SelectItem value="feedback" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Feedback</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="p-0 flex-1 overflow-y-auto">
              {filteredMessages.length === 0 && <p className="p-4 text-center text-keroluxe-grey dark:text-neutral-400">No messages match your filters.</p>}
              {filteredMessages.map(msg => (
                <button
                  key={msg.id}
                  onClick={() => handleSelectMessage(msg)}
                  className={`w-full text-left p-3 md:p-4 border-b border-keroluxe-gold/10 hover:bg-keroluxe-off-white/30 dark:hover:bg-neutral-700/50 transition-colors ${selectedMessage?.id === msg.id ? 'bg-keroluxe-off-white/50 dark:bg-neutral-700/40' : ''} ${!msg.read ? 'font-semibold' : ''}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className={`truncate max-w-[150px] text-sm ${!msg.read ? 'text-keroluxe-black dark:text-keroluxe-white' : 'text-keroluxe-black/90 dark:text-keroluxe-off-white/90'}`}>{msg.name}</span>
                    <span className={`text-xs ${!msg.read ? 'text-keroluxe-gold' : 'text-keroluxe-grey dark:text-neutral-500'}`}>{msg.date}</span>
                  </div>
                  <p className={`text-sm truncate ${!msg.read ? 'text-keroluxe-black/80 dark:text-keroluxe-off-white/80' : 'text-keroluxe-grey dark:text-neutral-400'}`}>{msg.subject}</p>
                  <div className="mt-1 flex items-center gap-1">
                    {!msg.read && <Badge variant="destructive" className="text-xs px-1.5 py-0.5">New</Badge>}
                    {msg.type === 'feedback' && <Badge variant="outline" className="text-xs px-1.5 py-0.5 border-keroluxe-gold text-keroluxe-gold dark:text-keroluxe-gold"><Star className="h-3 w-3 mr-1 inline-block"/>Feedback</Badge>}
                  </div>
                </button>
              ))}
            </CardContent>
          </Card>

          <Card className="w-full md:w-3/5 lg:w-2/3 bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10 h-full flex flex-col">
            {selectedMessage ? (
              <>
                <CardHeader className="border-b border-keroluxe-gold/10 p-3 md:p-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
                    <CardTitle className="text-lg md:text-xl font-serif text-keroluxe-black dark:text-keroluxe-white mb-1 sm:mb-0">{selectedMessage.subject}</CardTitle>
                    <Badge variant={getCategoryBadgeVariant(selectedMessage.category)} className="text-xs sm:text-sm">{selectedMessage.category}</Badge>
                  </div>
                  <div className="flex items-center space-x-2 text-xs sm:text-sm text-keroluxe-grey dark:text-neutral-400 mt-1">
                    <Avatar className="h-7 w-7 sm:h-8 sm:w-8">
                      <AvatarImage src={`https://ui-avatars.com/api/?name=${selectedMessage.name.replace(' ','+')}&background=F5BD02&color=000000&bold=true`} />
                      <AvatarFallback className="text-keroluxe-black">{selectedMessage.name.substring(0,1)}</AvatarFallback>
                    </Avatar>
                    <span>From: {selectedMessage.name} ({selectedMessage.email})</span>
                    <span>|</span>
                    <span>Date: {selectedMessage.date}</span>
                  </div>
                </CardHeader>
                <CardContent className="p-4 md:p-6 text-keroluxe-black/80 dark:text-keroluxe-off-white/80 leading-relaxed flex-1 overflow-y-auto">
                  {selectedMessage.message}
                </CardContent>
                <CardFooter className="border-t border-keroluxe-gold/10 p-3 md:p-4 flex flex-wrap justify-end gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleDeleteMessage(selectedMessage.id)} className="text-red-600 border-red-600 hover:bg-red-50 dark:text-red-400 dark:border-red-400 dark:hover:bg-red-900/30 dark:hover:text-red-300">
                    <Trash2 className="mr-1 h-4 w-4" /> Delete
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleArchiveMessage(selectedMessage.id)} className="text-keroluxe-grey dark:text-neutral-300 border-keroluxe-grey/50 dark:border-neutral-600 hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20 dark:hover:text-keroluxe-white">
                    <Archive className="mr-1 h-4 w-4" /> Archive
                  </Button>
                  <Button size="sm" className="bg-keroluxe-gold text-keroluxe-black hover:bg-keroluxe-gold/90 dark:bg-keroluxe-gold dark:text-keroluxe-black dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black">
                    <Reply className="mr-1 h-4 w-4" /> Reply
                  </Button>
                </CardFooter>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center p-4 md:p-8">
                <MessageSquare className="h-16 w-16 md:h-20 md:w-20 text-keroluxe-grey/30 dark:text-neutral-600 mb-4" />
                <h2 className="text-lg md:text-xl font-semibold text-keroluxe-black/80 dark:text-keroluxe-off-white/80">Select a message to read</h2>
                <p className="text-keroluxe-grey dark:text-neutral-400 text-sm md:text-base">Choose a message from the list on the left to view its content.</p>
              </div>
            )}
          </Card>
        </motion.div>
      );
    };

    export default AdminMessagesPage;