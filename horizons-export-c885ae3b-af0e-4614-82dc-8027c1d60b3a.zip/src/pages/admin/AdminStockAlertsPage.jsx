import React, { useState, useEffect } from 'react';
    import { motion } from 'framer-motion';
    import { AlertTriangle, ShoppingCart, Edit, Trash2 } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { useAppContext } from '@/contexts/AppContext';
    import { useToast } from '@/components/ui/use-toast';
    import { products as mockProducts } from '@/data/products'; // Using mock data for now

    const AdminStockAlertsPage = () => {
      const { supabase } = useAppContext(); // Assuming you'll use supabase later
      const { toast } = useToast();
      const [lowStockProducts, setLowStockProducts] = useState([]);
      const [loading, setLoading] = useState(true);
      const [threshold, setThreshold] = useState(10); // Default low stock threshold

      useEffect(() => {
        // Simulate fetching products and filtering for low stock
        setLoading(true);
        // In a real app, fetch from Supabase 'products' table
        // For now, using mock data
        const filtered = mockProducts.filter(p => p.stock <= threshold);
        setLowStockProducts(filtered);
        setLoading(false);
      }, [threshold]);

      const handleThresholdChange = (e) => {
        const newThreshold = parseInt(e.target.value, 10);
        if (!isNaN(newThreshold) && newThreshold >= 0) {
          setThreshold(newThreshold);
        }
      };
      
      // Placeholder for actions
      const handleRestock = (productId) => {
        toast({ title: "Action Placeholder", description: `Restock initiated for product ID: ${productId}`});
        console.log("Function Tracking: Admin initiated restock for product", productId);
      };

      const handleEditProduct = (productId) => {
        toast({ title: "Action Placeholder", description: `Navigate to edit page for product ID: ${productId}`});
        // navigate(`/admin/products/edit/${productId}`);
         console.log("Function Tracking: Admin navigating to edit product", productId);
      };


      if (loading) {
        return (
          <div className="flex justify-center items-center h-64">
            <AlertTriangle className="h-12 w-12 text-keroluxe-gold animate-pulse" />
            <p className="ml-4 text-lg text-keroluxe-black dark:text-keroluxe-white">Loading stock alerts...</p>
          </div>
        );
      }

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6 text-keroluxe-black dark:text-keroluxe-white"
        >
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-3 sm:space-y-0">
            <div className="flex items-center space-x-3">
              <AlertTriangle className="h-8 w-8 text-red-500" />
              <h1 className="text-2xl sm:text-3xl font-bold font-serif">Low Stock Alerts</h1>
            </div>
            <div className="flex items-center space-x-2">
              <Label htmlFor="threshold" className="text-sm font-medium">Threshold:</Label>
              <Input 
                type="number" 
                id="threshold" 
                value={threshold} 
                onChange={handleThresholdChange} 
                min="0"
                className="w-20 bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold text-sm"
              />
            </div>
          </div>

          {lowStockProducts.length === 0 ? (
            <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
              <CardContent className="p-6 text-center">
                <ShoppingCart className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <p className="text-lg font-semibold">All products are well-stocked!</p>
                <p className="text-sm text-keroluxe-grey dark:text-neutral-400">No items are currently below the threshold of {threshold} units.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {lowStockProducts.map(product => (
                <Card key={product.id} className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-l-4 border-red-500">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold truncate" title={product.name}>{product.name}</CardTitle>
                    <CardDescription className="text-sm text-keroluxe-grey dark:text-neutral-400">
                      SKU: {product.id} | Seller: {product.seller?.name || 'KeroLuxe Official'}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-2xl font-bold text-red-600 dark:text-red-500">
                      Stock: {product.stock} units
                    </p>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" onClick={() => handleRestock(product.id)} className="btn-outline-gold">
                        Mark Restocked
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => handleEditProduct(product.id)} className="text-blue-500 hover:bg-blue-500/10">
                        <Edit className="h-4 w-4 mr-1" /> Edit
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
          
          <p className="text-center text-sm text-keroluxe-grey dark:text-neutral-500 mt-8">
            Stock levels are based on mock data. Integrate with Supabase for real-time tracking.
          </p>
        </motion.div>
      );
    };

    export default AdminStockAlertsPage;