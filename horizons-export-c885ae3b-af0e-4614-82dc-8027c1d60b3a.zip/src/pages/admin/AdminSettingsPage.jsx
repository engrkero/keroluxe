import React, { useState }from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Switch } from '@/components/ui/switch';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
    import { useToast } from '@/components/ui/use-toast';
    import { Bell, Shield, Truck, Palette, Store, CreditCard } from 'lucide-react'; 

    const AdminSettingsPage = () => {
      const { toast } = useToast();
      
      const [settings, setSettings] = useState({
        notifications: { emailNewOrder: true, emailLowStock: false, pushNewMessage: true },
        security: { twoFactorAuth: false, passwordPolicy: 'medium' },
        store: { name: 'KeroLuxe', currency: 'NGN', maintenanceMode: false },
        shipping: { defaultRate: 1500, freeShippingThreshold: 25000 },
        appearance: { themeColor: '#F5BD02' }, // KeroLuxe Gold
        payments: { stripePubKey: '', stripeSecretKey: '', commissionRate: 5 }
      });

      const handleSwitchChange = (category, key) => {
        setSettings(prev => ({
          ...prev,
          [category]: { ...prev[category], [key]: !prev[category][key] }
        }));
      };

      const handleInputChange = (category, key, value) => {
         setSettings(prev => ({
          ...prev,
          [category]: { ...prev[category], [key]: value }
        }));
      };
      
      const handleSaveSettings = (category) => {
        console.log(`Saving ${category} settings:`, settings[category]);
        toast({ 
            title: `${category.charAt(0).toUpperCase() + category.slice(1)} Settings Saved`, 
            description: "Your changes have been successfully applied.",
            className: "bg-keroluxe-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white border-keroluxe-gold"
        });
      };


      return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8 text-keroluxe-black dark:text-keroluxe-white">
          <h1 className="text-3xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Admin Settings</h1>

          <Tabs defaultValue="store" className="w-full">
            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 bg-keroluxe-off-white dark:bg-neutral-800 p-1.5 rounded-lg mb-6 border border-keroluxe-grey/30 dark:border-neutral-700 shadow-sm">
              <TabsTrigger value="store" className="data-[state=active]:bg-keroluxe-gold data-[state=active]:text-keroluxe-black data-[state=active]:shadow-md text-keroluxe-black dark:text-keroluxe-white dark:data-[state=active]:text-keroluxe-black">Store</TabsTrigger>
              <TabsTrigger value="notifications" className="data-[state=active]:bg-keroluxe-gold data-[state=active]:text-keroluxe-black data-[state=active]:shadow-md text-keroluxe-black dark:text-keroluxe-white dark:data-[state=active]:text-keroluxe-black">Notifications</TabsTrigger>
              <TabsTrigger value="security" className="data-[state=active]:bg-keroluxe-gold data-[state=active]:text-keroluxe-black data-[state=active]:shadow-md text-keroluxe-black dark:text-keroluxe-white dark:data-[state=active]:text-keroluxe-black">Security</TabsTrigger>
              <TabsTrigger value="shipping" className="data-[state=active]:bg-keroluxe-gold data-[state=active]:text-keroluxe-black data-[state=active]:shadow-md text-keroluxe-black dark:text-keroluxe-white dark:data-[state=active]:text-keroluxe-black">Shipping</TabsTrigger>
              <TabsTrigger value="payments" className="data-[state=active]:bg-keroluxe-gold data-[state=active]:text-keroluxe-black data-[state=active]:shadow-md text-keroluxe-black dark:text-keroluxe-white dark:data-[state=active]:text-keroluxe-black">Payments</TabsTrigger>
              <TabsTrigger value="appearance" className="data-[state=active]:bg-keroluxe-gold data-[state=active]:text-keroluxe-black data-[state=active]:shadow-md text-keroluxe-black dark:text-keroluxe-white dark:data-[state=active]:text-keroluxe-black">Appearance</TabsTrigger>
            </TabsList>

            <TabsContent value="store">
              <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10">
                <CardHeader><CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white flex items-center"><Store className="mr-2 h-5 w-5 text-keroluxe-gold" /> Store Details</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div><Label htmlFor="storeName" className="text-keroluxe-black dark:text-keroluxe-off-white">Store Name</Label><Input id="storeName" value={settings.store.name} onChange={(e) => handleInputChange('store', 'name', e.target.value)} className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400" /></div>
                  <div><Label htmlFor="storeCurrency" className="text-keroluxe-black dark:text-keroluxe-off-white">Default Currency</Label><Input id="storeCurrency" value={settings.store.currency} onChange={(e) => handleInputChange('store', 'currency', e.target.value)} className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"/></div>
                  <div className="flex items-center justify-between pt-2">
                    <Label htmlFor="maintenanceMode" className="flex flex-col space-y-1 text-keroluxe-black dark:text-keroluxe-off-white">
                      <span>Maintenance Mode</span>
                      <span className="font-normal leading-snug text-keroluxe-grey dark:text-neutral-400 text-sm">Temporarily disable customer access to the store.</span>
                    </Label>
                    <Switch id="maintenanceMode" checked={settings.store.maintenanceMode} onCheckedChange={() => handleSwitchChange('store', 'maintenanceMode')} />
                  </div>
                  <Button onClick={() => handleSaveSettings('store')} className="mt-4 btn-primary">Save Store Settings</Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notifications">
              <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10">
                <CardHeader><CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white flex items-center"><Bell className="mr-2 h-5 w-5 text-keroluxe-gold" /> Notification Settings</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between"><Label htmlFor="emailNewOrder" className="text-keroluxe-black dark:text-keroluxe-off-white">Email on New Order</Label><Switch id="emailNewOrder" checked={settings.notifications.emailNewOrder} onCheckedChange={() => handleSwitchChange('notifications', 'emailNewOrder')} /></div>
                  <div className="flex items-center justify-between"><Label htmlFor="emailLowStock" className="text-keroluxe-black dark:text-keroluxe-off-white">Email for Low Stock Alerts</Label><Switch id="emailLowStock" checked={settings.notifications.emailLowStock} onCheckedChange={() => handleSwitchChange('notifications', 'emailLowStock')} /></div>
                  <div className="flex items-center justify-between"><Label htmlFor="pushNewMessage" className="text-keroluxe-black dark:text-keroluxe-off-white">Push Notification for New Message</Label><Switch id="pushNewMessage" checked={settings.notifications.pushNewMessage} onCheckedChange={() => handleSwitchChange('notifications', 'pushNewMessage')} /></div>
                  <Button onClick={() => handleSaveSettings('notifications')} className="mt-4 btn-primary">Save Notification Settings</Button>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="security">
              <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10">
                <CardHeader><CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white flex items-center"><Shield className="mr-2 h-5 w-5 text-keroluxe-gold" /> Security Settings</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between"><Label htmlFor="twoFactorAuth" className="text-keroluxe-black dark:text-keroluxe-off-white">Enable Two-Factor Authentication</Label><Switch id="twoFactorAuth" checked={settings.security.twoFactorAuth} onCheckedChange={() => handleSwitchChange('security', 'twoFactorAuth')} /></div>
                  <div>
                    <Label htmlFor="passwordPolicy" className="text-keroluxe-black dark:text-keroluxe-off-white">Password Policy</Label>
                    <select id="passwordPolicy" value={settings.security.passwordPolicy} onChange={(e) => handleInputChange('security', 'passwordPolicy', e.target.value)} className="w-full h-10 rounded-md border border-input bg-keroluxe-off-white dark:bg-neutral-700 px-3 py-2 text-sm text-keroluxe-black dark:text-keroluxe-white">
                      <option value="weak">Weak</option><option value="medium">Medium</option><option value="strong">Strong</option>
                    </select>
                  </div>
                  <Button onClick={() => handleSaveSettings('security')} className="mt-4 btn-primary">Save Security Settings</Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="shipping">
              <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10">
                <CardHeader><CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white flex items-center"><Truck className="mr-2 h-5 w-5 text-keroluxe-gold" /> Shipping Settings</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div><Label htmlFor="defaultRate" className="text-keroluxe-black dark:text-keroluxe-off-white">Default Shipping Rate (NGN)</Label><Input id="defaultRate" type="number" value={settings.shipping.defaultRate} onChange={(e) => handleInputChange('shipping', 'defaultRate', parseFloat(e.target.value))} className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"/></div>
                  <div><Label htmlFor="freeShippingThreshold" className="text-keroluxe-black dark:text-keroluxe-off-white">Free Shipping Threshold (NGN)</Label><Input id="freeShippingThreshold" type="number" value={settings.shipping.freeShippingThreshold} onChange={(e) => handleInputChange('shipping', 'freeShippingThreshold', parseFloat(e.target.value))} className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"/></div>
                  <Button onClick={() => handleSaveSettings('shipping')} className="mt-4 btn-primary">Save Shipping Settings</Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="payments">
              <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10">
                <CardHeader><CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white flex items-center"><CreditCard className="mr-2 h-5 w-5 text-keroluxe-gold" /> Payment Settings</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div><Label htmlFor="stripePubKey" className="text-keroluxe-black dark:text-keroluxe-off-white">Stripe Publishable Key</Label><Input id="stripePubKey" value={settings.payments.stripePubKey} onChange={(e) => handleInputChange('payments', 'stripePubKey', e.target.value)} className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"/></div>
                  <div><Label htmlFor="stripeSecretKey" className="text-keroluxe-black dark:text-keroluxe-off-white">Stripe Secret Key</Label><Input id="stripeSecretKey" type="password" value={settings.payments.stripeSecretKey} onChange={(e) => handleInputChange('payments', 'stripeSecretKey', e.target.value)} className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"/></div>
                  <div><Label htmlFor="commissionRate" className="text-keroluxe-black dark:text-keroluxe-off-white">KeroLuxe Commission Rate (%)</Label><Input id="commissionRate" type="number" value={settings.payments.commissionRate} onChange={(e) => handleInputChange('payments', 'commissionRate', parseFloat(e.target.value))} className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"/></div>
                  <Button onClick={() => handleSaveSettings('payments')} className="mt-4 btn-primary">Save Payment Settings</Button>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="appearance">
              <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10">
                <CardHeader><CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white flex items-center"><Palette className="mr-2 h-5 w-5 text-keroluxe-gold" /> Appearance Settings</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="themeColor" className="text-keroluxe-black dark:text-keroluxe-off-white">Admin Theme Accent Color</Label>
                    <Input id="themeColor" type="color" value={settings.appearance.themeColor} onChange={(e) => handleInputChange('appearance', 'themeColor', e.target.value)} className="w-full h-10 p-1" />
                  </div>
                  <p className="text-sm text-keroluxe-grey dark:text-neutral-400">Note: This color picker is for admin panel accent. Frontend theme is managed separately.</p>
                  <Button onClick={() => handleSaveSettings('appearance')} className="mt-4 btn-primary">Save Appearance Settings</Button>
                </CardContent>
              </Card>
            </TabsContent>

          </Tabs>
        </motion.div>
      );
    };

    export default AdminSettingsPage;