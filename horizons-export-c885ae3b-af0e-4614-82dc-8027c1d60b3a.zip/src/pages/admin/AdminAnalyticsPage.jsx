import React from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { BarChart3, Users, ShoppingCart, DollarSign, Activity } from 'lucide-react';

    const AdminAnalyticsPage = () => {
      // Placeholder data - replace with actual data fetching
      const analyticsData = {
        totalUsers: 1234,
        totalOrders: 567,
        totalRevenue: 10250000,
        averageOrderValue: 18077.50,
        topSellingProducts: [
          { name: "Elegant Silk Nightgown", sales: 150 },
          { name: "Classic Cotton T-Shirt", sales: 250 },
          { name: "Pinstripe Business Shirt", sales: 120 },
        ],
        userGrowth: [
          { month: "Jan", users: 100 },
          { month: "Feb", users: 150 },
          { month: "Mar", users: 220 },
          { month: "Apr", users: 300 },
          { month: "May", users: 380 },
        ],
      };

      const maxUserGrowth = Math.max(...analyticsData.userGrowth.map(d => d.users), 1);

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6 md:space-y-8 text-keroluxe-black dark:text-keroluxe-white"
        >
          <div className="flex items-center space-x-3">
            <BarChart3 className="h-8 w-8 text-keroluxe-gold" />
            <h1 className="text-2xl sm:text-3xl font-bold font-serif">Site Analytics</h1>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-keroluxe-grey dark:text-neutral-400">Total Users</CardTitle>
                <Users className="h-5 w-5 text-keroluxe-gold" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analyticsData.totalUsers.toLocaleString()}</div>
                <p className="text-xs text-keroluxe-grey dark:text-neutral-500">+5% from last month</p>
              </CardContent>
            </Card>
            <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-keroluxe-grey dark:text-neutral-400">Total Orders</CardTitle>
                <ShoppingCart className="h-5 w-5 text-keroluxe-gold" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analyticsData.totalOrders.toLocaleString()}</div>
                <p className="text-xs text-keroluxe-grey dark:text-neutral-500">+12% from last month</p>
              </CardContent>
            </Card>
            <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-keroluxe-grey dark:text-neutral-400">Total Revenue</CardTitle>
                <DollarSign className="h-5 w-5 text-keroluxe-gold" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₦{analyticsData.totalRevenue.toLocaleString()}</div>
                <p className="text-xs text-keroluxe-grey dark:text-neutral-500">+8% from last month</p>
              </CardContent>
            </Card>
             <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-keroluxe-grey dark:text-neutral-400">Avg. Order Value</CardTitle>
                <Activity className="h-5 w-5 text-keroluxe-gold" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₦{analyticsData.averageOrderValue.toLocaleString()}</div>
                <p className="text-xs text-keroluxe-grey dark:text-neutral-500">+3% from last month</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
            <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl font-serif">User Growth</CardTitle>
                <CardDescription className="text-keroluxe-grey dark:text-neutral-400">Monthly active users trend.</CardDescription>
              </CardHeader>
              <CardContent className="h-64 flex items-end space-x-2 p-4">
                {analyticsData.userGrowth.map(data => (
                  <div key={data.month} className="flex-1 flex flex-col items-center">
                    <motion.div 
                      className="w-full bg-keroluxe-gold rounded-t-md"
                      initial={{ height: 0 }}
                      animate={{ height: `${(data.users / maxUserGrowth) * 80}%` }}
                      transition={{ duration: 0.5, ease: "easeOut" }}
                    ></motion.div>
                    <span className="text-xs mt-1 text-keroluxe-grey dark:text-neutral-400">{data.month}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl font-serif">Top Selling Products</CardTitle>
                <CardDescription className="text-keroluxe-grey dark:text-neutral-400">Best performing products by sales volume.</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {analyticsData.topSellingProducts.map((product, index) => (
                    <li key={index} className="flex justify-between items-center text-sm p-2 bg-keroluxe-off-white/50 dark:bg-neutral-700/30 rounded-md">
                      <span className="truncate">{product.name}</span>
                      <span className="font-semibold">{product.sales} sales</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
          
          <p className="text-center text-sm text-keroluxe-grey dark:text-neutral-500 mt-8">
            More detailed analytics and reporting features will be available soon.
          </p>
        </motion.div>
      );
    };

    export default AdminAnalyticsPage;