import React, { useState, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { products as allProductsData } from '@/data/products';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Badge } from '@/components/ui/badge';
    import { Star, CheckCircle, XCircle, Trash2, Eye } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';
    import {
      Dialog,
      DialogContent,
      DialogHeader,
      DialogTitle,
      DialogTrigger,
      DialogFooter,
      DialogClose,
    } from "@/components/ui/dialog";
    import { DialogDescription as ShadDialogDescription } from "@radix-ui/react-dialog";


    const AdminReviewsPage = () => {
      const { toast } = useToast();
      
      const initialReviews = useMemo(() => {
        return allProductsData.flatMap(product => 
          (product.reviews || []).map(review => ({
            ...review,
            productName: product.name,
            productId: product.id,
            status: review.status || 'pending' 
          }))
        );
      }, []);

      const [reviews, setReviews] = useState(initialReviews);
      const [selectedReview, setSelectedReview] = useState(null);
      const [isViewModalOpen, setIsViewModalOpen] = useState(false);

      const handleUpdateStatus = (reviewId, newStatus) => {
        setReviews(prevReviews => 
          prevReviews.map(r => r.id === reviewId ? { ...r, status: newStatus } : r)
        );
        toast({
          title: `Review ${newStatus}`,
          description: `Review ID ${reviewId} has been ${newStatus}.`,
        });
      };

      const handleDeleteReview = (reviewId) => {
        setReviews(prevReviews => prevReviews.filter(r => r.id !== reviewId));
        toast({
          title: "Review Deleted",
          variant: "destructive",
        });
      };

      const openViewModal = (review) => {
        setSelectedReview(review);
        setIsViewModalOpen(true);
      };

      const getStatusBadgeVariant = (status) => {
        if (status === 'approved') return 'success';
        if (status === 'rejected') return 'destructive';
        return 'secondary';
      };


      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6"
        >
          <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/10">
            <CardHeader>
              <CardTitle className="text-2xl md:text-3xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Manage Product Reviews</CardTitle>
              <CardDescription className="text-keroluxe-grey dark:text-neutral-400">
                Approve, reject, or delete customer reviews.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {reviews.length === 0 ? (
                <p className="text-center py-8 text-keroluxe-grey dark:text-neutral-400">No reviews to display.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b dark:border-neutral-700">
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Product</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-white">User</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Rating</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Status</TableHead>
                      <TableHead className="text-keroluxe-black dark:text-keroluxe-white text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {reviews.map((review) => (
                      <TableRow key={review.id} className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b dark:border-neutral-700 last:border-b-0">
                        <TableCell className="font-medium text-keroluxe-black dark:text-keroluxe-off-white">{review.productName}</TableCell>
                        <TableCell className="text-keroluxe-grey dark:text-neutral-300">{review.user}</TableCell>
                        <TableCell className="text-keroluxe-grey dark:text-neutral-300">
                          <div className="flex items-center">
                            {review.rating} <Star className="ml-1 h-4 w-4 text-keroluxe-gold fill-keroluxe-gold" />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={getStatusBadgeVariant(review.status)} className="capitalize">
                            {review.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right space-x-1">
                          <Button variant="ghost" size="icon" onClick={() => openViewModal(review)} className="text-keroluxe-grey dark:text-neutral-400 hover:text-keroluxe-gold dark:hover:text-keroluxe-off-white">
                            <Eye className="h-4 w-4" />
                          </Button>
                          {review.status !== 'approved' && (
                            <Button variant="ghost" size="icon" onClick={() => handleUpdateStatus(review.id, 'approved')} className="text-green-600 dark:text-green-400 hover:text-green-700 dark:hover:text-green-300">
                              <CheckCircle className="h-4 w-4" />
                            </Button>
                          )}
                          {review.status !== 'rejected' && (
                            <Button variant="ghost" size="icon" onClick={() => handleUpdateStatus(review.id, 'rejected')} className="text-orange-500 dark:text-orange-400 hover:text-orange-600 dark:hover:text-orange-300">
                              <XCircle className="h-4 w-4" />
                            </Button>
                          )}
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteReview(review.id)} className="text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {selectedReview && (
            <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
              <DialogContent className="sm:max-w-[525px] bg-keroluxe-white dark:bg-neutral-800 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white">
                <DialogHeader>
                  <DialogTitle className="text-keroluxe-black dark:text-keroluxe-white font-serif text-xl">Review Details</DialogTitle>
                  <ShadDialogDescription className="text-keroluxe-grey dark:text-neutral-400">
                    Viewing review for: {selectedReview.productName}
                  </ShadDialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-3 text-sm">
                  <p><strong className="text-keroluxe-black dark:text-keroluxe-off-white">User:</strong> <span className="text-keroluxe-grey dark:text-neutral-300">{selectedReview.user}</span></p>
                  <p><strong className="text-keroluxe-black dark:text-keroluxe-off-white">Rating:</strong> 
                    <span className="inline-flex items-center ml-1 text-keroluxe-grey dark:text-neutral-300">
                      {selectedReview.rating} <Star className="ml-1 h-4 w-4 text-keroluxe-gold fill-keroluxe-gold" />
                    </span>
                  </p>
                  <p><strong className="text-keroluxe-black dark:text-keroluxe-off-white">Date:</strong> <span className="text-keroluxe-grey dark:text-neutral-300">{new Date(selectedReview.date).toLocaleDateString()}</span></p>
                  <p><strong className="text-keroluxe-black dark:text-keroluxe-off-white">Status:</strong> <Badge variant={getStatusBadgeVariant(selectedReview.status)} className="capitalize ml-1">{selectedReview.status}</Badge></p>
                  <p><strong className="text-keroluxe-black dark:text-keroluxe-off-white">Title:</strong> <span className="text-keroluxe-grey dark:text-neutral-300">{selectedReview.title}</span></p>
                  <div className="space-y-1">
                    <strong className="text-keroluxe-black dark:text-keroluxe-off-white">Comment:</strong>
                    <p className="text-keroluxe-grey dark:text-neutral-300 bg-keroluxe-off-white dark:bg-neutral-700/50 p-2 rounded-md border border-keroluxe-grey/20 dark:border-neutral-600">{selectedReview.comment}</p>
                  </div>
                  {selectedReview.userPhoto && (
                    <div>
                      <strong className="text-keroluxe-black dark:text-keroluxe-off-white">User Photo:</strong>
                      <img  alt="User review photo" className="mt-1 rounded-md max-w-[100px] max-h-[100px] object-cover border border-keroluxe-grey/20 dark:border-neutral-600" src="https://images.unsplash.com/photo-1682078234868-412ec5566118" />
                    </div>
                  )}
                </div>
                <DialogFooter>
                  <DialogClose asChild>
                    <Button type="button" variant="outline" className="border-keroluxe-gold text-keroluxe-gold hover:bg-keroluxe-gold hover:text-keroluxe-black dark:text-keroluxe-white dark:hover:bg-keroluxe-gold dark:hover:text-keroluxe-black">Close</Button>
                  </DialogClose>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}

        </motion.div>
      );
    };

    export default AdminReviewsPage;