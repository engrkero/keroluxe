import React, { useState, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Search, CheckCircle, Truck, Package, Download } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';

    const mockOrders = [
      { id: 'KERO123XYZ', customer: 'Alice Wonderland', date: '2025-05-21', total: 129.97, status: 'Shipped', items: 2, payment: 'Paid', dispatchStatus: 'Dispatched' },
      { id: 'KERO456ABC', customer: 'Bob The Builder', date: '2025-05-20', total: 59.99, status: 'Processing', items: 1, payment: 'Paid', dispatchStatus: 'Pending Dispatch' },
      { id: 'KERO789DEF', customer: 'Charlie Brown', date: '2025-05-19', total: 24.99, status: 'Delivered', items: 1, payment: 'Paid', dispatchStatus: 'Dispatched' },
      { id: 'KERO202JKL', customer: 'Edward Scissorhands', date: '2025-05-22', total: 199.00, status: 'Processing', items: 4, payment: 'Paid', dispatchStatus: 'Pending Dispatch' },
      { id: 'KERO303MNO', customer: 'Fiona Gallagher', date: '2025-05-23', total: 75.00, status: 'Processing', items: 1, payment: 'Paid', dispatchStatus: 'Pending Dispatch' },
    ];

    const AdminPaidOrdersPage = () => {
      const [orders, setOrders] = useState(mockOrders.filter(o => o.payment === 'Paid'));
      const [searchTerm, setSearchTerm] = useState('');
      const { toast } = useToast();

      const handleDispatch = (orderId) => {
        setOrders(prevOrders => prevOrders.map(order => 
          order.id === orderId ? { ...order, dispatchStatus: 'Dispatched', status: 'Shipped' } : order
        ));
        toast({ title: "Order Dispatched", description: `Order ${orderId} has been marked as dispatched.` });
      };

      const filteredOrders = useMemo(() => orders.filter(order =>
        order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customer.toLowerCase().includes(searchTerm.toLowerCase())
      ), [orders, searchTerm]);
      
      const getDispatchStatusBadge = (status) => {
        switch (status) {
          case 'Dispatched': return <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-700 dark:bg-green-700/30 dark:text-green-300 rounded-full flex items-center"><Truck className="mr-1 h-3 w-3" />Dispatched</span>;
          case 'Pending Dispatch': return <span className="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-700 dark:bg-yellow-700/30 dark:text-yellow-300 rounded-full flex items-center"><Package className="mr-1 h-3 w-3" />Pending Dispatch</span>;
          default: return <span className="px-2 py-1 text-xs font-medium bg-gray-100 text-gray-700 dark:bg-neutral-700 dark:text-neutral-300 rounded-full">{status}</span>;
        }
      };

      const exportPaidOrders = () => {
        const csvContent = "data:text/csv;charset=utf-8," 
          + "Order ID,Customer,Date,Total,Status,Dispatch Status\n" 
          + filteredOrders.map(o => `${o.id},"${o.customer}",${o.date},${o.total},${o.status},${o.dispatchStatus}`).join("\n");
        
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "paid_orders.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        toast({ title: "Export Successful", description: "Paid orders list has been downloaded." });
      };


      return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 text-keroluxe-black dark:text-keroluxe-white">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h1 className="text-2xl md:text-3xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Paid Orders for Dispatch</h1>
            <Button onClick={exportPaidOrders} variant="outline" className="border-keroluxe-gold text-keroluxe-gold hover:bg-keroluxe-gold/10 dark:text-keroluxe-off-white dark:border-keroluxe-gold dark:hover:bg-keroluxe-gold/20">
              <Download className="mr-2 h-4 w-4" /> Export List
            </Button>
          </div>
          
          <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10">
            <CardHeader>
              <div className="flex items-center space-x-2 p-2 bg-keroluxe-off-white dark:bg-neutral-700 rounded-md">
                <Search className="h-5 w-5 text-keroluxe-grey dark:text-neutral-400" />
                <Input 
                  type="text" 
                  placeholder="Search by Order ID or Customer Name..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="border-0 focus:ring-0 bg-transparent flex-1 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"
                />
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b dark:border-neutral-700">
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Order ID</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Customer</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Date</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white text-right">Total</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Order Status</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Dispatch Status</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white text-center">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOrders.map((order) => (
                    <TableRow key={order.id} className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b dark:border-neutral-700 last:border-b-0">
                      <TableCell className="font-medium text-keroluxe-black dark:text-keroluxe-off-white">{order.id}</TableCell>
                      <TableCell className="text-keroluxe-grey dark:text-neutral-300">{order.customer}</TableCell>
                      <TableCell className="text-keroluxe-grey dark:text-neutral-300">{order.date}</TableCell>
                      <TableCell className="text-right text-keroluxe-grey dark:text-neutral-300">₦{order.total.toFixed(2)}</TableCell>
                      <TableCell className="text-keroluxe-grey dark:text-neutral-300">{order.status}</TableCell>
                      <TableCell>{getDispatchStatusBadge(order.dispatchStatus)}</TableCell>
                      <TableCell className="text-center">
                        {order.dispatchStatus === 'Pending Dispatch' ? (
                          <Button 
                            size="sm" 
                            onClick={() => handleDispatch(order.id)}
                            className="bg-keroluxe-gold text-keroluxe-black hover:bg-keroluxe-gold/90 dark:bg-keroluxe-gold dark:text-keroluxe-black dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black"
                          >
                            <Truck className="mr-1 h-4 w-4" /> Mark as Dispatched
                          </Button>
                        ) : (
                          <span className="text-green-600 dark:text-green-400 flex items-center justify-center"><CheckCircle className="mr-1 h-4 w-4" /> Dispatched</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {filteredOrders.length === 0 && <p className="text-center text-keroluxe-grey dark:text-neutral-400 py-8">No paid orders found matching your criteria.</p>}
            </CardContent>
          </Card>
        </motion.div>
      );
    };

    export default AdminPaidOrdersPage;