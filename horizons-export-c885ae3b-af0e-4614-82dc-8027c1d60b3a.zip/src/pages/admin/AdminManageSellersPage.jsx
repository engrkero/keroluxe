import React, { useState, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Badge } from '@/components/ui/badge';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Eye, CheckCircle, XCircle, Search, Filter, Briefcase, Clock, MessageSquare as MessageIcon, PhoneCall } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
    import { DialogDescription as ShadDialogDescription } from "@radix-ui/react-dialog";
    import { Textarea } from '@/components/ui/textarea';


    const mockSellers = [
      { id: 'SELLER001', storeName: 'Vintage Vibes NG', contactName: 'Ada Okoro', email: 'ada@vintagevibes.ng', phone: '08012345678', status: 'Pending', dateApplied: '2025-05-15', itemsListed: 0, totalSales: 0, documents: { ninNumber: '12345678901', ninFront: 'nin_front_ada.jpg', ninBack: 'nin_back_ada.jpg', bvn: '22233344455', passportPhoto: 'passport_ada.jpg', cac: null}, bankDetails: { bankName: 'Moniepoint MFB', accountNumber: '0123456789', accountName: 'Ada Okoro Vintage' } },
      { id: 'SELLER002', storeName: 'Modern Wears Inc.', contactName: 'Bayo Adekunle', email: 'bayo@modernwears.co', phone: '09087654321', status: 'Approved', dateApplied: '2025-04-20', itemsListed: 25, totalSales: 150000, documents: { ninNumber: '98765432109', ninFront: 'nin_front_bayo.jpg', ninBack: 'nin_back_bayo.jpg', bvn: '11122233344', passportPhoto: 'passport_bayo.jpg', cac: 'cac_modernwears.pdf'}, bankDetails: { bankName: 'Moniepoint MFB', accountNumber: '9876543210', accountName: 'Bayo Adekunle Modern' } },
      { id: 'SELLER003', storeName: 'Kiddies Corner', contactName: 'Fatima Yusuf', email: 'fatima@kiddies.ng', phone: '07011223344', status: 'Rejected', dateApplied: '2025-05-01', itemsListed: 0, totalSales: 0, documents: { ninNumber: '55566677788', ninFront: null, ninBack: null, bvn: 'N/A', passportPhoto: null, cac: null}, bankDetails: { bankName: 'Moniepoint MFB', accountNumber: '5556667778', accountName: 'Fatima Yusuf Kiddies' }, rejectionReason: 'Incomplete NIN documentation.' },
      { id: 'SELLER004', storeName: 'Urban Threads', contactName: 'David Eze', email: 'david.eze@urban.com', phone: '08155566777', status: 'Pending', dateApplied: '2025-05-23', itemsListed: 0, totalSales: 0, documents: { ninNumber: '10203040506', ninFront: 'nin_front_david.jpg', ninBack: 'nin_back_david.jpg', bvn: '66677788899', passportPhoto: 'passport_david.jpg', cac: 'cac_urban.pdf'}, bankDetails: { bankName: 'Moniepoint MFB', accountNumber: '1020304050', accountName: 'David Eze Urban' } },
    ];

    const AdminManageSellersPage = () => {
      const [sellers, setSellers] = useState(mockSellers);
      const [searchTerm, setSearchTerm] = useState('');
      const [statusFilter, setStatusFilter] = useState('all');
      const [selectedSeller, setSelectedSeller] = useState(null);
      const [isViewModalOpen, setIsViewModalOpen] = useState(false);
      const [isChatModalOpen, setIsChatModalOpen] = useState(false);
      const [chatMessage, setChatMessage] = useState('');
      const { toast } = useToast();

      const handleUpdateStatus = (sellerId, newStatus, rejectionReason = '') => {
        setSellers(prevSellers => 
          prevSellers.map(s => s.id === sellerId ? { ...s, status: newStatus, rejectionReason: newStatus === 'Rejected' ? rejectionReason : s.rejectionReason } : s)
        );
        toast({ title: `Seller ${newStatus}`, description: `Seller ${sellerId} has been ${newStatus}.` });
        if (isViewModalOpen) setIsViewModalOpen(false);
      };

      const openViewModal = (seller) => {
        setSelectedSeller(seller);
        setIsViewModalOpen(true);
      };
      
      const openChatModal = (seller) => {
        setSelectedSeller(seller);
        setIsChatModalOpen(true);
        setChatMessage('');
      };

      const handleSendChatMessage = () => {
        if (!chatMessage.trim() || !selectedSeller) return;
        toast({ title: "Message Sent (Mock)", description: `Message to ${selectedSeller.storeName}: "${chatMessage}"`});
        console.log(`Message to ${selectedSeller.storeName} (${selectedSeller.email}): ${chatMessage}`);
        setIsChatModalOpen(false);
      };


      const filteredSellers = useMemo(() => {
        return sellers
          .filter(seller => statusFilter === 'all' || seller.status.toLowerCase() === statusFilter.toLowerCase())
          .filter(seller => 
            seller.storeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            seller.contactName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            seller.email.toLowerCase().includes(searchTerm.toLowerCase())
          );
      }, [sellers, searchTerm, statusFilter]);

      const getStatusBadgeVariant = (status) => {
        if (status === 'Approved') return 'success';
        if (status === 'Rejected') return 'destructive';
        return 'secondary';
      };

      return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 text-keroluxe-black dark:text-keroluxe-white">
          <h1 className="text-2xl md:text-3xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Manage Seller Applications & Profiles</h1>
          
          <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/10">
            <CardHeader>
              <CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white">Filter & Search Sellers</CardTitle>
              <div className="flex flex-col md:flex-row gap-4 pt-2">
                <div className="flex-grow flex items-center space-x-2 p-2 bg-keroluxe-off-white dark:bg-neutral-700 rounded-md">
                  <Search className="h-5 w-5 text-keroluxe-grey dark:text-neutral-400" />
                  <Input 
                    type="text" 
                    placeholder="Search by Store, Contact Name or Email..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="border-0 focus:ring-0 bg-transparent flex-1 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Filter className="h-5 w-5 text-keroluxe-grey dark:text-neutral-400" />
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full md:w-[180px] bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white focus:border-keroluxe-gold">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white">
                      <SelectItem value="all" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">All Statuses</SelectItem>
                      <SelectItem value="pending" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Pending</SelectItem>
                      <SelectItem value="approved" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Approved</SelectItem>
                      <SelectItem value="rejected" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b dark:border-neutral-700">
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Store Name</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Contact Name</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Date Applied</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Status</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSellers.map((seller) => (
                    <TableRow key={seller.id} className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b dark:border-neutral-700 last:border-b-0">
                      <TableCell className="font-medium text-keroluxe-black dark:text-keroluxe-off-white">{seller.storeName}</TableCell>
                      <TableCell className="text-keroluxe-grey dark:text-neutral-300">{seller.contactName}</TableCell>
                      <TableCell className="text-keroluxe-grey dark:text-neutral-300">{seller.dateApplied}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(seller.status)} className="capitalize">
                          {seller.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right space-x-1">
                        <Button variant="ghost" size="icon" onClick={() => openViewModal(seller)} className="text-keroluxe-grey dark:text-neutral-400 hover:text-keroluxe-gold dark:hover:text-keroluxe-off-white" title="View Details">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => openChatModal(seller)} className="text-keroluxe-grey dark:text-neutral-400 hover:text-keroluxe-gold dark:hover:text-keroluxe-off-white" title="Chat with Seller">
                          <MessageIcon className="h-4 w-4" />
                        </Button>
                        {seller.status === 'Pending' && (
                          <>
                            <Button variant="ghost" size="icon" onClick={() => handleUpdateStatus(seller.id, 'Approved')} className="text-green-600 dark:text-green-400 hover:text-green-700 dark:hover:text-green-300" title="Approve Seller">
                              <CheckCircle className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleUpdateStatus(seller.id, 'Rejected', 'Reason not specified')} className="text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300" title="Reject Seller">
                              <XCircle className="h-4 w-4" />
                            </Button>
                          </>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {filteredSellers.length === 0 && <p className="text-center text-keroluxe-grey dark:text-neutral-400 py-8">No sellers found matching your criteria.</p>}
            </CardContent>
          </Card>

          {selectedSeller && (
            <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
              <DialogContent className="sm:max-w-lg bg-keroluxe-white dark:bg-neutral-800 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white">
                <DialogHeader>
                  <DialogTitle className="text-keroluxe-black dark:text-keroluxe-white font-serif text-xl flex items-center">
                    <Briefcase className="mr-2 h-5 w-5 text-keroluxe-gold" /> Seller Details: {selectedSeller.storeName}
                  </DialogTitle>
                  <ShadDialogDescription className="text-keroluxe-grey dark:text-neutral-400">
                    Review application details for {selectedSeller.contactName}.
                  </ShadDialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-3 text-sm max-h-[60vh] overflow-y-auto pr-2">
                  <p><strong className="text-keroluxe-black dark:text-keroluxe-off-white">Contact Name:</strong> <span className="text-keroluxe-grey dark:text-neutral-300">{selectedSeller.contactName}</span></p>
                  <p><strong className="text-keroluxe-black dark:text-keroluxe-off-white">Email:</strong> <span className="text-keroluxe-grey dark:text-neutral-300">{selectedSeller.email}</span></p>
                  <p><strong className="text-keroluxe-black dark:text-keroluxe-off-white">Phone:</strong> <span className="text-keroluxe-grey dark:text-neutral-300">{selectedSeller.phone}</span></p>
                  <p><strong className="text-keroluxe-black dark:text-keroluxe-off-white">Date Applied:</strong> <span className="text-keroluxe-grey dark:text-neutral-300">{selectedSeller.dateApplied}</span></p>
                  <p><strong className="text-keroluxe-black dark:text-keroluxe-off-white">Status:</strong> <Badge variant={getStatusBadgeVariant(selectedSeller.status)} className="capitalize ml-1">{selectedSeller.status}</Badge></p>
                  {selectedSeller.status === 'Rejected' && selectedSeller.rejectionReason && (
                    <p><strong className="text-red-500 dark:text-red-400">Rejection Reason:</strong> <span className="text-keroluxe-grey dark:text-neutral-300">{selectedSeller.rejectionReason}</span></p>
                  )}
                  <div className="pt-2">
                    <strong className="text-keroluxe-black dark:text-keroluxe-off-white block mb-1">Bank Details (Moniepoint):</strong>
                    <ul className="list-disc list-inside pl-4 space-y-1 text-keroluxe-grey dark:text-neutral-300">
                      <li>Account Name: {selectedSeller.bankDetails?.accountName || 'N/A'}</li>
                      <li>Account Number: {selectedSeller.bankDetails?.accountNumber || 'N/A'}</li>
                    </ul>
                  </div>
                  <div className="pt-2">
                    <strong className="text-keroluxe-black dark:text-keroluxe-off-white block mb-1">Document Status:</strong>
                    <ul className="list-disc list-inside pl-4 space-y-1 text-keroluxe-grey dark:text-neutral-300">
                      <li>NIN Number: {selectedSeller.documents?.ninNumber || 'N/A'}</li>
                      <li>NIN Front: {selectedSeller.documents?.ninFront ? <a href="#" className="text-keroluxe-gold hover:underline">View</a> : 'Not Uploaded'}</li>
                      <li>NIN Back: {selectedSeller.documents?.ninBack ? <a href="#" className="text-keroluxe-gold hover:underline">View</a> : 'Not Uploaded'}</li>
                      <li>BVN: {selectedSeller.documents?.bvn || 'N/A'}</li>
                      <li>Passport Photo: {selectedSeller.documents?.passportPhoto ? <a href="#" className="text-keroluxe-gold hover:underline">View</a> : 'Not Uploaded'}</li>
                      <li>CAC Document: {selectedSeller.documents?.cac ? <a href="#" className="text-keroluxe-gold hover:underline">View</a> : 'Not Uploaded'}</li>
                    </ul>
                  </div>
                  {selectedSeller.status === 'Approved' && (
                    <>
                     <p><strong className="text-keroluxe-black dark:text-keroluxe-off-white">Items Listed:</strong> <span className="text-keroluxe-grey dark:text-neutral-300">{selectedSeller.itemsListed}</span></p>
                     <p><strong className="text-keroluxe-black dark:text-keroluxe-off-white">Total Sales:</strong> <span className="text-keroluxe-grey dark:text-neutral-300">₦{selectedSeller.totalSales.toLocaleString()}</span></p>
                    </>
                  )}
                </div>
                <DialogFooter className="gap-2 sm:gap-0 pt-4 border-t dark:border-neutral-700">
                  {selectedSeller.status === 'Pending' && (
                    <>
                    <Button onClick={() => {handleUpdateStatus(selectedSeller.id, 'Rejected', prompt("Enter reason for rejection (optional):") || 'Documentation incomplete/invalid.');}} variant="outline" className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white dark:border-red-500 dark:text-red-400 dark:hover:bg-red-500 dark:hover:text-white">Reject</Button>
                    <Button onClick={() => {handleUpdateStatus(selectedSeller.id, 'Approved');}} className="btn-primary">Approve</Button>
                    </>
                  )}
                  <DialogClose asChild>
                    <Button type="button" variant="outline" className="border-keroluxe-gold text-keroluxe-gold hover:bg-keroluxe-gold hover:text-keroluxe-black dark:text-keroluxe-white dark:hover:bg-keroluxe-gold dark:hover:text-keroluxe-black">Close</Button>
                  </DialogClose>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}

          {selectedSeller && (
            <Dialog open={isChatModalOpen} onOpenChange={setIsChatModalOpen}>
              <DialogContent className="sm:max-w-md bg-keroluxe-white dark:bg-neutral-800 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white">
                <DialogHeader>
                  <DialogTitle className="font-serif text-xl flex items-center">
                    <MessageIcon className="mr-2 h-5 w-5 text-keroluxe-gold" /> Chat with {selectedSeller.storeName}
                  </DialogTitle>
                </DialogHeader>
                <div className="py-4 space-y-3">
                  <Label htmlFor="chatMessageInput">Your Message</Label>
                  <Textarea 
                    id="chatMessageInput" 
                    value={chatMessage} 
                    onChange={(e) => setChatMessage(e.target.value)} 
                    placeholder={`Type your message to ${selectedSeller.contactName}...`} 
                    rows={4}
                    className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold"
                  />
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsChatModalOpen(false)} className="border-keroluxe-grey dark:border-neutral-600">Cancel</Button>
                  <Button onClick={handleSendChatMessage} className="btn-primary">Send Message</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}

        </motion.div>
      );
    };

    export default AdminManageSellersPage;