import React, { useState, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Badge } from '@/components/ui/badge';
    import { Input } from '@/components/ui/input';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Truck, PackageCheck, Search, Filter, Clock, CheckCircle } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';

    const mockParcels = [
      { id: 'PARCEL001', orderId: 'KERO456ABC', sellerStore: 'Modern Wears Inc.', customerName: 'Bob The Builder', dateNotified: '2025-05-24', status: 'Ready for Pickup', items: 1, location: 'Lagos Warehouse A' },
      { id: 'PARCEL002', orderId: 'KERO202JKL', sellerStore: 'Edward Scissorhands Store', customerName: 'Edward Scissorhands', dateNotified: '2025-05-23', status: 'Picked Up', items: 4, location: 'Abuja Hub' },
      { id: 'PARCEL003', orderId: 'KERO303MNO', sellerStore: 'Fiona\'s Finds', customerName: 'Fiona Gallagher', dateNotified: '2025-05-25', status: 'In Transit', items: 1, location: 'On route to PH' },
      { id: 'PARCEL004', orderId: 'KERO999ZZZ', sellerStore: 'Vintage Vibes NG', customerName: 'Ada Okoro', dateNotified: '2025-05-25', status: 'Ready for Pickup', items: 3, location: 'Lagos Warehouse B' },
    ];

    const dispatchStatusOptions = ["Ready for Pickup", "Picked Up", "In Transit", "Delivered"];

    const DispatchFilterControls = ({ searchTerm, setSearchTerm, statusFilter, setStatusFilter }) => (
      <div className="flex flex-col md:flex-row gap-4 pt-2">
        <div className="flex-grow flex items-center space-x-2 p-2 bg-keroluxe-off-white dark:bg-neutral-700 rounded-md">
          <Search className="h-5 w-5 text-keroluxe-grey dark:text-neutral-400" />
          <Input 
            type="text" 
            placeholder="Search by Order ID, Store, or Customer..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="border-0 focus:ring-0 bg-transparent flex-1 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Filter className="h-5 w-5 text-keroluxe-grey dark:text-neutral-400" />
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-[200px] bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white focus:border-keroluxe-gold">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white">
              <SelectItem value="all" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">All Statuses</SelectItem>
              {dispatchStatusOptions.map(opt => (
                <SelectItem key={opt.toLowerCase().replace(/\s/g, '')} value={opt.toLowerCase().replace(/\s/g, '')} className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">{opt}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    );

    const getStatusBadge = (status) => {
      switch (status.toLowerCase().replace(/\s/g, '')) {
        case 'readyforpickup': return <Badge variant="warning" className="flex items-center text-xs sm:text-sm"><Clock className="mr-1 h-3 w-3" />Ready for Pickup</Badge>;
        case 'pickedup': return <Badge variant="info" className="flex items-center text-xs sm:text-sm"><PackageCheck className="mr-1 h-3 w-3" />Picked Up</Badge>;
        case 'intransit': return <Badge variant="default" className="bg-blue-500 hover:bg-blue-600 text-white flex items-center text-xs sm:text-sm"><Truck className="mr-1 h-3 w-3" />In Transit</Badge>;
        case 'delivered': return <Badge variant="success" className="flex items-center text-xs sm:text-sm"><CheckCircle className="mr-1 h-3 w-3" />Delivered</Badge>;
        default: return <Badge variant="outline" className="text-xs sm:text-sm">{status}</Badge>;
      }
    };

    const DispatchTable = ({ parcels, onUpdateStatus }) => (
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b dark:border-neutral-700">
            <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Order ID</TableHead>
            <TableHead className="text-keroluxe-black dark:text-keroluxe-white hidden md:table-cell">Seller Store</TableHead>
            <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Customer</TableHead>
            <TableHead className="text-keroluxe-black dark:text-keroluxe-white hidden lg:table-cell">Notified</TableHead>
            <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Status</TableHead>
            <TableHead className="text-keroluxe-black dark:text-keroluxe-white text-right">Update Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {parcels.map((parcel) => (
            <TableRow key={parcel.id} className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b dark:border-neutral-700 last:border-b-0">
              <TableCell className="font-medium text-keroluxe-black dark:text-keroluxe-off-white text-xs sm:text-sm">{parcel.orderId}</TableCell>
              <TableCell className="text-keroluxe-grey dark:text-neutral-300 hidden md:table-cell text-xs sm:text-sm">{parcel.sellerStore}</TableCell>
              <TableCell className="text-keroluxe-grey dark:text-neutral-300 text-xs sm:text-sm">{parcel.customerName}</TableCell>
              <TableCell className="text-keroluxe-grey dark:text-neutral-300 hidden lg:table-cell text-xs sm:text-sm">{parcel.dateNotified}</TableCell>
              <TableCell>{getStatusBadge(parcel.status)}</TableCell>
              <TableCell className="text-right">
                <Select defaultValue={parcel.status} onValueChange={(newStatus) => onUpdateStatus(parcel.id, newStatus)}>
                  <SelectTrigger className="w-full sm:w-[140px] md:w-[160px] bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white focus:border-keroluxe-gold text-xs h-8">
                    <SelectValue placeholder="Update status" />
                  </SelectTrigger>
                  <SelectContent className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white">
                    {dispatchStatusOptions.map(opt => (
                      <SelectItem key={opt} value={opt} className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20 text-xs">{opt}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );


    const AdminDispatchCenterPage = () => {
      const [parcels, setParcels] = useState(mockParcels);
      const [searchTerm, setSearchTerm] = useState('');
      const [statusFilter, setStatusFilter] = useState('all');
      const { toast } = useToast();

      const handleUpdateStatus = (parcelId, newStatus) => {
        setParcels(prevParcels => 
          prevParcels.map(p => p.id === parcelId ? { ...p, status: newStatus } : p)
        );
        toast({ title: "Parcel Status Updated", description: `Parcel ${parcelId} is now ${newStatus}.` });
      };

      const filteredParcels = useMemo(() => {
        return parcels
          .filter(parcel => statusFilter === 'all' || parcel.status.toLowerCase().replace(/\s/g, '') === statusFilter.toLowerCase())
          .filter(parcel => 
            parcel.orderId.toLowerCase().includes(searchTerm.toLowerCase()) ||
            parcel.sellerStore.toLowerCase().includes(searchTerm.toLowerCase()) ||
            parcel.customerName.toLowerCase().includes(searchTerm.toLowerCase())
          );
      }, [parcels, searchTerm, statusFilter]);

      return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 text-keroluxe-black dark:text-keroluxe-white">
          <h1 className="text-2xl md:text-3xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Dispatch Center</h1>
          
          <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-xl border-keroluxe-gold/10">
            <CardHeader>
              <CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white">Manage Parcel Dispatch</CardTitle>
              <CardDescription className="text-keroluxe-grey dark:text-neutral-400">
                Track parcels from seller pickup notifications to customer delivery.
              </CardDescription>
              <DispatchFilterControls 
                searchTerm={searchTerm} 
                setSearchTerm={setSearchTerm} 
                statusFilter={statusFilter} 
                setStatusFilter={setStatusFilter} 
              />
            </CardHeader>
            <CardContent className="overflow-x-auto">
              {filteredParcels.length === 0 ? (
                <p className="text-center text-keroluxe-grey dark:text-neutral-400 py-8">No parcels found matching your criteria.</p>
              ) : (
                <DispatchTable parcels={filteredParcels} onUpdateStatus={handleUpdateStatus} />
              )}
            </CardContent>
            <CardDescription className="p-4 text-xs text-keroluxe-grey dark:text-neutral-500">
              Sellers notify admin when items are ready. Admin updates status through pickup to delivery.
            </CardDescription>
          </Card>
        </motion.div>
      );
    };

    export default AdminDispatchCenterPage;