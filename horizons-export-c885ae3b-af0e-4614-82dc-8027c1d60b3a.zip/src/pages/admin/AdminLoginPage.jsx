import React, { useState } from 'react';
    import { useNavigate, Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
    import { Shield, LogIn, Info } from 'lucide-react';
    import { useAppContext } from '@/contexts/AppContext';
    import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";


    const AdminLoginPage = () => {
      const [email, setEmail] = useState('admin@keroluxe.com'); // Default admin email
      const [password, setPassword] = useState('password123'); // Default admin password
      const { login, isLoading } = useAppContext();
      const navigate = useNavigate();
      
      const handleSubmit = async (e) => {
        e.preventDefault();
        const success = await login(email, password);
        if (success) {
          // Navigation handled by AppContext
        }
      };

      return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-tr from-neutral-900 via-keroluxe-black to-neutral-800 p-4">
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="w-full max-w-md"
          >
            <Alert className="mb-4 bg-keroluxe-gold/10 border-keroluxe-gold text-keroluxe-gold dark:bg-keroluxe-gold/20 dark:text-keroluxe-off-white">
              <Info className="h-4 w-4 !text-keroluxe-gold dark:!text-keroluxe-off-white" />
              <AlertTitle className="font-semibold">Demo Admin Credentials</AlertTitle>
              <AlertDescription className="text-xs">
                Use <strong className="text-keroluxe-rose-gold">admin@keroluxe.com</strong> and password <strong className="text-keroluxe-rose-gold">password123</strong>. Ensure this user exists in your Supabase 'auth.users' table and has the 'admin' role in the 'profiles' table.
              </AlertDescription>
            </Alert>
            <Card className="bg-keroluxe-off-white dark:bg-neutral-800 shadow-2xl border-2 border-keroluxe-gold">
              <CardHeader className="text-center space-y-3">
                <Shield className="h-16 w-16 text-keroluxe-gold mx-auto" />
                <CardTitle className="text-4xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Admin Access</CardTitle>
                <CardDescription className="text-keroluxe-grey dark:text-neutral-400">KeroLuxe Administration Panel</CardDescription>
              </CardHeader>
              <form onSubmit={handleSubmit}>
                <CardContent className="space-y-6 px-8 py-6">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-keroluxe-black dark:text-keroluxe-off-white">Admin Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="admin@keroluxe.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="bg-white dark:bg-neutral-700 border-keroluxe-gold/50 focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-keroluxe-black dark:text-keroluxe-off-white">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="bg-white dark:bg-neutral-700 border-keroluxe-gold/50 focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white"
                    />
                  </div>
                </CardContent>
                <CardFooter className="px-8 pb-8">
                  <Button type="submit" className="w-full bg-keroluxe-gold text-keroluxe-black hover:bg-keroluxe-gold/80 dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black text-lg py-3" disabled={isLoading}>
                    {isLoading ? 'Authenticating...' : 'Enter Secure Panel'}
                    {!isLoading && <LogIn className="ml-2 h-5 w-5" />}
                  </Button>
                </CardFooter>
              </form>
                <p className="text-xs text-center pb-4 text-keroluxe-grey dark:text-neutral-500">
                 <Link to="/login">Back to Customer Login</Link>
                </p>
            </Card>
          </motion.div>
        </div>
      );
    };

    export default AdminLoginPage;