import React, { useState, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Eye, Edit, Search, Filter, CheckCircle, Truck, Package, AlertCircle } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';

    const mockOrders = [
      { id: 'KERO123XYZ', customer: 'Alice Wonderland', date: '2025-05-21', total: 129.97, status: 'Shipped', items: 2, payment: 'Paid' },
      { id: 'KERO456ABC', customer: 'Bob The Builder', date: '2025-05-20', total: 59.99, status: 'Processing', items: 1, payment: 'Paid' },
      { id: 'KERO789DEF', customer: 'Charlie Brown', date: '2025-05-19', total: 24.99, status: 'Delivered', items: 1, payment: 'Paid' },
      { id: 'KERO101GHI', customer: 'Diana Prince', date: '2025-05-22', total: 89.50, status: 'Pending Payment', items: 3, payment: 'Pending' },
      { id: 'KERO202JKL', customer: 'Edward Scissorhands', date: '2025-05-22', total: 199.00, status: 'Processing', items: 4, payment: 'Paid' },
    ];

    const AdminOrdersPage = () => {
      const [orders, setOrders] = useState(mockOrders);
      const [searchTerm, setSearchTerm] = useState('');
      const [statusFilter, setStatusFilter] = useState('all');
      const { toast } = useToast();

      const handleStatusChange = (orderId, newStatus) => {
        setOrders(prevOrders => prevOrders.map(order => 
          order.id === orderId ? { ...order, status: newStatus } : order
        ));
        toast({ title: "Order Status Updated", description: `Order ${orderId} status changed to ${newStatus}.` });
      };

      const filteredOrders = useMemo(() => orders.filter(order => {
        const matchesSearch = order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                              order.customer.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = statusFilter === 'all' || order.status.toLowerCase() === statusFilter.toLowerCase();
        return matchesSearch && matchesStatus;
      }), [orders, searchTerm, statusFilter]);


      const getStatusBadge = (status) => {
        switch (status.toLowerCase()) {
          case 'shipped': return <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-700 dark:bg-blue-700/30 dark:text-blue-300 rounded-full flex items-center"><Truck className="mr-1 h-3 w-3" />Shipped</span>;
          case 'processing': return <span className="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-700 dark:bg-yellow-700/30 dark:text-yellow-300 rounded-full flex items-center"><Package className="mr-1 h-3 w-3" />Processing</span>;
          case 'delivered': return <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-700 dark:bg-green-700/30 dark:text-green-300 rounded-full flex items-center"><CheckCircle className="mr-1 h-3 w-3" />Delivered</span>;
          case 'pending payment': return <span className="px-2 py-1 text-xs font-medium bg-red-100 text-red-700 dark:bg-red-700/30 dark:text-red-300 rounded-full flex items-center"><AlertCircle className="mr-1 h-3 w-3" />Pending Payment</span>;
          default: return <span className="px-2 py-1 text-xs font-medium bg-gray-100 text-gray-700 dark:bg-neutral-700 dark:text-neutral-300 rounded-full">{status}</span>;
        }
      };

      return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 text-keroluxe-black dark:text-keroluxe-white">
          <h1 className="text-3xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Track Orders</h1>
          
          <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10">
            <CardHeader>
              <CardTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white">Filter & Search Orders</CardTitle>
              <div className="flex flex-col md:flex-row gap-4 pt-2">
                <div className="flex-grow flex items-center space-x-2 p-2 bg-keroluxe-off-white dark:bg-neutral-700 rounded-md">
                  <Search className="h-5 w-5 text-keroluxe-grey dark:text-neutral-400" />
                  <Input 
                    type="text" 
                    placeholder="Search by Order ID or Customer Name..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="border-0 focus:ring-0 bg-transparent flex-1 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Filter className="h-5 w-5 text-keroluxe-grey dark:text-neutral-400" />
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full md:w-[180px] bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white focus:border-keroluxe-gold">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white">
                      <SelectItem value="all" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">All Statuses</SelectItem>
                      <SelectItem value="processing" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Processing</SelectItem>
                      <SelectItem value="shipped" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Shipped</SelectItem>
                      <SelectItem value="delivered" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Delivered</SelectItem>
                      <SelectItem value="pending payment" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Pending Payment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b dark:border-neutral-700">
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Order ID</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Customer</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Date</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white text-right">Total</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Status</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white">Payment</TableHead>
                    <TableHead className="text-keroluxe-black dark:text-keroluxe-white text-center">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOrders.map((order) => (
                    <TableRow key={order.id} className="hover:bg-keroluxe-off-white/50 dark:hover:bg-neutral-700/50 border-b dark:border-neutral-700 last:border-b-0">
                      <TableCell className="font-medium text-keroluxe-black dark:text-keroluxe-off-white">{order.id}</TableCell>
                      <TableCell className="text-keroluxe-grey dark:text-neutral-300">{order.customer}</TableCell>
                      <TableCell className="text-keroluxe-grey dark:text-neutral-300">{order.date}</TableCell>
                      <TableCell className="text-right text-keroluxe-grey dark:text-neutral-300">₦{order.total.toFixed(2)}</TableCell>
                      <TableCell>{getStatusBadge(order.status)}</TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${order.payment === 'Paid' ? 'bg-green-100 text-green-700 dark:bg-green-700/30 dark:text-green-300' : 'bg-red-100 text-red-700 dark:bg-red-700/30 dark:text-red-300'}`}>
                          {order.payment}
                        </span>
                      </TableCell>
                      <TableCell className="text-center space-x-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-keroluxe-grey dark:text-neutral-400 hover:text-keroluxe-gold dark:hover:text-keroluxe-off-white">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Select 
                          defaultValue={order.status} 
                          onValueChange={(newStatus) => handleStatusChange(order.id, newStatus)}
                        >
                          <SelectTrigger className="h-8 w-8 p-0 inline-flex items-center justify-center border-0 bg-transparent text-keroluxe-grey dark:text-neutral-400 hover:text-keroluxe-gold dark:hover:text-keroluxe-off-white focus:ring-0">
                             <Edit className="h-4 w-4" />
                          </SelectTrigger>
                          <SelectContent className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white">
                            <SelectItem value="Processing" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Processing</SelectItem>
                            <SelectItem value="Shipped" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Shipped</SelectItem>
                            <SelectItem value="Delivered" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Delivered</SelectItem>
                            <SelectItem value="Pending Payment" className="hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/20">Pending Payment</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {filteredOrders.length === 0 && <p className="text-center text-keroluxe-grey dark:text-neutral-400 py-8">No orders found matching your criteria.</p>}
            </CardContent>
          </Card>
        </motion.div>
      );
    };

    export default AdminOrdersPage;