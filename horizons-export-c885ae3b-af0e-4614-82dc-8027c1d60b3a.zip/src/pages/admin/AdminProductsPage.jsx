import React, { useState, useEffect } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Textarea } from '@/components/ui/textarea';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
    import { PlusCircle, Edit, Trash2, Search, AlertTriangle, PackagePlus } from 'lucide-react';
    import { products as initialProductsData, categories as initialCategoriesData } from '@/data/products';
    import { useToast } from '@/components/ui/use-toast';

    const LOW_STOCK_THRESHOLD = 10;

    const AdminProductsPage = () => {
      const [products, setProducts] = useState(initialProductsData.filter(p => p.seller?.name === 'KeroLuxe Admin' || !p.seller));
      const [categories, setCategories] = useState(initialCategoriesData);
      const [searchTerm, setSearchTerm] = useState('');
      const [isFormOpen, setIsFormOpen] = useState(false);
      const [currentProduct, setCurrentProduct] = useState(null);
      const [formData, setFormData] = useState({
        name: '', category: '', price: '', stock: '', description: '', imageUrlPlaceholder: '',
        fabric: '', care: '', sizes: '', colors: '', labels: ''
      });
      const { toast } = useToast();

      useEffect(() => {
        const adminProducts = initialProductsData.filter(p => p.seller?.name === 'KeroLuxe Admin' || !p.seller);
        setProducts(adminProducts);
      }, []);


      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
      };

      const handleSubmit = (e) => {
        e.preventDefault();
        const productData = {
          ...formData,
          id: currentProduct ? currentProduct.id : String(Date.now()),
          price: parseFloat(formData.price) || 0,
          stock: parseInt(formData.stock) || 0,
          rating: currentProduct ? currentProduct.rating : (Math.random() * (5 - 3.5) + 3.5).toFixed(1),
          sizes: formData.sizes.split(',').map(s => s.trim()).filter(s => s),
          colors: formData.colors.split(',').map(c => { const parts = c.split(':'); return { name: parts[0].trim(), hex: parts[1] ? parts[1].trim() : '#000000' }; }).filter(c => c.name),
          labels: formData.labels.split(',').map(l => l.trim()).filter(l => l),
          images: formData.imageUrlPlaceholder ? [formData.imageUrlPlaceholder, formData.imageUrlPlaceholder, formData.imageUrlPlaceholder] : ['product image placeholder', 'product image placeholder', 'product image placeholder'],
          seller: { name: 'KeroLuxe Admin', rating: 4.9, id: 'keroluxe-admin' }
        };

        if (currentProduct) {
          setProducts(prev => prev.map(p => p.id === currentProduct.id ? productData : p));
          toast({ title: "Product Updated", description: `${productData.name} has been updated.` });
        } else {
          setProducts(prev => [productData, ...prev]);
          toast({ title: "Product Added", description: `${productData.name} has been added.` });
        }
        setIsFormOpen(false);
        setCurrentProduct(null);
        setFormData({ name: '', category: '', price: '', stock: '', description: '', imageUrlPlaceholder: '', fabric: '', care: '', sizes: '', colors: '', labels: '' });
      };

      const handleEdit = (product) => {
        setCurrentProduct(product);
        setFormData({
          name: product.name,
          category: product.category,
          price: String(product.price),
          stock: String(product.stock),
          description: product.description,
          imageUrlPlaceholder: product.imageUrlPlaceholder || product.images?.[0] || '',
          fabric: product.fabric || '',
          care: product.care || '',
          sizes: product.sizes ? product.sizes.join(', ') : '',
          colors: product.colors ? product.colors.map(c => `${c.name}:${c.hex}`).join(', ') : '',
          labels: product.labels ? product.labels.join(', ') : ''
        });
        setIsFormOpen(true);
      };

      const handleDelete = (productId) => {
        setProducts(prev => prev.filter(p => p.id !== productId));
        toast({ title: "Product Deleted", description: "The product has been removed.", variant: "destructive" });
      };
      
      const openNewProductForm = () => {
        setCurrentProduct(null);
        setFormData({ name: '', category: '', price: '', stock: '', description: '', imageUrlPlaceholder: '', fabric: '', care: '', sizes: '', colors: '', labels: '' });
        setIsFormOpen(true);
      };

      const filteredProducts = products.filter(product =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.category.toLowerCase().includes(searchTerm.toLowerCase())
      );

      return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 md:space-y-8 text-keroluxe-black dark:text-keroluxe-white">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h1 className="text-2xl md:text-3xl font-bold font-serif">Official Store Products</h1>
            <Button onClick={openNewProductForm} className="btn-primary w-full sm:w-auto">
              <PackagePlus className="mr-2 h-5 w-5" /> Add New Product
            </Button>
          </div>

          <Card className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10">
            <CardHeader>
              <div className="flex items-center space-x-2 p-2 bg-keroluxe-off-white dark:bg-neutral-700 rounded-md">
                <Search className="h-5 w-5 text-keroluxe-grey dark:text-neutral-400" />
                <Input 
                  type="text" 
                  placeholder="Search products by name or category..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="border-0 focus:ring-0 bg-transparent flex-1 text-keroluxe-black dark:text-keroluxe-white placeholder:text-keroluxe-grey dark:placeholder:text-neutral-400"
                />
              </div>
            </CardHeader>
            <CardContent>
              {filteredProducts.length === 0 ? (
                <p className="text-center text-keroluxe-grey dark:text-neutral-400 py-8">No products found. Add some to get started!</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                  {filteredProducts.map(product => (
                    <Card key={product.id} className="bg-keroluxe-off-white/50 dark:bg-neutral-700/30 shadow-md hover:shadow-xl transition-shadow border-keroluxe-gold/10 overflow-hidden">
                      <div className="h-48 bg-neutral-200 dark:bg-neutral-600 overflow-hidden relative">
                        <img  alt={product.name} className="w-full h-full object-cover" src={`https://source.unsplash.com/random/400x300/?${encodeURIComponent(product.imageUrlPlaceholder || product.name)}`} />
                        {product.stock < LOW_STOCK_THRESHOLD && (
                           <div className="absolute top-2 right-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full flex items-center">
                             <AlertTriangle className="h-3 w-3 mr-1" /> Low Stock
                           </div>
                        )}
                      </div>
                      <CardHeader className="p-3">
                        <CardTitle className="text-lg font-serif text-keroluxe-black dark:text-keroluxe-white truncate" title={product.name}>{product.name}</CardTitle>
                        <CardDescription className="text-xs text-keroluxe-grey dark:text-neutral-400">{product.category}</CardDescription>
                      </CardHeader>
                      <CardContent className="text-sm space-y-1 p-3">
                        <p className="text-keroluxe-black dark:text-keroluxe-off-white">Price: <span className="font-semibold text-keroluxe-gold">₦{product.price.toFixed(2)}</span></p>
                        <p className={`text-keroluxe-black dark:text-keroluxe-off-white ${product.stock < LOW_STOCK_THRESHOLD ? 'text-red-600 dark:text-red-400 font-semibold' : ''}`}>Stock: {product.stock}</p>
                      </CardContent>
                      <CardFooter className="flex justify-end space-x-2 bg-keroluxe-white dark:bg-neutral-800 p-3 border-t dark:border-neutral-700">
                        <Button variant="outline" size="sm" onClick={() => handleEdit(product)} className="border-keroluxe-gold text-keroluxe-gold hover:bg-keroluxe-gold/10 dark:text-keroluxe-off-white dark:border-keroluxe-gold dark:hover:bg-keroluxe-gold/20">
                          <Edit className="mr-1 h-4 w-4" /> Edit
                        </Button>
                        <Button variant="destructive" size="sm" onClick={() => handleDelete(product.id)}>
                          <Trash2 className="mr-1 h-4 w-4" /> Delete
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
            <DialogContent className="sm:max-w-2xl bg-keroluxe-white dark:bg-neutral-800 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white">
              <DialogHeader>
                <DialogTitle className="text-2xl font-serif">{currentProduct ? 'Edit Product' : 'Add New Product'}</DialogTitle>
                <CardDescription className="text-keroluxe-grey dark:text-neutral-400">Fill in the details for the KeroLuxe Admin store product.</CardDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-3 md:space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                  <div><Label htmlFor="name">Product Name</Label><Input id="name" name="name" value={formData.name} onChange={handleInputChange} required className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold"/></div>
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <select id="category" name="category" value={formData.category} onChange={handleInputChange} required className="w-full h-10 rounded-md border border-input bg-keroluxe-off-white dark:bg-neutral-700 px-3 py-2 text-sm focus:border-keroluxe-gold">
                      <option value="">Select Category</option>
                      {categories.map(cat => <option key={cat.slug} value={cat.name}>{cat.name}</option>)}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                  <div><Label htmlFor="price">Price (₦)</Label><Input id="price" name="price" type="number" step="0.01" value={formData.price} onChange={handleInputChange} required className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold"/></div>
                  <div><Label htmlFor="stock">Stock Quantity</Label><Input id="stock" name="stock" type="number" value={formData.stock} onChange={handleInputChange} required className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold"/></div>
                </div>
                <div><Label htmlFor="description">Description</Label><Textarea id="description" name="description" value={formData.description} onChange={handleInputChange} required className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold" rows={3}/></div>
                <div><Label htmlFor="imageUrlPlaceholder">Image Placeholder Text (for Unsplash)</Label><Input id="imageUrlPlaceholder" name="imageUrlPlaceholder" value={formData.imageUrlPlaceholder} onChange={handleInputChange} placeholder="e.g. elegant silk nightgown" required className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold"/></div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                  <div><Label htmlFor="fabric">Fabric</Label><Input id="fabric" name="fabric" value={formData.fabric} onChange={handleInputChange} className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold"/></div>
                  <div><Label htmlFor="care">Care Instructions</Label><Input id="care" name="care" value={formData.care} onChange={handleInputChange} className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold"/></div>
                </div>
                <div><Label htmlFor="sizes">Sizes (comma-separated)</Label><Input id="sizes" name="sizes" value={formData.sizes} onChange={handleInputChange} placeholder="S, M, L, XL" className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold"/></div>
                <div><Label htmlFor="colors">Colors (name:hex, comma-separated)</Label><Input id="colors" name="colors" value={formData.colors} onChange={handleInputChange} placeholder="Champagne:#F7E7CE, Dusty Rose:#DCAE96" className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold"/></div>
                <div><Label htmlFor="labels">Labels (comma-separated)</Label><Input id="labels" name="labels" value={formData.labels} onChange={handleInputChange} placeholder="Bestseller, New Arrival, Unisex" className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold"/></div>
                <DialogFooter className="pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)} className="border-keroluxe-grey dark:border-neutral-600">Cancel</Button>
                  <Button type="submit" className="btn-primary">{currentProduct ? 'Update Product' : 'Add Product'}</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </motion.div>
      );
    };

    export default AdminProductsPage;