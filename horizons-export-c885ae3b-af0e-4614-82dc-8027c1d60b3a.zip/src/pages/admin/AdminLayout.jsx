import React, { useState } from 'react';
    import { Outlet, Link, useLocation, Navigate } from 'react-router-dom';
    import { LayoutDashboard, ShoppingCart, Package, Users, MessageSquare, Settings, LogOut, BarChart3, FileText, Menu, X, Star, UserCheck, Banknote, Truck as TruckIcon, AlertTriangle } from 'lucide-react';
    import { cn } from '@/lib/utils';
    import { Button } from '@/components/ui/button';
    import { useAppContext } from '@/contexts/AppContext';

    const AdminSidebar = ({ isOpen, toggleSidebar }) => {
      const location = useLocation();
      const { adminLogout } = useAppContext();

      const navItems = [
        { href: '/admin/dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-5 w-5" /> },
        { href: '/admin/products', label: 'Manage Products', icon: <ShoppingCart className="h-5 w-5" /> },
        { href: '/admin/orders', label: 'Track Orders', icon: <Package className="h-5 w-5" /> },
        { href: '/admin/paid-orders', label: 'Paid Orders', icon: <FileText className="h-5 w-5" /> },
        { href: '/admin/manage-sellers', label: 'Manage Sellers', icon: <UserCheck className="h-5 w-5" /> },
        { href: '/admin/seller-payouts', label: 'Seller Payouts', icon: <Banknote className="h-5 w-5" /> },
        { href: '/admin/dispatch-center', label: 'Dispatch Center', icon: <TruckIcon className="h-5 w-5" /> },
        { href: '/admin/manage-categories', label: 'Categories', icon: <Users className="h-5 w-5" /> },
        { href: '/admin/stock-alerts', label: 'Stock Alerts', icon: <AlertTriangle className="h-5 w-5" /> },
        { href: '/admin/analytics', label: 'User Analytics', icon: <BarChart3 className="h-5 w-5" /> },
        { href: '/admin/messages', label: 'Messages', icon: <MessageSquare className="h-5 w-5" /> },
        { href: '/admin/reviews', label: 'Reviews', icon: <Star className="h-5 w-5" /> },
        { href: '/admin/settings', label: 'Settings', icon: <Settings className="h-5 w-5" /> },
      ];

      return (
        <aside className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 bg-keroluxe-black text-keroluxe-off-white p-4 space-y-2 border-r border-keroluxe-gold/20 transition-transform duration-300 ease-in-out md:relative md:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}>
          <div className="flex items-center justify-between mb-6 py-3">
            <Link to="/admin/dashboard" className="text-2xl font-bold font-serif text-keroluxe-gold">KeroLuxe Admin</Link>
            <Button variant="ghost" size="icon" onClick={toggleSidebar} className="md:hidden text-keroluxe-gold hover:bg-keroluxe-gold/10">
              <X className="h-6 w-6" />
            </Button>
          </div>
          <nav className="flex flex-col space-y-1">
            {navItems.map(item => (
              <Link
                key={item.href}
                to={item.href}
                onClick={toggleSidebar} 
                className={cn(
                  "flex items-center space-x-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                  location.pathname === item.href || (item.href !== '/admin/dashboard' && location.pathname.startsWith(item.href))
                    ? "bg-keroluxe-gold text-keroluxe-black shadow-md" 
                    : "hover:bg-keroluxe-gold/20 hover:text-keroluxe-gold text-keroluxe-off-white/80"
                )}
              >
                {item.icon}
                <span>{item.label}</span>
              </Link>
            ))}
          </nav>
          <div className="pt-4 mt-auto border-t border-keroluxe-gold/20">
             <Button onClick={() => { adminLogout(); toggleSidebar(); }} variant="ghost" className="w-full justify-start text-keroluxe-off-white/80 hover:text-keroluxe-gold hover:bg-keroluxe-gold/20">
                <LogOut className="mr-3 h-5 w-5" /> Logout
             </Button>
          </div>
        </aside>
      );
    };

    const AdminLayout = () => {
      const { isAdminAuthenticated } = useAppContext();
      const [isSidebarOpen, setIsSidebarOpen] = useState(false);

      const toggleSidebar = () => {
        if (window.innerWidth < 768) { 
            setIsSidebarOpen(!isSidebarOpen);
        }
      };
      
      if (!isAdminAuthenticated) {
        return <Navigate to="/admin/login" replace />;
      }

      return (
        <div className="flex h-screen bg-keroluxe-off-white dark:bg-neutral-900">
          <AdminSidebar isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
          <div className="flex-1 flex flex-col">
            <header className="md:hidden sticky top-0 z-40 bg-keroluxe-black text-keroluxe-gold p-4 shadow-md flex items-center justify-between">
              <Link to="/admin/dashboard" className="text-xl font-bold font-serif">KeroLuxe Admin</Link>
              <Button variant="ghost" size="icon" onClick={toggleSidebar} className="text-keroluxe-gold hover:bg-keroluxe-gold/10">
                <Menu className="h-6 w-6" />
              </Button>
            </header>
            <main className="flex-1 p-4 sm:p-6 md:p-8 overflow-y-auto">
              <Outlet />
            </main>
          </div>
          {isSidebarOpen && <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={toggleSidebar}></div>}
        </div>
      );
    };

    export default AdminLayout;