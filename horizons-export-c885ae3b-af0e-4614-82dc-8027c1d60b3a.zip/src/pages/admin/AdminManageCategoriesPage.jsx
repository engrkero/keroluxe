import React, { useState } from 'react';
    import { motion } from 'framer-motion';
    import { PlusCircle, Edit, Trash2, Tag, ListTree, Save, X } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";

    const initialCategories = [
      { id: '1', name: 'Nightwear', slug: 'nightwear', subcategories: [] },
      { id: '2', name: 'Bale (First Class)', slug: 'bale-first-class', subcategories: [
        { id: 'b1', name: 'Jeans', slug: 'bale-jeans'},
        { id: 'b2', name: 'Female Tops', slug: 'bale-female-tops'},
      ]},
      { id: '3', name: 'Unisex', slug: 'unisex', subcategories: [] },
    ];

    const AdminManageCategoriesPage = () => {
      const { toast } = useToast();
      const [categories, setCategories] = useState(initialCategories);
      
      const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
      const [isSubcategoryModalOpen, setIsSubcategoryModalOpen] = useState(false);
      
      const [currentCategory, setCurrentCategory] = useState(null); 
      const [currentParentCategoryIdForSub, setCurrentParentCategoryIdForSub] = useState(null);
      const [currentSubcategory, setCurrentSubcategory] = useState(null);

      const [categoryName, setCategoryName] = useState('');
      const [subcategoryName, setSubcategoryName] = useState('');

      const generateSlug = (name) => name.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]+/g, '');

      const openNewCategoryModal = () => {
        setCurrentCategory(null);
        setCategoryName('');
        setIsCategoryModalOpen(true);
      };

      const openEditCategoryModal = (category) => {
        setCurrentCategory(category);
        setCategoryName(category.name);
        setIsCategoryModalOpen(true);
      };

      const handleSaveCategory = () => {
        if (!categoryName.trim()) {
          toast({ title: "Error", description: "Category name cannot be empty.", variant: "destructive" });
          return;
        }
        const slug = generateSlug(categoryName);
        if (currentCategory) {
          setCategories(categories.map(cat => cat.id === currentCategory.id ? { ...cat, name: categoryName, slug } : cat));
          toast({ title: "Success", description: `Category "${categoryName}" updated.` });
        } else {
          const newCategory = { id: Date.now().toString(), name: categoryName, slug, subcategories: [] };
          setCategories([...categories, newCategory]);
          toast({ title: "Success", description: `Category "${categoryName}" added.` });
        }
        setIsCategoryModalOpen(false);
      };

      const handleDeleteCategory = (categoryId) => {
        setCategories(categories.filter(cat => cat.id !== categoryId));
        toast({ title: "Success", description: "Category deleted." });
      };

      const openNewSubcategoryModal = (parentCategoryId) => {
        setCurrentParentCategoryIdForSub(parentCategoryId);
        setCurrentSubcategory(null);
        setSubcategoryName('');
        setIsSubcategoryModalOpen(true);
      };
      
      const openEditSubcategoryModal = (parentCategoryId, subcategory) => {
        setCurrentParentCategoryIdForSub(parentCategoryId);
        setCurrentSubcategory(subcategory);
        setSubcategoryName(subcategory.name);
        setIsSubcategoryModalOpen(true);
      };

      const handleSaveSubcategory = () => {
        if (!subcategoryName.trim()) {
          toast({ title: "Error", description: "Subcategory name cannot be empty.", variant: "destructive" });
          return;
        }
        const slug = generateSlug(subcategoryName);
        setCategories(categories.map(cat => {
          if (cat.id === currentParentCategoryIdForSub) {
            if (currentSubcategory) { // Editing existing subcategory
              return {
                ...cat,
                subcategories: cat.subcategories.map(sub => sub.id === currentSubcategory.id ? { ...sub, name: subcategoryName, slug } : sub)
              };
            } else { // Adding new subcategory
              const newSub = { id: Date.now().toString(), name: subcategoryName, slug };
              return { ...cat, subcategories: [...cat.subcategories, newSub] };
            }
          }
          return cat;
        }));
        toast({ title: "Success", description: `Subcategory "${subcategoryName}" ${currentSubcategory ? 'updated' : 'added'}.` });
        setIsSubcategoryModalOpen(false);
      };
      
      const handleDeleteSubcategory = (parentCategoryId, subcategoryId) => {
         setCategories(categories.map(cat => {
          if (cat.id === parentCategoryId) {
            return { ...cat, subcategories: cat.subcategories.filter(sub => sub.id !== subcategoryId) };
          }
          return cat;
        }));
        toast({ title: "Success", description: "Subcategory deleted." });
      };

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="p-4 md:p-6 space-y-6 md:space-y-8 text-keroluxe-black dark:text-keroluxe-white"
        >
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h1 className="text-2xl md:text-3xl font-bold font-serif">Manage Categories & Subcategories</h1>
            <Button onClick={openNewCategoryModal} className="btn-primary w-full sm:w-auto">
              <PlusCircle className="mr-2 h-5 w-5" /> Add New Category
            </Button>
          </div>

          <div className="space-y-6">
            <h2 className="text-xl md:text-2xl font-semibold flex items-center">
              <ListTree className="mr-2 h-6 w-6 md:h-7 md:w-7 text-keroluxe-gold" /> Existing Categories
            </h2>
            {categories.length === 0 && (
              <p className="text-center py-8 text-keroluxe-grey dark:text-neutral-400">No categories created yet. Add one to get started!</p>
            )}
            {categories.map(category => (
              <Card key={category.id} className="bg-keroluxe-white dark:bg-neutral-800 shadow-lg border-keroluxe-gold/10">
                <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-3 md:p-4 border-b dark:border-neutral-700">
                  <CardTitle className="text-lg md:text-xl font-serif flex items-center mb-2 sm:mb-0">
                    <Tag className="mr-2 h-5 w-5 text-keroluxe-gold" /> {category.name}
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" className="text-keroluxe-gold border-keroluxe-gold hover:bg-keroluxe-gold/10 dark:text-keroluxe-off-white dark:border-keroluxe-gold dark:hover:bg-keroluxe-gold/20" onClick={() => openEditCategoryModal(category)}>
                      <Edit className="mr-1 h-4 w-4" /> Edit
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => handleDeleteCategory(category.id)}>
                      <Trash2 className="mr-1 h-4 w-4" /> Delete
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-3 md:p-4">
                  <div className="pl-4 md:pl-6 border-l-2 border-keroluxe-gold/30 space-y-2 md:space-y-3">
                    {category.subcategories.length === 0 && <p className="text-sm text-keroluxe-grey dark:text-neutral-400 italic">No subcategories yet.</p>}
                    {category.subcategories.map(sub => (
                      <div key={sub.id} className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-2 bg-keroluxe-off-white dark:bg-neutral-700/50 rounded-md">
                        <span className="text-sm mb-1 sm:mb-0">{sub.name}</span>
                        <div className="flex items-center gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-xs text-keroluxe-grey dark:text-neutral-400 hover:text-keroluxe-gold dark:hover:text-keroluxe-off-white" onClick={() => openEditSubcategoryModal(category.id, sub)}>
                            <Edit className="h-3 w-3" />
                          </Button>
                           <Button variant="ghost" size="icon" className="h-7 w-7 text-xs text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300" onClick={() => handleDeleteSubcategory(category.id, sub.id)}>
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    <Button variant="link" size="sm" className="text-keroluxe-gold hover:underline p-0 mt-2 dark:text-keroluxe-gold dark:hover:text-keroluxe-off-white" onClick={() => openNewSubcategoryModal(category.id)}>
                      <PlusCircle className="mr-1 h-4 w-4" /> Add Subcategory
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Dialog open={isCategoryModalOpen} onOpenChange={setIsCategoryModalOpen}>
            <DialogContent className="sm:max-w-md bg-keroluxe-white dark:bg-neutral-800 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white">
              <DialogHeader>
                <DialogTitle className="font-serif text-xl">{currentCategory ? 'Edit Category' : 'Add New Category'}</DialogTitle>
              </DialogHeader>
              <div className="py-4 space-y-3">
                <Label htmlFor="categoryNameInput">Category Name</Label>
                <Input id="categoryNameInput" value={categoryName} onChange={(e) => setCategoryName(e.target.value)} placeholder="e.g., Footwear" className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold"/>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCategoryModalOpen(false)} className="border-keroluxe-grey dark:border-neutral-600">Cancel</Button>
                <Button onClick={handleSaveCategory} className="btn-primary"><Save className="mr-2 h-4 w-4"/>Save Category</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={isSubcategoryModalOpen} onOpenChange={setIsSubcategoryModalOpen}>
            <DialogContent className="sm:max-w-md bg-keroluxe-white dark:bg-neutral-800 border-keroluxe-gold/30 text-keroluxe-black dark:text-keroluxe-white">
              <DialogHeader>
                <DialogTitle className="font-serif text-xl">{currentSubcategory ? 'Edit Subcategory' : 'Add New Subcategory'}</DialogTitle>
                <CardDescription className="text-keroluxe-grey dark:text-neutral-400">For category: {categories.find(c => c.id === currentParentCategoryIdForSub)?.name}</CardDescription>
              </DialogHeader>
              <div className="py-4 space-y-3">
                <Label htmlFor="subcategoryNameInput">Subcategory Name</Label>
                <Input id="subcategoryNameInput" value={subcategoryName} onChange={(e) => setSubcategoryName(e.target.value)} placeholder="e.g., Sneakers" className="bg-keroluxe-off-white dark:bg-neutral-700 focus:border-keroluxe-gold"/>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsSubcategoryModalOpen(false)} className="border-keroluxe-grey dark:border-neutral-600">Cancel</Button>
                <Button onClick={handleSaveSubcategory} className="btn-primary"><Save className="mr-2 h-4 w-4"/>Save Subcategory</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

        </motion.div>
      );
    };

    export default AdminManageCategoriesPage;