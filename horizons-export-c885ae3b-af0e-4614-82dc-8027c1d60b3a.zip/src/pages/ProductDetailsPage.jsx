import React, { useState, useEffect, useCallback } from 'react';
    import { useParams, Link, useNavigate } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { products as allProductsData } from '@/data/products';
    import { Button } from '@/components/ui/button';
    import ProductCard from '@/components/ProductCard';
    import { Star, ShoppingCart, Heart } from 'lucide-react';
    import { useAppContext } from '@/contexts/AppContext';
    import { useToast } from '@/components/ui/use-toast';
    import ProductImageGallery from '@/components/product_details/ProductImageGallery';
    import ProductInfo from '@/components/product_details/ProductInfo';
    import ProductTabs from '@/components/product_details/ProductTabs';

    const ProductDetailsPage = () => {
      const { productId } = useParams();
      const { addToCart, addToWishlist, wishlist, user } = useAppContext();
      const { toast } = useToast();
      const navigate = useNavigate();
      const [product, setProduct] = useState(null);
      const [quantity, setQuantity] = useState(1);
      const [selectedSize, setSelectedSize] = useState('');
      const [selectedColor, setSelectedColor] = useState('');
      const [currentImageIndex, setCurrentImageIndex] = useState(0);
      const [isFollowingSeller, setIsFollowingSeller] = useState(false); // Mock state

      useEffect(() => {
        const foundProduct = allProductsData.find(p => p.id === productId);
        setProduct(foundProduct);
        if (foundProduct) {
          setSelectedSize(foundProduct.sizes?.[0] || '');
          setSelectedColor(foundProduct.colors?.[0]?.name || '');
          setCurrentImageIndex(0); 
        }
      }, [productId]);

      if (!product) {
        return <div className="container mx-auto text-center py-12 text-keroluxe-black dark:text-keroluxe-white">Product not found. <Link to="/" className='text-keroluxe-gold hover:underline'>Go to Homepage</Link></div>;
      }

      const isWishlisted = wishlist.some(item => item.id === product.id);

      const handleAddToCart = () => {
        addToCart({ ...product, selectedSize, selectedColor }, quantity);
        toast({
          title: "Added to Cart! 🎉",
          description: `${product.name} (${quantity}) has been added to your cart.`,
          className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold",
        });
      };

      const handleAddToWishlist = () => {
        const wasInWishlist = isWishlisted;
        addToWishlist(product); 
         toast({
          title: wasInWishlist ? "Removed from Wishlist" : "Added to Wishlist! ❤️",
          description: `${product.name} ${wasInWishlist ? 'removed from' : 'added to'} your wishlist.`,
          className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold",
        });
      };
      
      const handleBuyNow = () => {
        addToCart({ ...product, selectedSize, selectedColor }, quantity);
        toast({
          title: "Proceeding to Checkout!",
          description: `${product.name} (${quantity}) added. Redirecting...`,
          className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold",
        });
        navigate('/checkout');
      };

      const handleFollowSeller = () => {
        if (!user) {
          toast({
            title: "Login Required",
            description: "Please login to follow sellers.",
            variant: "destructive",
            className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-red-500",
          });
          navigate('/login');
          return;
        }
        setIsFollowingSeller(!isFollowingSeller);
        toast({
          title: !isFollowingSeller ? `Following ${product.seller.name}` : `Unfollowed ${product.seller.name}`,
          description: `You will ${!isFollowingSeller ? '' : 'no longer '}receive notifications for new items and promotions.`,
          className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold",
        });
      };

      const relatedProducts = allProductsData.filter(p => p.category === product.category && p.id !== product.id).slice(0, 3);

      return (
        <div className="container mx-auto py-8 px-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12"
          >
            <ProductImageGallery 
              images={product.images || []} 
              productName={product.name} 
              currentImageIndex={currentImageIndex}
              setCurrentImageIndex={setCurrentImageIndex}
            />
            <ProductInfo 
              product={product} 
              quantity={quantity} 
              setQuantity={setQuantity}
              selectedSize={selectedSize}
              setSelectedSize={setSelectedSize}
              selectedColor={selectedColor}
              setSelectedColor={setSelectedColor}
              handleAddToCart={handleAddToCart}
              handleBuyNow={handleBuyNow}
              handleAddToWishlist={handleAddToWishlist}
              isWishlisted={isWishlisted}
              handleFollowSeller={handleFollowSeller}
              isFollowingSeller={isFollowingSeller}
            />
          </motion.div>

          <ProductTabs product={product} />

          {relatedProducts.length > 0 && (
            <motion.section 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9, duration: 0.5 }}
              className="mt-16"
            >
              <h2 className="text-2xl md:text-3xl font-semibold font-serif text-keroluxe-black dark:text-keroluxe-white mb-8 text-center">You Might Also Like</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                {relatedProducts.map(relatedProduct => (
                  <ProductCard key={relatedProduct.id} product={relatedProduct} />
                ))}
              </div>
            </motion.section>
          )}
        </div>
      );
    };

    export default ProductDetailsPage;