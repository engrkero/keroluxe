import React, { useState } from 'react';
    import { useNavigate, Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
    import { LogIn, UserCircle, Shield, Store } from 'lucide-react';
    import { useAppContext } from '@/contexts/AppContext';
    import { useToast } from '@/components/ui/use-toast';

    const LoginPage = () => {
      const [email, setEmail] = useState('');
      const [password, setPassword] = useState('');
      const { login, isLoading, signUp } = useAppContext();
      const navigate = useNavigate();
      const { toast } = useToast();
      const [isSignUp, setIsSignUp] = useState(false);
      const [confirmPassword, setConfirmPassword] = useState('');
      const [username, setUsername] = useState('');

      const handleLoginSubmit = async (e) => {
        e.preventDefault();
        const success = await login(email, password);
        if (success) {
         // Navigation handled by AppContext login
        }
      };
      
      const handleSignUpSubmit = async (e) => {
        e.preventDefault();
        if (password !== confirmPassword) {
          toast({ title: "Sign Up Error", description: "Passwords do not match.", variant: "destructive" });
          return;
        }
        const user = await signUp(email, password, { role: 'user', username: username || email.split('@')[0] });
        if (user) {
          // Toast handled by AppContext signUp
          setIsSignUp(false); // Switch back to login form
          setEmail(''); // Clear fields
          setPassword('');
          setConfirmPassword('');
          setUsername('');
        }
      };


      return (
        <div className="min-h-[calc(100vh-10rem)] flex items-center justify-center bg-gradient-to-br from-keroluxe-white via-keroluxe-off-white to-keroluxe-beige dark:from-keroluxe-black dark:via-neutral-900 dark:to-neutral-800 p-4">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="w-full max-w-md bg-keroluxe-white dark:bg-neutral-800 shadow-2xl border-keroluxe-gold/20">
              <CardHeader className="text-center space-y-2">
                 <UserCircle className="h-12 w-12 text-keroluxe-gold mx-auto" />
                <CardTitle className="text-3xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">
                  {isSignUp ? "Create Account" : "Customer Login"}
                </CardTitle>
                <CardDescription className="text-keroluxe-grey dark:text-neutral-400">
                  {isSignUp ? "Join KeroLuxe for an exclusive shopping experience." : "Welcome back to KeroLuxe."}
                </CardDescription>
              </CardHeader>
              <form onSubmit={isSignUp ? handleSignUpSubmit : handleLoginSubmit}>
                <CardContent className="space-y-4">
                  {isSignUp && (
                    <div className="space-y-1">
                      <Label htmlFor="username" className="text-keroluxe-black dark:text-keroluxe-off-white">Username (Optional)</Label>
                      <Input
                        id="username"
                        type="text"
                        placeholder="Your unique username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold"
                      />
                    </div>
                  )}
                  <div className="space-y-1">
                    <Label htmlFor="email" className="text-keroluxe-black dark:text-keroluxe-off-white">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="password" className="text-keroluxe-black dark:text-keroluxe-off-white">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold"
                    />
                  </div>
                  {isSignUp && (
                     <div className="space-y-1">
                        <Label htmlFor="confirmPassword" className="text-keroluxe-black dark:text-keroluxe-off-white">Confirm Password</Label>
                        <Input
                          id="confirmPassword"
                          type="password"
                          placeholder="••••••••"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          required
                          className="bg-keroluxe-off-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold"
                        />
                      </div>
                  )}
                </CardContent>
                <CardFooter className="flex flex-col space-y-3">
                  <Button type="submit" className="w-full bg-keroluxe-gold text-keroluxe-black hover:bg-keroluxe-gold/90 dark:bg-keroluxe-gold dark:text-keroluxe-black dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black" disabled={isLoading}>
                    {isLoading ? (isSignUp ? 'Creating Account...' : 'Logging In...') : (isSignUp ? 'Sign Up' : 'Log In')}
                    {!isLoading && <LogIn className="ml-2 h-5 w-5" />}
                  </Button>
                  <Button type="button" variant="link" onClick={() => setIsSignUp(!isSignUp)} className="text-keroluxe-gold hover:underline">
                    {isSignUp ? "Already have an account? Log In" : "Don't have an account? Sign Up"}
                  </Button>
                  {!isSignUp && (
                    <Link to="/admin/login" className="text-xs text-keroluxe-grey dark:text-neutral-500 hover:text-keroluxe-gold dark:hover:text-keroluxe-gold flex items-center justify-center">
                      <Shield className="mr-1 h-3 w-3"/> Admin Login
                    </Link>
                  )}
                   <Link to="/seller/login" className="text-xs text-keroluxe-grey dark:text-neutral-500 hover:text-keroluxe-gold dark:hover:text-keroluxe-gold flex items-center justify-center">
                      <Store className="mr-1 h-3 w-3"/> Seller Login/Register
                   </Link>
                </CardFooter>
              </form>
            </Card>
          </motion.div>
        </div>
      );
    };

    export default LoginPage;