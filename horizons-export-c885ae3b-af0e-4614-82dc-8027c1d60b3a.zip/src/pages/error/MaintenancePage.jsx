import React from 'react';
    import { motion } from 'framer-motion';
    import { HardHat, Clock } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Link } from 'react-router-dom';

    const MaintenancePage = () => {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-keroluxe-off-white dark:bg-neutral-900 text-center p-6">
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="space-y-8 max-w-lg"
          >
            <HardHat className="mx-auto h-24 w-24 text-keroluxe-gold" />
            <h1 className="text-4xl md:text-5xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">Under Maintenance</h1>
            <p className="text-lg text-keroluxe-grey dark:text-neutral-400">
              Our website is currently undergoing scheduled maintenance to bring you an even better experience. 
              We appreciate your patience and will be back online shortly!
            </p>
            <div className="flex items-center justify-center space-x-2 text-keroluxe-grey dark:text-neutral-500">
              <Clock className="h-5 w-5" />
              <span>Estimated down time: Approximately 2 hours.</span>
            </div>
             <img  alt="Website under construction illustration" className="mx-auto mt-8 w-72 h-auto opacity-80" src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=500" />
            <div className="pt-6">
              <p className="text-sm text-keroluxe-grey dark:text-neutral-600">
                If you need urgent assistance, please contact us at <a href="mailto:support@keroluxe.com" className="text-keroluxe-gold hover:underline">support@keroluxe.com</a>.
              </p>
               <Button asChild className="mt-6 btn-primary">
                <Link to="/">Try Homepage</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      );
    };

    export default MaintenancePage;