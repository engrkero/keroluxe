import React from 'react';
    import { Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { AlertTriangle, Home } from 'lucide-react';

    const NotFoundPage = () => {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-keroluxe-off-white dark:bg-neutral-900 text-center p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: -50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ type: 'spring', stiffness: 100, duration: 0.5 }}
            className="space-y-8 max-w-md"
          >
            <AlertTriangle className="mx-auto h-24 w-24 text-keroluxe-gold" />
            <h1 className="text-6xl md:text-8xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">404</h1>
            <h2 className="text-2xl md:text-3xl font-semibold text-keroluxe-black dark:text-keroluxe-white">Page Not Found</h2>
            <p className="text-keroluxe-grey dark:text-neutral-400 text-lg">
              Oops! The page you are looking for does not exist. It might have been moved or deleted.
            </p>
            <div className="flex justify-center gap-4">
              <Button asChild className="btn-primary group">
                <Link to="/">
                  <Home className="mr-2 h-5 w-5 transition-transform group-hover:-translate-x-1" />
                  Go to Homepage
                </Link>
              </Button>
              <Button variant="outline" onClick={() => window.history.back()} className="btn-outline-gold group">
                 Go Back
              </Button>
            </div>
            <img  alt="Sad character looking for page" className="mx-auto mt-8 w-60 h-auto opacity-70" src="https://images.unsplash.com/photo-1594322436404-5a0526db4d13?w=500" />
          </motion.div>
        </div>
      );
    };

    export default NotFoundPage;