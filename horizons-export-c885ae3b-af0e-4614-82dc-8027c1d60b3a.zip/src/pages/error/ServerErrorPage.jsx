import React from 'react';
    import { Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { ServerCrash, RefreshCw } from 'lucide-react';

    const ServerErrorPage = () => {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-keroluxe-off-white dark:bg-neutral-900 text-center p-6">
          <motion.div
            initial={{ opacity: 0, filter: 'blur(5px)' }}
            animate={{ opacity: 1, filter: 'blur(0px)' }}
            transition={{ duration: 0.7 }}
            className="space-y-8 max-w-md"
          >
            <ServerCrash className="mx-auto h-24 w-24 text-red-500 dark:text-red-400" />
            <h1 className="text-5xl md:text-7xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">500</h1>
            <h2 className="text-2xl md:text-3xl font-semibold text-keroluxe-black dark:text-keroluxe-white">Internal Server Error</h2>
            <p className="text-keroluxe-grey dark:text-neutral-400 text-lg">
              Oops! Something went wrong on our end. We are working to fix the issue. Please try again later.
            </p>
            <div className="flex justify-center gap-4">
              <Button onClick={() => window.location.reload()} className="btn-primary group">
                <RefreshCw className="mr-2 h-5 w-5 transition-transform group-hover:rotate-180" />
                Try Again
              </Button>
              <Button asChild variant="outline" className="btn-outline-gold">
                <Link to="/">Go to Homepage</Link>
              </Button>
            </div>
             <img  alt="Broken server illustration" className="mx-auto mt-8 w-60 h-auto opacity-60" src="https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?w=500" />
          </motion.div>
        </div>
      );
    };

    export default ServerErrorPage;