import React, { createContext, useContext } from 'react';
    import { useToast } from '@/components/ui/use-toast';
    import { useLocation, useNavigate } from 'react-router-dom';
    import { supabase } from '@/lib/supabaseClient';
    import useAuth from '@/hooks/useAuth';
    import useCart from '@/hooks/useCart';
    import useWishlist from '@/hooks/useWishlist';
    import useTheme from '@/hooks/useTheme';
    import useGlobalLoading from '@/hooks/useGlobalLoading';

    const AppContext = createContext();

    export const AppProvider = ({ children }) => {
      const { toast } = useToast();
      const location = useLocation();
      const navigate = useNavigate();

      const authHook = useAuth(supabase, toast, navigate);
      const cartHook = useCart(toast);
      const wishlistHook = useWishlist(toast);
      const themeHook = useTheme();
      // Pass authHook.isLoadingAuth to useGlobalLoading
      const loadingHook = useGlobalLoading(location, authHook.session, authHook.isLoadingAuth); 
      
      return (
        <AppContext.Provider
          value={{
            // Auth
            user: authHook.user, 
            userProfile: authHook.userProfile,
            session: authHook.session,
            isLoadingAuth: authHook.isLoadingAuth, // Provide the auth-specific loading state
            isAdminAuthenticated: authHook.isAdminAuthenticated,
            isSellerAuthenticated: authHook.isSellerAuthenticated,
            isAuthenticated: authHook.isAuthenticated,
            login: authHook.login,
            signUp: authHook.signUp,
            logout: authHook.logout,
            fetchUserProfile: authHook.fetchUserProfile,

            // Cart
            cart: cartHook.cart,
            addToCart: cartHook.addToCart,
            removeFromCart: cartHook.removeFromCart,
            updateCartQuantity: cartHook.updateCartQuantity,
            clearCart: cartHook.clearCart,

            // Wishlist
            wishlist: wishlistHook.wishlist,
            addToWishlist: wishlistHook.addToWishlist,
            removeFromWishlist: wishlistHook.removeFromWishlist,

            // Theme
            theme: themeHook.theme,
            toggleTheme: themeHook.toggleTheme,

            // Global Loading (from useGlobalLoading hook)
            isLoading: loadingHook.isLoading, 
            setIsLoading: loadingHook.setIsLoading,

            supabase, 
          }}
        >
          {children}
        </AppContext.Provider>
      );
    };

    export const useAppContext = () => {
      const context = useContext(AppContext);
      if (context === undefined) {
        throw new Error('useAppContext must be used within an AppProvider');
      }
      return context;
    };
