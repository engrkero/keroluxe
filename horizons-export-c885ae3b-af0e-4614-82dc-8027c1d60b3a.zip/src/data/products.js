export const products = [
      {
        id: '1',
        name: 'Elegant Silk Nightgown',
        category: 'Nightwears (Female)',
        price: 79.99,
        rating: 4.8,
        imageUrlPlaceholder: 'Elegant silk nightgown on a hanger',
        images: [
          'Elegant silk nightgown on a hanger',
          'Model wearing elegant silk nightgown',
          'Close up of silk nightgown fabric'
        ],
        description: 'Luxurious 100% silk nightgown, perfect for a comfortable and elegant night. Features delicate lace trim and adjustable straps.',
        fabric: '100% Mulberry Silk',
        care: 'Hand wash cold, lay flat to dry.',
        stock: 15,
        labels: ['Bestseller', 'Luxury'],
        sizes: ['S', 'M', 'L', 'XL'],
        colors: [{ name: 'Champagne', hex: '#F7E7CE' }, { name: 'Dusty Rose', hex: '#DCAE96' }],
        seller: { id: 'seller001', name: 'KeroLuxe Boutique', rating: 4.9 },
        reviews: [
          { id: 'rev1', user: 'Sarah L.', rating: 5, title: 'Absolutely Stunning!', comment: 'This nightgown is pure luxury. So soft and fits perfectly.', date: '2025-05-10', userPhoto: 'user_sarah.jpg', status: 'approved' },
          { id: 'rev2', user: 'Jessica M.', rating: 4, title: 'Very Comfortable', comment: 'Love the feel of the silk. Wish it came in more colors.', date: '2025-05-15', status: 'pending' },
        ]
      },
      {
        id: '2',
        name: 'Classic Cotton T-Shirt (Unisex)',
        category: 'T-Shirts',
        price: 24.99,
        rating: 4.5,
        imageUrlPlaceholder: 'White cotton t-shirt folded neatly',
        images: [
          'White cotton t-shirt folded neatly',
          'Model wearing white cotton t-shirt',
          'Black cotton t-shirt variant'
        ],
        description: 'A timeless unisex t-shirt made from premium soft cotton. Versatile and comfortable for everyday wear.',
        fabric: '100% Organic Cotton',
        care: 'Machine wash cold, tumble dry low.',
        stock: 50,
        labels: ['Unisex', 'Essential'],
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [{ name: 'White', hex: '#FFFFFF' }, { name: 'Black', hex: '#000000' }, { name: 'Heather Grey', hex: '#B2BEB5' }],
        seller: { id: 'seller002', name: 'KeroLuxe Essentials', rating: 4.7 },
        reviews: [
          { id: 'rev3', user: 'Mike P.', rating: 5, title: 'Best Basic Tee!', comment: 'Super soft and holds up well after washing.', date: '2025-05-18', status: 'approved' }
        ]
      },
      {
        id: '3',
        name: 'Comfort Fit Boxer Briefs (Male)',
        category: 'Underwears (Male)',
        price: 19.99,
        rating: 4.6,
        imageUrlPlaceholder: 'Pack of three male boxer briefs',
        images: [
          'Pack of three male boxer briefs',
          'Model wearing comfort fit boxer brief',
          'Detail of boxer brief waistband'
        ],
        description: 'Soft and breathable boxer briefs designed for all-day comfort. Features a supportive pouch and a comfortable waistband.',
        fabric: '95% Cotton, 5% Elastane',
        care: 'Machine wash warm, tumble dry medium.',
        stock: 30,
        labels: ['New Arrival'],
        sizes: ['M', 'L', 'XL'],
        colors: [{ name: 'Navy Blue', hex: '#000080' }, { name: 'Charcoal', hex: '#36454F' }],
        seller: { id: 'seller003', name: 'KeroLuxe Intimates', rating: 4.8 },
        reviews: []
      },
      {
        id: '4',
        name: 'Linen Blend Trousers (Unisex)',
        category: 'Trousers (Unisex)',
        price: 59.99,
        rating: 4.7,
        imageUrlPlaceholder: 'Beige linen blend trousers',
        images: [
          'Beige linen blend trousers',
          'Model wearing linen blend trousers',
          'Close up of linen fabric texture'
        ],
        description: 'Lightweight and breathable linen blend trousers, perfect for warm weather. Unisex design with a relaxed fit.',
        fabric: '55% Linen, 45% Cotton',
        care: 'Machine wash cold, hang to dry.',
        stock: 22,
        labels: ['Unisex', 'Summer Collection'],
        sizes: ['S', 'M', 'L', 'XL'],
        colors: [{ name: 'Natural Beige', hex: '#D8C4A4' }, { name: 'Olive Green', hex: '#556B2F' }],
        seller: { id: 'seller002', name: 'KeroLuxe Casuals', rating: 4.6 },
        reviews: []
      },
      {
        id: '5',
        name: 'Pinstripe Business Shirt (Male)',
        category: 'Shirts',
        price: 45.00,
        rating: 4.9,
        imageUrlPlaceholder: 'Crisp pinstripe business shirt',
        images: [
          'Crisp pinstripe business shirt',
          'Man wearing pinstripe business shirt with a tie',
          'Detail of pinstripe shirt cuff'
        ],
        description: 'A sharp and professional pinstripe business shirt. Made from high-quality cotton for a comfortable fit and a polished look.',
        fabric: '100% Cotton Poplin',
        care: 'Machine wash warm, iron medium.',
        stock: 18,
        labels: ['Bestseller', 'Formal'],
        sizes: ['M', 'L', 'XL', 'XXL'],
        colors: [{ name: 'Blue Pinstripe', hex: '#A7C7E7' }, { name: 'Grey Pinstripe', hex: '#D3D3D3' }],
        seller: { id: 'seller001', name: 'KeroLuxe Professional', rating: 4.9 },
        reviews: []
      },
      {
        id: '6',
        name: 'Denim Shorts (Unisex)',
        category: 'Shorts (Unisex)',
        price: 35.50,
        rating: 4.3,
        imageUrlPlaceholder: 'Classic blue denim shorts',
        images: [
          'Classic blue denim shorts',
          'Models (male and female) wearing denim shorts',
          'Detail of denim shorts stitching'
        ],
        description: 'Versatile denim shorts for a casual look. Durable and comfortable, suitable for any relaxed occasion.',
        fabric: '98% Cotton, 2% Elastane',
        care: 'Machine wash cold, tumble dry low.',
        stock: 40,
        labels: ['Unisex', 'Casual'],
        sizes: ['S', 'M', 'L', 'XL'],
        colors: [{ name: 'Vintage Blue', hex: '#6495ED' }, { name: 'Washed Black', hex: '#4A4A4A' }],
        seller: { id: 'seller002', name: 'KeroLuxe Denim', rating: 4.5 },
        reviews: []
      },
      {
        id: 'bale001',
        name: 'Vintage Denim Jeans (Bale)',
        category: 'Bale (First Class) - Jeans',
        price: 30.00,
        originalPrice: 60.00,
        rating: 4.2,
        imageUrlPlaceholder: 'Folded stack of vintage denim jeans',
        images: ['Folded stack of vintage denim jeans', 'Close up of vintage denim jean details'],
        description: 'A unique pair of Grade A vintage denim jeans. Condition is excellent with minor signs of wear typical for vintage items. Specific measurements available.',
        fabric: 'Denim (Cotton)',
        care: 'Wash cold, inspect for specific care needs.',
        stock: 1,
        labels: ['Bale', 'Vintage', 'Unique Find'],
        sizes: ['Unique - Check Measurements'],
        colors: [{ name: 'Classic Blue Wash', hex: '#5F7BA5' }],
        seller: { id: 'sellerBale01', name: 'KeroLuxe Vintage Finds', rating: 4.8 },
        reviews: []
      },
      {
        id: 'bale002',
        name: 'Silk Blend Female Top (Bale)',
        category: 'Bale (First Class) - Female Tops',
        price: 25.00,
        rating: 4.5,
        imageUrlPlaceholder: 'Elegant silk blend female top on hanger',
        images: ['Elegant silk blend female top on hanger', 'Detail of fabric texture on bale top'],
        description: 'A beautiful first-class used female top, silk blend. Excellent condition. Perfect for adding a unique touch to your wardrobe.',
        fabric: 'Silk Blend',
        care: 'Gentle wash recommended.',
        stock: 1,
        labels: ['Bale', 'Luxury Thrift'],
        sizes: ['M (Approx)'],
        colors: [{ name: 'Floral Print', hex: '#C8A2C8' }],
        seller: { id: 'sellerBale01', name: 'KeroLuxe Vintage Finds', rating: 4.8 },
        reviews: []
      },
      {
        id: 'bale003',
        name: 'Retro Football Jersey (Bale)',
        category: 'Bale (First Class) - Jersey',
        price: 40.00,
        rating: 4.7,
        imageUrlPlaceholder: 'Vintage football jersey displayed flat',
        images: ['Vintage football jersey displayed flat', 'Close up of jersey crest'],
        description: 'Authentic Grade A retro football jersey. A collector\'s item in great condition.',
        fabric: 'Polyester Blend',
        care: 'Hand wash recommended.',
        stock: 1,
        labels: ['Bale', 'Collectible', 'Sportswear'],
        sizes: ['L (Men\'s)'],
        colors: [{ name: 'Red & White Stripes', hex: '#FF0000' }],
        seller: { id: 'sellerBale02', name: 'KeroSports Relics', rating: 4.9 },
        reviews: []
      },
      {
        id: 'bale004',
        name: 'Leather Tote Handbag (Bale)',
        category: 'Bale (First Class) - Female Hand Bags',
        price: 65.00,
        rating: 4.6,
        imageUrlPlaceholder: 'Classic leather tote handbag',
        images: ['Classic leather tote handbag', 'Interior view of leather tote handbag'],
        description: 'A stylish and durable Grade A leather tote handbag. Shows minimal wear, excellent for daily use.',
        fabric: 'Genuine Leather',
        care: 'Leather cleaner and conditioner.',
        stock: 1,
        labels: ['Bale', 'Designer Inspired', 'Durable'],
        sizes: ['One Size'],
        colors: [{ name: 'Tan Brown', hex: '#D2B48C' }],
        seller: { id: 'sellerBale01', name: 'KeroLuxe Vintage Finds', rating: 4.8 },
        reviews: []
      }
    ];

    export const categories = [
      { name: "Shirts", slug: "shirts", subcategories: [] },
      { name: "T-Shirts", slug: "t-shirts", subcategories: [] },
      { name: "Underwears (Male)", slug: "underwears-male", subcategories: [] },
      { name: "Nightwears (Female)", slug: "nightwears-female", subcategories: [] },
      { name: "Trousers (Unisex)", slug: "trousers-unisex", subcategories: [] },
      { name: "Shorts (Unisex)", slug: "shorts-unisex", subcategories: [] },
      { 
        name: "Bale (First Class)", 
        slug: "bale-first-class", 
        subcategories: [
          { name: "Jeans", slug: "bale-jeans", parentSlug: "bale-first-class" },
          { name: "Female Tops", slug: "bale-female-tops", parentSlug: "bale-first-class" },
          { name: "Jersey", slug: "bale-jersey", parentSlug: "bale-first-class" },
          { name: "Female Hand Bags", slug: "bale-female-hand-bags", parentSlug: "bale-first-class" },
        ] 
      },
    ];

    export const heroSlides = [
      { id: 1, title: "New Nightwear Collection", description: "Discover elegance and comfort in our latest arrivals.", imageUrlPlaceholder: "Beautiful model in luxury nightwear", buttonText: "Shop Nightwear", link: "/category/nightwears-female" },
      { id: 2, title: "Unisex Essentials Launch", description: "Versatile styles for everyone, crafted for comfort.", imageUrlPlaceholder: "Group of diverse models in unisex apparel", buttonText: "Explore Unisex", link: "/category/t-shirts" },
      { id: 3, title: "Seasonal Sale Up to 50% Off", description: "Limited time offers on selected items. Don't miss out!", imageUrlPlaceholder: "Stylish flat lay of sale items", buttonText: "Shop Sale", link: "/sale" },
      { id: 4, title: "Bale (First Class) Finds", description: "Unique, high-quality pre-loved fashion treasures.", imageUrlPlaceholder: "Artistic display of vintage clothing items", buttonText: "Discover Bale", link: "/category/bale-first-class" },
    ];