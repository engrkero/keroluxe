import React, { useCallback } from 'react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { ChevronLeft, ChevronRight, Image as ImageIcon } from 'lucide-react';

    const ProductImageGallery = ({ images, productName, currentImageIndex, setCurrentImageIndex }) => {
      const nextImage = useCallback(() => {
        setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
      }, [images.length, setCurrentImageIndex]);
    
      const prevImage = useCallback(() => {
        setCurrentImageIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
      }, [images.length, setCurrentImageIndex]);

      if (!images || images.length === 0) {
        return (
          <div className="aspect-square bg-keroluxe-off-white dark:bg-neutral-700 rounded-lg flex items-center justify-center shadow-lg">
            <ImageIcon className="h-24 w-24 text-keroluxe-grey dark:text-neutral-500" />
          </div>
        );
      }
      
      const mainPlaceholderQuery = images[currentImageIndex] || productName || 'fashion product details';
      const mainImageSrc = `https://source.unsplash.com/600x600/?${encodeURIComponent(mainPlaceholderQuery)}`;

      return (
        <div className="space-y-4">
          <div className="relative aspect-square bg-keroluxe-off-white dark:bg-neutral-700 rounded-lg overflow-hidden shadow-lg">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentImageIndex}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.3 }}
                className="absolute inset-0"
              >
                <img  
                  alt={`${productName} - Image ${currentImageIndex + 1}`} 
                  className="w-full h-full object-cover"
                 src={mainImageSrc} />
              </motion.div>
            </AnimatePresence>
            {images.length > 1 && (
              <>
                <Button onClick={prevImage} variant="ghost" size="icon" className="absolute left-2 top-1/2 -translate-y-1/2 bg-keroluxe-white/50 dark:bg-keroluxe-black/50 hover:bg-keroluxe-white/80 dark:hover:bg-keroluxe-black/80 rounded-full text-keroluxe-black dark:text-keroluxe-white hover:text-keroluxe-gold">
                  <ChevronLeft className="h-6 w-6" />
                </Button>
                <Button onClick={nextImage} variant="ghost" size="icon" className="absolute right-2 top-1/2 -translate-y-1/2 bg-keroluxe-white/50 dark:bg-keroluxe-black/50 hover:bg-keroluxe-white/80 dark:hover:bg-keroluxe-black/80 rounded-full text-keroluxe-black dark:text-keroluxe-white hover:text-keroluxe-gold">
                  <ChevronRight className="h-6 w-6" />
                </Button>
              </>
            )}
          </div>
          {images.length > 1 && (
            <div className="grid grid-cols-4 gap-2">
              {images.map((imgPlaceholder, index) => {
                const thumbPlaceholderQuery = imgPlaceholder || productName || 'fashion product thumbnail';
                const thumbImageSrc = `https://source.unsplash.com/150x150/?${encodeURIComponent(thumbPlaceholderQuery)}`;
                return (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`aspect-square rounded-md overflow-hidden border-2 bg-keroluxe-off-white dark:bg-neutral-700 ${index === currentImageIndex ? 'border-keroluxe-gold ring-2 ring-keroluxe-gold' : 'border-transparent hover:border-keroluxe-gold/50'}`}
                  >
                    <img  alt={`Thumbnail ${index + 1}`} className="w-full h-full object-cover" src={thumbImageSrc} />
                  </button>
                );
              })}
            </div>
          )}
        </div>
      );
    };
    export default ProductImageGallery;