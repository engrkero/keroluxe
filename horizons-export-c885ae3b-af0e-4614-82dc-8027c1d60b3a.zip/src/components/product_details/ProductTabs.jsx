import React from 'react';
    import { Link, useNavigate } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
    import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
    import { Separator } from '@/components/ui/separator';
    import { Button } from '@/components/ui/button';
    import { Star, Truck, RotateCcw } from 'lucide-react';

    const ProductTabs = ({product}) => {
      const navigate = useNavigate();

      const handleWriteReviewClick = () => {
        navigate(`/write-review/${product.id}`);
      };

       return (
         <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.5 }}
            className="mt-12"
          >
            <Tabs defaultValue="description" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-keroluxe-off-white dark:bg-neutral-800 p-1 rounded-lg border border-keroluxe-grey/20 dark:border-neutral-700">
                <TabsTrigger value="description" className="data-[state=active]:bg-keroluxe-gold data-[state=active]:text-keroluxe-black data-[state=active]:shadow-md text-keroluxe-grey dark:text-neutral-400 dark:data-[state=active]:text-keroluxe-black">Description</TabsTrigger>
                <TabsTrigger value="reviews" className="data-[state=active]:bg-keroluxe-gold data-[state=active]:text-keroluxe-black data-[state=active]:shadow-md text-keroluxe-grey dark:text-neutral-400 dark:data-[state=active]:text-keroluxe-black">Reviews</TabsTrigger>
                <TabsTrigger value="delivery" className="data-[state=active]:bg-keroluxe-gold data-[state=active]:text-keroluxe-black data-[state=active]:shadow-md text-keroluxe-grey dark:text-neutral-400 dark:data-[state=active]:text-keroluxe-black">Delivery & Returns</TabsTrigger>
              </TabsList>
              <TabsContent value="description" className="mt-6 p-6 bg-keroluxe-white dark:bg-neutral-800 rounded-lg shadow-md border border-keroluxe-grey/10 dark:border-neutral-700">
                <h3 className="text-xl font-semibold font-serif text-keroluxe-black dark:text-keroluxe-white mb-3">Product Details</h3>
                <p className="text-keroluxe-grey dark:text-neutral-300 leading-relaxed mb-4">{product.description}</p>
                <Separator className="my-4 bg-keroluxe-grey/20 dark:bg-neutral-700" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="font-medium text-keroluxe-black dark:text-keroluxe-off-white">Fabric:</p>
                    <p className="text-keroluxe-grey dark:text-neutral-400">{product.fabric}</p>
                  </div>
                  <div>
                    <p className="font-medium text-keroluxe-black dark:text-keroluxe-off-white">Care Instructions:</p>
                    <p className="text-keroluxe-grey dark:text-neutral-400">{product.care || product.care_instructions}</p>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="reviews" className="mt-6 p-6 bg-keroluxe-white dark:bg-neutral-800 rounded-lg shadow-md border border-keroluxe-grey/10 dark:border-neutral-700">
                <h3 className="text-xl font-semibold font-serif text-keroluxe-black dark:text-keroluxe-white mb-3">Customer Reviews</h3>
                <div className="space-y-4">
                  {product.reviews && product.reviews.length > 0 ? product.reviews.map(review => (
                    <div key={review.id} className="border-b border-keroluxe-grey/10 dark:border-neutral-700 pb-4">
                      <div className="flex items-center mb-1">
                        {[...Array(5)].map((_, idx) => (
                          <Star key={idx} className={`h-4 w-4 ${idx < review.rating ? 'text-keroluxe-gold fill-keroluxe-gold' : 'text-keroluxe-grey/30 dark:text-neutral-600'}`} />
                        ))}
                        <span className="ml-2 font-semibold text-keroluxe-black dark:text-keroluxe-white">{review.title || "Great Product!"}</span>
                      </div>
                      <p className="text-sm text-keroluxe-grey dark:text-neutral-300 mb-1">"{review.comment}" - {review.user}</p>
                      <p className="text-xs text-keroluxe-grey/70 dark:text-neutral-500">Reviewed on: {new Date(review.date).toLocaleDateString()}</p>
                      { review.userPhoto && <img  alt="User review photo" className="mt-2 rounded-md max-w-[100px] max-h-[100px] object-cover" src={`https://source.unsplash.com/100x100/?${encodeURIComponent(review.userPhoto || 'person review')}`} />}
                    </div>
                  )) : (
                    <p className="text-keroluxe-grey dark:text-neutral-400">No reviews yet for this product. Be the first to write one!</p>
                  )}
                </div>
                <Button onClick={handleWriteReviewClick} variant="outline" className="mt-4 border-keroluxe-gold text-keroluxe-gold hover:bg-keroluxe-gold hover:text-keroluxe-black dark:hover:text-keroluxe-black">Write a Review</Button>
              </TabsContent>
              <TabsContent value="delivery" className="mt-6 p-6 bg-keroluxe-white dark:bg-neutral-800 rounded-lg shadow-md border border-keroluxe-grey/10 dark:border-neutral-700">
                <h3 className="text-xl font-semibold font-serif text-keroluxe-black dark:text-keroluxe-white mb-4">Delivery Information</h3>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="shipping">
                    <AccordionTrigger className="text-keroluxe-black dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold">
                      <Truck className="mr-2 h-5 w-5 text-keroluxe-gold" /> Standard Shipping
                    </AccordionTrigger>
                    <AccordionContent className="text-keroluxe-grey dark:text-neutral-300">
                      Estimated delivery within 3-5 business days. Free shipping on orders over ₦25,000.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="returns">
                    <AccordionTrigger className="text-keroluxe-black dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold">
                      <RotateCcw className="mr-2 h-5 w-5 text-keroluxe-gold" /> Return Policy
                    </AccordionTrigger>
                    <AccordionContent className="text-keroluxe-grey dark:text-neutral-300">
                      Easy 14-day returns. Items must be in original condition with tags attached. Some exclusions apply. Read our full <Link to="/shipping-returns" className="text-keroluxe-gold hover:underline">Shipping & Returns policy</Link>.
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </TabsContent>
            </Tabs>
          </motion.div>
       );
    };
    export default ProductTabs;