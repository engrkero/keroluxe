import React from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
    import { Label } from '@/components/ui/label';
    import { Input } from '@/components/ui/input';
    import { Avatar, AvatarFallback } from '@/components/ui/avatar';
    import { Star, ShoppingCart, Heart, UserPlus, UserCheck, CheckCircle } from 'lucide-react';
    import { useNavigate } from 'react-router-dom';


    const ProductInfo = ({ product, quantity, setQuantity, selectedSize, setSelectedSize, selectedColor, setSelectedColor, handleAddToCart, handleBuyNow, handleAddToWishlist, isWishlisted, handleFollowSeller, isFollowingSeller }) => {
      const navigate = useNavigate();
      
      const onFollowSellerClick = () => {
        navigate(`/message-seller/${product.seller.id}`); 
      };

      const isKeroLuxeAdminSeller = product.seller.id === 'seller001' || product.seller.name.toLowerCase().includes('keroluxe');
      
      return (
        <div className="space-y-6">
          <motion.h1 
            initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="text-3xl md:text-4xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white"
          >
            {product.name}
          </motion.h1>
          
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="flex items-center space-x-4">
            <p className="text-3xl font-semibold text-keroluxe-gold">₦{product.price.toFixed(2)}</p>
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className={`h-5 w-5 ${i < Math.round(product.rating) ? 'text-keroluxe-gold fill-keroluxe-gold' : 'text-keroluxe-grey/50 dark:text-neutral-600'}`} />
              ))}
              <span className="ml-2 text-sm text-keroluxe-grey dark:text-neutral-400">({product.rating.toFixed(1)} from {product.reviews?.length || 0} reviews)</span>
            </div>
          </motion.div>

          {isKeroLuxeAdminSeller && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
              className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-keroluxe-gold/10 text-keroluxe-gold border border-keroluxe-gold/30"
            >
              <CheckCircle className="h-4 w-4 mr-1.5" /> Official KeroLuxe Store
            </motion.div>
          )}

          {product.sizes && product.sizes.length > 0 && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="space-y-2">
              <Label className="text-base font-medium text-keroluxe-black dark:text-keroluxe-off-white">Size:</Label>
              <RadioGroup value={selectedSize} onValueChange={setSelectedSize} className="flex flex-wrap gap-2">
                {product.sizes.map(size => (
                  <Label 
                    key={size}
                    htmlFor={`size-${size}-${product.id}`}
                    className={`cursor-pointer px-3 py-1.5 border rounded-md transition-colors text-sm ${selectedSize === size ? 'bg-keroluxe-gold text-keroluxe-black border-keroluxe-gold font-semibold' : 'bg-keroluxe-white dark:bg-neutral-700 hover:bg-keroluxe-off-white dark:hover:bg-neutral-600 border-keroluxe-grey/30 dark:border-neutral-600 text-keroluxe-black dark:text-keroluxe-off-white'}`}
                  >
                    <RadioGroupItem value={size} id={`size-${size}-${product.id}`} className="sr-only" />
                    {size}
                  </Label>
                ))}
              </RadioGroup>
            </motion.div>
          )}

          {product.colors && product.colors.length > 0 && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="space-y-2">
              <Label className="text-base font-medium text-keroluxe-black dark:text-keroluxe-off-white">Color: <span className="font-normal text-keroluxe-grey dark:text-neutral-400">{selectedColor}</span></Label>
              <div className="flex space-x-2">
                {product.colors.map(color => (
                  <button
                    key={color.name}
                    title={color.name}
                    onClick={() => setSelectedColor(color.name)}
                    className={`w-8 h-8 rounded-full border-2 transition-all ${selectedColor === color.name ? 'border-keroluxe-gold ring-2 ring-keroluxe-gold ring-offset-1 scale-110' : 'border-keroluxe-grey/30 dark:border-neutral-600 hover:scale-105'}`}
                    style={{ backgroundColor: color.hex }}
                  />
                ))}
              </div>
            </motion.div>
          )}

          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="flex items-center space-x-4">
            <Label htmlFor={`quantity-${product.id}`} className="text-base font-medium text-keroluxe-black dark:text-keroluxe-off-white">Quantity:</Label>
            <Input 
              id={`quantity-${product.id}`}
              type="number" 
              min="1" 
              max={product.stock} 
              value={quantity} 
              onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value)))} 
              className="w-20 bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-center text-keroluxe-black dark:text-keroluxe-white"
            />
            {product.stock < 10 && <span className="text-sm text-red-500">Only {product.stock} left!</span>}
          </motion.div>

          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Button size="lg" onClick={handleAddToCart} className="w-full bg-keroluxe-black text-keroluxe-white hover:bg-keroluxe-gold hover:text-keroluxe-black dark:bg-keroluxe-gold dark:text-keroluxe-black dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black text-lg py-3">
              <ShoppingCart className="mr-2 h-5 w-5" /> Add to Cart
            </Button>
            <Button size="lg" onClick={handleBuyNow} variant="outline" className="w-full border-keroluxe-black text-keroluxe-black hover:bg-keroluxe-black hover:text-keroluxe-white dark:border-keroluxe-gold dark:text-keroluxe-gold dark:hover:bg-keroluxe-gold dark:hover:text-keroluxe-black text-lg py-3">
              Buy Now
            </Button>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.65 }}>
            <Button variant="ghost" onClick={handleAddToWishlist} className="w-full text-keroluxe-grey dark:text-neutral-400 hover:text-keroluxe-gold dark:hover:text-keroluxe-gold hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/10">
              <Heart className={`mr-2 h-5 w-5 ${isWishlisted ? 'text-keroluxe-gold fill-keroluxe-gold' : ''}`} /> 
              {isWishlisted ? 'In Wishlist' : 'Add to Wishlist'}
            </Button>
          </motion.div>

          {!isKeroLuxeAdminSeller && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }} className="border border-keroluxe-grey/20 dark:border-neutral-700 rounded-lg p-4 space-y-3 bg-keroluxe-off-white dark:bg-neutral-800">
              <div className="flex items-center">
                <Avatar className="h-10 w-10 mr-3">
                  <img  alt={product.seller.name} className="object-cover" src={`https://source.unsplash.com/random/100x100/?store,logo,${product.seller.name.replace(/\s/g,',')}`} />
                  <AvatarFallback>{product.seller.name.substring(0,2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold text-keroluxe-black dark:text-keroluxe-white">{product.seller.name}</p>
                  <div className="flex items-center text-sm text-keroluxe-grey dark:text-neutral-400">
                    <Star className="h-4 w-4 text-keroluxe-gold fill-keroluxe-gold mr-1" /> {product.seller.rating} Seller Rating
                  </div>
                </div>
              </div>
              <Button 
                variant="outline" 
                onClick={onFollowSellerClick}
                className={`w-full border-keroluxe-grey/50 dark:border-neutral-600  hover:border-keroluxe-gold hover:text-keroluxe-gold dark:hover:border-keroluxe-gold dark:hover:text-keroluxe-gold transition-colors ${
                  isFollowingSeller 
                  ? 'bg-keroluxe-gold/20 text-keroluxe-gold border-keroluxe-gold dark:bg-keroluxe-gold/20 dark:text-keroluxe-gold dark:border-keroluxe-gold' 
                  : 'text-keroluxe-grey dark:text-neutral-300'
                }`}
              >
                {isFollowingSeller ? <UserCheck className="mr-2 h-4 w-4" /> : <UserPlus className="mr-2 h-4 w-4" /> }
                {isFollowingSeller ? 'Following Seller' : 'Follow Seller'}
              </Button>
            </motion.div>
          )}
        </div>
      );
    };
    export default ProductInfo;
