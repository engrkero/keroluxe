import React from 'react';
    import { Link } from 'react-router-dom';
    import { Scissors, Facebook, Instagram, Twitter } from 'lucide-react';

    const FooterLink = ({ to, children }) => (
      <li>
        <Link 
          to={to} 
          className="hover:text-keroluxe-gold transition-colors duration-200"
        >
          {children}
        </Link>
      </li>
    );

    const Footer = () => {
      const currentYear = new Date().getFullYear();
      return (
        <footer className="bg-keroluxe-black text-keroluxe-white py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8 mb-8">
              <div>
                <Link to="/" className="flex items-center space-x-2 mb-4">
                  <Scissors className="h-7 w-7 text-keroluxe-gold" />
                  <span className="text-2xl font-bold font-serif text-keroluxe-gold">KeroLuxe</span>
                </Link>
                <p className="text-sm text-keroluxe-off-white/80">
                  Experience timeless elegance and unparalleled comfort with KeroLuxe.
                </p>
              </div>
              <div>
                <p className="font-semibold text-keroluxe-gold mb-3">Shop</p>
                <ul className="space-y-2 text-sm text-keroluxe-off-white/90">
                  <FooterLink to="/category/nightwears-female">Nightwear</FooterLink>
                  <FooterLink to="/category/t-shirts">Unisex Essentials</FooterLink>
                  <FooterLink to="/new-arrivals">New Arrivals</FooterLink>
                  <FooterLink to="/sale">Sale</FooterLink>
                </ul>
              </div>
              <div>
                <p className="font-semibold text-keroluxe-gold mb-3">Customer Service</p>
                <ul className="space-y-2 text-sm text-keroluxe-off-white/90">
                  <FooterLink to="/contact">Contact Us</FooterLink>
                  <FooterLink to="/about">About Us</FooterLink>
                  <FooterLink to="/track-order">Track Order</FooterLink>
                  <FooterLink to="/faq">FAQ</FooterLink>
                  <FooterLink to="/shipping-returns">Shipping & Returns</FooterLink>
                  <FooterLink to="/size-guide">Size Guide</FooterLink>
                </ul>
              </div>
              <div>
                <p className="font-semibold text-keroluxe-gold mb-3">Follow Us</p>
                <div className="flex space-x-4">
                  <a href="#" aria-label="Facebook" className="text-keroluxe-off-white/80 hover:text-keroluxe-gold transition-colors"><Facebook size={20} /></a>
                  <a href="#" aria-label="Instagram" className="text-keroluxe-off-white/80 hover:text-keroluxe-gold transition-colors"><Instagram size={20} /></a>
                  <a href="#" aria-label="Twitter" className="text-keroluxe-off-white/80 hover:text-keroluxe-gold transition-colors"><Twitter size={20} /></a>
                </div>
                <p className="font-semibold text-keroluxe-gold mt-6 mb-3">Admin</p>
                 <ul className="space-y-2 text-sm text-keroluxe-off-white/90">
                    <FooterLink to="/admin">Admin Panel</FooterLink>
                 </ul>
              </div>
            </div>
            <div className="border-t border-keroluxe-grey/30 pt-8 text-center text-sm text-keroluxe-off-white/70">
              <p>&copy; {currentYear} KeroLuxe. All rights reserved.</p>
              <p className="mt-1">
                <Link to="/privacy-policy" className="hover:text-keroluxe-gold transition-colors">Privacy Policy</Link> | <Link to="/terms-of-service" className="hover:text-keroluxe-gold transition-colors">Terms of Service</Link>
              </p>
            </div>
          </div>
        </footer>
      );
    };

    export default Footer;