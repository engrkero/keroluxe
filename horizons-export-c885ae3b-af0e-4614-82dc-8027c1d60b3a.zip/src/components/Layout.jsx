import React, { useEffect } from 'react';
    import { Outlet, useLocation } from 'react-router-dom';
    import Navbar from '@/components/Navbar';
    import Footer from '@/components/Footer';
    import { Toaster } from "@/components/ui/toaster";

    const ScrollToTop = () => {
      const { pathname } = useLocation();

      useEffect(() => {
        window.scrollTo(0, 0);
      }, [pathname]);

      return null;
    };

    const Layout = () => {
      return (
        <div className="flex flex-col min-h-screen bg-background text-foreground">
          <ScrollToTop />
          <Navbar />
          <main className="flex-grow">
            <Outlet />
          </main>
          <Footer />
          <Toaster />
        </div>
      );
    };

    export default Layout;