import React from 'react';
    import { Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Heart, ShoppingCart, ZoomIn } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent } from '@/components/ui/card';
    import { useAppContext } from '@/contexts/AppContext';
    import { useToast } from '@/components/ui/use-toast';

    const ProductCard = ({ product, isSale = false }) => {
      const { addToCart, addToWishlist, wishlist } = useAppContext();
      const { toast } = useToast();

      const isInWishlist = wishlist.some(item => item.id === product.id);

      const handleAddToCart = (e) => {
        e.preventDefault();
        addToCart({ ...product, quantity: 1 });
        toast({
          title: `${product.name} added to cart!`,
          description: "You can view your cart or continue shopping.",
          className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold",
        });
      };

      const handleToggleWishlist = (e) => {
        e.preventDefault();
        const wasInWishlist = isInWishlist;
        addToWishlist(product);
        toast({
          title: wasInWishlist ? `${product.name} removed from wishlist!` : `${product.name} added to wishlist!`,
          className: "bg-keroluxe-off-white text-keroluxe-black dark:bg-neutral-800 dark:text-keroluxe-white border-keroluxe-gold",
          action: <Heart className={`fill-current ${wasInWishlist ? 'text-keroluxe-grey' : 'text-keroluxe-gold'}`} />,
        });
      };

      const discountPercentage = isSale && product.originalPrice ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : 0;
      // Ensure imageUrlPlaceholder is always a non-empty string for Unsplash
      const placeholderQuery = product.imageUrlPlaceholder || product.name || 'stylish apparel';
      const imageSrc = product.images && product.images[0] ? `https://source.unsplash.com/400x500/?${encodeURIComponent(product.images[0])}` : `https://source.unsplash.com/400x500/?${encodeURIComponent(placeholderQuery)}`;


      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          whileHover={{ y: -5, boxShadow: "0px 10px 20px hsla(var(--keroluxe-black), 0.1)" }}
          transition={{ type: "spring", stiffness: 300 }}
          className="group relative"
        >
          <Card className="overflow-hidden shadow-lg h-full flex flex-col bg-keroluxe-white dark:bg-neutral-800 border-keroluxe-grey/20 dark:border-keroluxe-grey/30 hover:border-keroluxe-gold/50 transition-all duration-300">
            <Link to={`/product/${product.id}`} className="block">
              <div className="relative h-64 md:h-72 w-full overflow-hidden bg-keroluxe-off-white dark:bg-neutral-700">
                <img  
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 ease-in-out"
                 src={imageSrc} />
                {isSale && discountPercentage > 0 && (
                  <div className="absolute top-2 right-2 bg-keroluxe-gold text-keroluxe-black text-xs font-bold px-2 py-1 rounded">
                    {discountPercentage}% OFF
                  </div>
                )}
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <ZoomIn className="h-12 w-12 text-keroluxe-white/80" />
                </div>
              </div>
            </Link>
            <CardContent className="p-4 flex-grow flex flex-col justify-between">
              <div>
                <Link to={`/product/${product.id}`} className="block">
                  <h3 className="text-lg font-semibold text-keroluxe-black dark:text-keroluxe-white group-hover:text-keroluxe-gold transition-colors truncate" title={product.name}>
                    {product.name}
                  </h3>
                </Link>
                <p className="text-sm text-keroluxe-grey dark:text-neutral-400 mb-1">{product.category}</p>
                <div className="flex items-baseline space-x-2 mb-3">
                  <p className={`text-xl font-bold ${isSale ? 'text-keroluxe-gold' : 'text-keroluxe-black dark:text-keroluxe-white'}`}>
                    ₦{product.price.toFixed(2)}
                  </p>
                  {isSale && product.originalPrice && (
                    <p className="text-sm text-keroluxe-grey dark:text-neutral-400 line-through">
                      ₦{product.originalPrice.toFixed(2)}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between space-x-2 mt-2">
                <Button
                  onClick={handleAddToCart}
                  variant="outline"
                  size="sm"
                  className="flex-1 border-keroluxe-black text-keroluxe-black hover:bg-keroluxe-black hover:text-keroluxe-white dark:border-keroluxe-gold dark:text-keroluxe-gold dark:hover:bg-keroluxe-gold dark:hover:text-keroluxe-black transition-colors"
                  aria-label={`Add ${product.name} to cart`}
                >
                  <ShoppingCart className="mr-2 h-4 w-4" /> Add to Cart
                </Button>
                <Button
                  onClick={handleToggleWishlist}
                  variant="ghost"
                  size="icon"
                  className="text-keroluxe-grey hover:text-keroluxe-gold dark:text-neutral-400 dark:hover:text-keroluxe-gold"
                  aria-label={isInWishlist ? `Remove ${product.name} from wishlist` : `Add ${product.name} to wishlist`}
                >
                  <Heart className={`h-5 w-5 transition-colors ${isInWishlist ? 'fill-keroluxe-gold text-keroluxe-gold' : 'text-keroluxe-grey dark:text-neutral-400'}`} />
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      );
    };

    export default ProductCard;