import React, { useState } from 'react';
    import { Link, NavLink, useNavigate } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { useAppContext } from '@/contexts/AppContext';
    import { Scissors, ChevronDown } from 'lucide-react';
    import { cn } from '@/lib/utils';
    import MegaMenu from '@/components/navigation/MegaMenu';
    import MobileNav from '@/components/navigation/MobileNav';
    import NavIcons from '@/components/navigation/NavIcons';

    const DesktopNavItem = ({ to, children, className }) => (
      <NavLink
        to={to}
        className={({ isActive }) =>
          cn(
            "text-sm font-medium transition-colors nav-icon", // Uses nav-icon for consistent coloring
            isActive && "text-keroluxe-gold font-semibold",
            className
          )
        }
      >
        {children}
      </NavLink>
    );

    const Navbar = () => {
      const [isMegaMenuOpen, setIsMegaMenuOpen] = useState(false);
      const { user, logout } = useAppContext();
      const navigate = useNavigate();
      
      const handleProfileClick = () => {
        if (user) {
          navigate('/profile');
        } else {
          navigate('/login');
        }
      };
      
      const navLinkStyles = "nav-icon"; // Updated to use nav-icon class from index.css
      const activeNavLinkStyles = "text-keroluxe-gold font-semibold";

      return (
        <header className="sticky top-0 z-50 w-full border-b border-keroluxe-grey/20 dark:border-neutral-700 bg-keroluxe-white dark:bg-keroluxe-black">
          <div className="container mx-auto flex h-16 items-center justify-between px-4">
            <Link to="/" className="flex items-center space-x-2" aria-label="KeroLuxe Home">
              <Scissors className="h-7 w-7 text-keroluxe-gold" />
              <span className="text-2xl font-bold font-serif text-keroluxe-black dark:text-keroluxe-white">KeroLuxe</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-6">
              <DesktopNavItem to="/">Home</DesktopNavItem>
              <div 
                className="relative" 
                onMouseEnter={() => setIsMegaMenuOpen(true)} 
                onMouseLeave={() => setIsMegaMenuOpen(false)}
              >
                <button 
                  className={cn("flex items-center text-sm font-medium transition-colors outline-none", isMegaMenuOpen ? activeNavLinkStyles : navLinkStyles)}
                  aria-expanded={isMegaMenuOpen}
                >
                  Categories <ChevronDown className={`ml-1 h-4 w-4 transition-transform ${isMegaMenuOpen ? 'rotate-180' : ''}`} />
                </button>
                <MegaMenu isOpen={isMegaMenuOpen} closeMegaMenu={() => setIsMegaMenuOpen(false)} />
              </div>
              <DesktopNavItem to="/new-arrivals">New Arrivals</DesktopNavItem>
              <DesktopNavItem to="/best-sellers">Best Sellers</DesktopNavItem>
              <DesktopNavItem to="/sale">Sale</DesktopNavItem>
            </nav>

            <div className="flex items-center">
              <NavIcons handleProfileClick={handleProfileClick} />
              <MobileNav user={user} logout={logout} handleProfileClick={handleProfileClick} />
            </div>
          </div>
        </header>
      );
    };

    export default Navbar;