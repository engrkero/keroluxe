import React, { useState } from 'react';
    import { Link, NavLink } from 'react-router-dom';
    import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
    import { Button } from '@/components/ui/button';
    import { Menu } from 'lucide-react';
    import { categories } from '@/data/products';
    import { cn } from '@/lib/utils';
    import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
    import { useAppContext } from '@/contexts/AppContext';

    const MobileNavItem = ({ category, closeMobileMenu, openSubcategories, toggleSubcategory }) => {
      const hasSubcategories = category.subcategories && category.subcategories.length > 0;
      const isOpen = openSubcategories[category.slug];

      if (hasSubcategories) {
        return (
          <Accordion type="single" collapsible value={isOpen ? category.slug : undefined} onValueChange={() => toggleSubcategory(category.slug)} className="w-full">
            <AccordionItem value={category.slug} className="border-b-0">
              <AccordionTrigger className="py-2 text-base flex justify-between items-center w-full text-keroluxe-grey dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold data-[state=open]:text-keroluxe-gold [&[data-state=open]>svg]:rotate-90 no-underline hover:no-underline">
                <Link to={`/category/${category.slug}`} onClick={(e) => { e.stopPropagation(); closeMobileMenu(); }} className="flex-grow text-left">
                  {category.name}
                </Link>
              </AccordionTrigger>
              <AccordionContent className="pl-4 pb-0">
                {category.subcategories.map(sub => (
                  <NavLink
                    key={sub.slug}
                    to={`/category/${sub.slug}`}
                    onClick={closeMobileMenu}
                    className={({ isActive }) =>
                      cn("block py-1.5 text-sm transition-colors", isActive ? "text-keroluxe-gold font-medium" : "text-keroluxe-grey dark:text-neutral-300 hover:text-keroluxe-gold dark:hover:text-keroluxe-gold")
                    }
                  >
                    {sub.name}
                  </NavLink>
                ))}
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        );
      }

      return (
        <NavLink
          to={`/category/${category.slug}`}
          onClick={closeMobileMenu}
          className={({ isActive }) =>
            cn("block py-2 text-base transition-colors", isActive ? "text-keroluxe-gold font-semibold" : "text-keroluxe-grey dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold")
          }
        >
          {category.name}
        </NavLink>
      );
    };

    const MobileNav = ({ user, logout, handleProfileClick }) => {
      const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
      const [openSubcategories, setOpenSubcategories] = useState({});

      const closeMobileMenu = () => setIsMobileMenuOpen(false);
      const toggleSubcategory = (slug) => {
        setOpenSubcategories(prev => ({ ...prev, [slug]: !prev[slug] }));
      };

      return (
        <div className="md:hidden">
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Open menu" className="text-keroluxe-grey hover:text-keroluxe-gold dark:text-keroluxe-grey dark:hover:text-keroluxe-gold">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[340px] bg-keroluxe-white dark:bg-keroluxe-black p-0 flex flex-col">
              <SheetHeader className="p-4 border-b border-keroluxe-grey/20 dark:border-keroluxe-grey/30">
                <SheetTitle className="text-xl font-serif text-keroluxe-black dark:text-keroluxe-white">Menu</SheetTitle>
              </SheetHeader>
              <nav className="flex-1 flex flex-col space-y-1 p-4 overflow-y-auto">
                <NavLink to="/" onClick={closeMobileMenu} className={({ isActive }) => cn("block py-2 text-base transition-colors", isActive ? "text-keroluxe-gold font-semibold" : "text-keroluxe-grey dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold")}>Home</NavLink>
                
                {categories.map(category => (
                  <MobileNavItem 
                    key={category.slug}
                    category={category}
                    closeMobileMenu={closeMobileMenu}
                    openSubcategories={openSubcategories}
                    toggleSubcategory={toggleSubcategory}
                  />
                ))}

                <NavLink to="/new-arrivals" onClick={closeMobileMenu} className={({ isActive }) => cn("block py-2 text-base transition-colors", isActive ? "text-keroluxe-gold font-semibold" : "text-keroluxe-grey dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold")}>New Arrivals</NavLink>
                <NavLink to="/best-sellers" onClick={closeMobileMenu} className={({ isActive }) => cn("block py-2 text-base transition-colors", isActive ? "text-keroluxe-gold font-semibold" : "text-keroluxe-grey dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold")}>Best Sellers</NavLink>
                <NavLink to="/sale" onClick={closeMobileMenu} className={({ isActive }) => cn("block py-2 text-base transition-colors", isActive ? "text-keroluxe-gold font-semibold" : "text-keroluxe-grey dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold")}>Sale</NavLink>
                <hr className="border-keroluxe-grey/20 dark:border-keroluxe-grey/30 my-3"/>
                <NavLink to="/about" onClick={closeMobileMenu} className={({ isActive }) => cn("block py-2 text-base transition-colors", isActive ? "text-keroluxe-gold font-semibold" : "text-keroluxe-grey dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold")}>About Us</NavLink>
                <NavLink to="/contact" onClick={closeMobileMenu} className={({ isActive }) => cn("block py-2 text-base transition-colors", isActive ? "text-keroluxe-gold font-semibold" : "text-keroluxe-grey dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold")}>Contact Us</NavLink>
                <hr className="border-keroluxe-grey/20 dark:border-keroluxe-grey/30 my-3"/>
                 {user ? (
                  <Button onClick={() => { logout(); closeMobileMenu(); }} className="w-full justify-start bg-keroluxe-black text-keroluxe-white hover:bg-keroluxe-gold hover:text-keroluxe-black dark:bg-keroluxe-gold dark:text-keroluxe-black dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black">Logout</Button>
                ) : (
                  <Button asChild onClick={closeMobileMenu} className="w-full justify-start bg-keroluxe-black text-keroluxe-white hover:bg-keroluxe-gold hover:text-keroluxe-black dark:bg-keroluxe-gold dark:text-keroluxe-black dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black">
                    <Link to="/login">Login / Signup</Link>
                  </Button>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      );
    };

    export default MobileNav;