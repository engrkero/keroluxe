import React from 'react';
    import { Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { categories } from '@/data/products';
    import { cn } from '@/lib/utils';
    import { ChevronDown } from 'lucide-react';

    const MegaMenu = ({ isOpen, closeMegaMenu }) => {
      const nightwearFocus = categories.find(c => c.slug.includes("nightwears-female"));
      const baleFocus = categories.find(c => c.slug === "bale-first-class");
      const otherCategories = categories.filter(c => c.slug !== nightwearFocus?.slug && c.slug !== baleFocus?.slug);

      if (!isOpen) return null;

      return (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3, ease: "easeInOut" }}
          className="absolute top-full left-0 mt-0 w-full bg-keroluxe-white dark:bg-neutral-800 shadow-2xl z-40 border-t border-keroluxe-grey/20 dark:border-neutral-700"
          onMouseLeave={closeMegaMenu}
        >
          <div className="container mx-auto grid grid-cols-1 md:grid-cols-4 gap-x-6 gap-y-8 py-8 px-4">
            {nightwearFocus && (
              <div className="md:col-span-1">
                <h3 className="font-semibold text-lg text-keroluxe-gold mb-4">{nightwearFocus.name}</h3>
                <ul className="space-y-2.5">
                  <li><Link to={`/category/${nightwearFocus.slug}`} onClick={closeMegaMenu} className="text-sm text-keroluxe-black dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold transition-colors">View All {nightwearFocus.name}</Link></li>
                </ul>
                <div className="mt-6 rounded-lg overflow-hidden shadow-md">
                   <img  alt={`${nightwearFocus.name} promotion`} className="object-cover h-48 w-full" src="https://images.unsplash.com/photo-1637626636162-f9f987642384" />
                </div>
              </div>
            )}
             {baleFocus && (
              <div className="md:col-span-1">
                <h3 className="font-semibold text-lg text-keroluxe-gold mb-4">{baleFocus.name}</h3>
                <ul className="space-y-2.5">
                  <li><Link to={`/category/${baleFocus.slug}`} onClick={closeMegaMenu} className="text-sm text-keroluxe-black dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold transition-colors">All {baleFocus.name}</Link></li>
                  {baleFocus.subcategories.map(sub => (
                     <li key={sub.slug}><Link to={`/category/${sub.slug}`} onClick={closeMegaMenu} className="text-sm text-keroluxe-black dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold transition-colors">{sub.name}</Link></li>
                  ))}
                </ul>
                 <div className="mt-6 rounded-lg overflow-hidden shadow-md">
                   <img  alt={`${baleFocus.name} promotion`} className="object-cover h-48 w-full" src="https://images.unsplash.com/photo-1556905055-8f358a7a47b2" />
                </div>
              </div>
            )}
            
            <div className={cn(
                "grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4",
                (nightwearFocus && baleFocus) ? "md:col-span-1" : (nightwearFocus || baleFocus ? "md:col-span-2" : "md:col-span-3")
            )}>
              {otherCategories.map(category => (
                <div key={category.slug} className="mb-4">
                  <h3 className="font-semibold text-keroluxe-black dark:text-keroluxe-off-white mb-3">{category.name}</h3>
                  <ul className="space-y-2">
                     <li><Link to={`/category/${category.slug}`} onClick={closeMegaMenu} className="text-sm text-keroluxe-black dark:text-keroluxe-off-white hover:text-keroluxe-gold dark:hover:text-keroluxe-gold transition-colors">All {category.name}</Link></li>
                     {/* If other categories also have subcategories, map them here */}
                  </ul>
                </div>
              ))}
            </div>

            <div className="md:col-span-1">
                <h3 className="font-semibold text-lg text-keroluxe-black dark:text-keroluxe-off-white mb-4">Featured</h3>
                <div className="rounded-lg overflow-hidden shadow-md mb-4">
                 <img  alt="Featured Collection - Stylish apparel" className="object-cover h-52 w-full" src="https://images.unsplash.com/photo-1532613903-5701881f09d8" />
                </div>
                <Link to="/new-arrivals" onClick={closeMegaMenu} className="block text-sm font-medium text-keroluxe-gold hover:underline transition-colors">Shop New Arrivals</Link>
                <Link to="/sale" onClick={closeMegaMenu} className="block text-sm font-medium text-keroluxe-gold hover:underline mt-1.5 transition-colors">View Sale Items</Link>
            </div>
          </div>
        </motion.div>
      );
    };

    export default MegaMenu;
