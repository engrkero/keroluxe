import React from 'react';
    import { Link } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { useAppContext } from '@/contexts/AppContext';
    import { ShoppingCart, Heart, User, Sun, Moon } from 'lucide-react';

    const NavIcons = ({ handleProfileClick }) => {
      const { cart, wishlist, theme, toggleTheme } = useAppContext();

      return (
        <div className="flex items-center space-x-2 sm:space-x-3">
          <Button variant="ghost" size="icon" onClick={toggleTheme} aria-label="Toggle theme" className="nav-icon">
            {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
          <Link to="/wishlist" className="relative nav-icon" aria-label="Wishlist">
            <Heart className="h-5 w-5 sm:h-6 sm:w-6" />
            {wishlist.length > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-keroluxe-gold text-xs text-keroluxe-black">
                {wishlist.length}
              </span>
            )}
          </Link>
          <Link to="/cart" className="relative nav-icon" aria-label="Shopping Cart">
            <ShoppingCart className="h-5 w-5 sm:h-6 sm:w-6" />
            {cart.length > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-keroluxe-gold text-xs text-keroluxe-black">
                {cart.reduce((count, item) => count + item.quantity, 0)}
              </span>
            )}
          </Link>
          <Button variant="ghost" size="icon" onClick={handleProfileClick} aria-label="Profile" className="nav-icon">
            <User className="h-5 w-5 sm:h-6 sm:w-6" />
          </Button>
        </div>
      );
    };

    export default NavIcons;