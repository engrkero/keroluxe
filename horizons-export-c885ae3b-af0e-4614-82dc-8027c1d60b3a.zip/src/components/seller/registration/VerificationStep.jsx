import React from 'react';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Button } from '@/components/ui/button';
    import { CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { ShieldCheck, Camera, CheckCircle } from 'lucide-react';
    import { motion } from 'framer-motion';

    const VerificationStep = ({ 
      formData, 
      handleInputChange, 
      handleFileChange, 
      filePreviews,
      isCameraOn,
      videoRef,
      canvasRef,
      startCamera,
      capturePhoto,
      stopCamera 
    }) => {
      return (
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="space-y-3">
          <CardHeader className="p-0 mb-3">
            <CardTitle className="text-lg text-keroluxe-black dark:text-keroluxe-white flex items-center">
              <ShieldCheck className="mr-2 h-5 w-5 text-keroluxe-gold" /> Verification
            </CardTitle>
            <CardDescription className="text-keroluxe-grey dark:text-neutral-400 text-xs">Upload IDs, passport photo and complete facial scan.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 p-0 max-h-[calc(100vh-20rem)] overflow-y-auto pr-2">
            <div>
              <Label htmlFor="ninNumber">NIN Digits (11 digits)</Label>
              <Input id="ninNumber" name="ninNumber" type="text" pattern="\d*" maxLength="11" value={formData.ninNumber} onChange={handleInputChange} required className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
            </div>
            <div>
              <Label htmlFor="ninFrontFile">NIN Slip - Front (Required)</Label>
              <Input id="ninFrontFile" name="ninFrontFile" type="file" onChange={handleFileChange} required className="mt-1 file:text-xs file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:font-semibold file:bg-keroluxe-gold/20 file:text-keroluxe-gold hover:file:bg-keroluxe-gold/30 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
              {filePreviews.ninFrontFile && <img src={filePreviews.ninFrontFile} alt="NIN Front Preview" className="mt-1 h-16 object-contain border rounded dark:border-neutral-600"/>}
            </div>
            <div>
              <Label htmlFor="ninBackFile">NIN Slip - Back (Required)</Label>
              <Input id="ninBackFile" name="ninBackFile" type="file" onChange={handleFileChange} required className="mt-1 file:text-xs file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:font-semibold file:bg-keroluxe-gold/20 file:text-keroluxe-gold hover:file:bg-keroluxe-gold/30 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
              {filePreviews.ninBackFile && <img src={filePreviews.ninBackFile} alt="NIN Back Preview" className="mt-1 h-16 object-contain border rounded dark:border-neutral-600"/>}
            </div>
            <div>
              <Label htmlFor="bvnNumber">BVN Digits (11 digits)</Label>
              <Input id="bvnNumber" name="bvnNumber" type="text" pattern="\d*" maxLength="11" value={formData.bvnNumber} onChange={handleInputChange} required className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
            </div>
            <div>
              <Label htmlFor="passportPhotoFile">Passport Photograph (Required)</Label>
              <Input id="passportPhotoFile" name="passportPhotoFile" type="file" accept="image/*" onChange={handleFileChange} required className="mt-1 file:text-xs file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:font-semibold file:bg-keroluxe-gold/20 file:text-keroluxe-gold hover:file:bg-keroluxe-gold/30 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
              {filePreviews.passportPhotoFile && <img src={filePreviews.passportPhotoFile} alt="Passport Preview" className="mt-1 h-16 w-16 object-cover rounded border dark:border-neutral-600"/>}
            </div>
            <div>
              <Label htmlFor="cacFile">CAC Certificate (Optional)</Label>
              <Input id="cacFile" name="cacFile" type="file" onChange={handleFileChange} className="mt-1 file:text-xs file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:font-semibold file:bg-keroluxe-gold/20 file:text-keroluxe-gold hover:file:bg-keroluxe-gold/30 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
              {filePreviews.cacFile && <span className="text-xs text-green-500 flex items-center mt-1"><CheckCircle className="h-3 w-3 mr-1"/>{formData.cacFile.name}</span>}
            </div>
          
            <div className="pt-2 border-t dark:border-neutral-700 mt-4">
              <Label className="flex items-center text-keroluxe-black dark:text-keroluxe-white"><Camera className="mr-2 h-4 w-4 text-keroluxe-gold"/>Facial Verification (Required)</Label>
              <div className="mt-2 p-2 border rounded-md bg-keroluxe-off-white dark:bg-neutral-700">
                {!isCameraOn && !filePreviews.facialVerificationPhoto && (
                  <Button type="button" onClick={startCamera} variant="outline" className="w-full border-keroluxe-gold text-keroluxe-gold hover:bg-keroluxe-gold/10 dark:text-keroluxe-off-white dark:border-keroluxe-gold dark:hover:bg-keroluxe-gold/20">Start Camera Scan</Button>
                )}
                {isCameraOn && (
                  <div className="flex flex-col items-center">
                    <video ref={videoRef} autoPlay playsInline className="w-full max-w-[320px] h-auto rounded border dark:border-neutral-600 mb-2"></video>
                    <div className="flex gap-2">
                      <Button type="button" onClick={capturePhoto} className="btn-primary">Capture Photo</Button>
                      <Button type="button" onClick={stopCamera} variant="destructive">Cancel Scan</Button>
                    </div>
                  </div>
                )}
                 {filePreviews.facialVerificationPhoto && !isCameraOn && (
                  <div className="text-center">
                    <img src={filePreviews.facialVerificationPhoto} alt="Facial Scan Preview" className="mt-1 h-24 w-auto mx-auto object-cover rounded border dark:border-neutral-600"/>
                    <p className="text-xs text-green-500 mt-1">Facial scan captured.</p>
                    <Button type="button" onClick={startCamera} variant="link" size="sm" className="text-keroluxe-gold text-xs">Retake Photo</Button>
                  </div>
                )}
                <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
                 <p className="text-xs text-keroluxe-grey dark:text-neutral-400 mt-2 text-center">Position your face clearly in the frame for verification.</p>
              </div>
            </div>
          </CardContent>
        </motion.div>
      );
    };

    export default VerificationStep;