import React from 'react';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Store } from 'lucide-react';
    import { motion } from 'framer-motion';

    const StoreStep = ({ formData, handleInputChange }) => {
      return (
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="space-y-3">
          <CardHeader className="p-0 mb-3">
            <CardTitle className="text-lg text-keroluxe-black dark:text-keroluxe-white flex items-center">
              <Store className="mr-2 h-5 w-5 text-keroluxe-gold" /> Store Details
            </CardTitle>
            <CardDescription className="text-keroluxe-grey dark:text-neutral-400 text-xs">Tell us about your store.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 p-0">
            <div>
              <Label htmlFor="storeName">Store Name</Label>
              <Input id="storeName" name="storeName" value={formData.storeName} onChange={handleInputChange} required className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
            </div>
            <div>
              <Label htmlFor="storeDescription">Store Description</Label>
              <Textarea id="storeDescription" name="storeDescription" value={formData.storeDescription} onChange={handleInputChange} rows={2} className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
            </div>
            <div>
              <Label htmlFor="contactPhone">Contact Phone</Label>
              <Input id="contactPhone" name="contactPhone" type="tel" value={formData.contactPhone} onChange={handleInputChange} required className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
            </div>
          </CardContent>
        </motion.div>
      );
    };

    export default StoreStep;