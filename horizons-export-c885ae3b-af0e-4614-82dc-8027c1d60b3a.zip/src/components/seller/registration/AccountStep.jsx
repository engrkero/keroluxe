import React from 'react';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { UserPlus } from 'lucide-react';
    import { motion } from 'framer-motion';

    const AccountStep = ({ formData, handleInputChange }) => {
      return (
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="space-y-3">
          <CardHeader className="p-0 mb-3">
            <CardTitle className="text-lg text-keroluxe-black dark:text-keroluxe-white flex items-center">
              <UserPlus className="mr-2 h-5 w-5 text-keroluxe-gold" /> Account Information
            </CardTitle>
            <CardDescription className="text-keroluxe-grey dark:text-neutral-400 text-xs">Create your seller account.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 p-0">
            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input id="email" name="email" type="email" value={formData.email} onChange={handleInputChange} required className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
            </div>
            <div>
              <Label htmlFor="password">Password (min. 6 characters)</Label>
              <Input id="password" name="password" type="password" value={formData.password} onChange={handleInputChange} required className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
            </div>
            <div>
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input id="confirmPassword" name="confirmPassword" type="password" value={formData.confirmPassword} onChange={handleInputChange} required className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
            </div>
          </CardContent>
        </motion.div>
      );
    };

    export default AccountStep;