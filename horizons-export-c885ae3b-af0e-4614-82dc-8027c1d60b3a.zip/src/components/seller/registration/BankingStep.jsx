import React from 'react';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Banknote } from 'lucide-react';
    import { motion } from 'framer-motion';

    const BankingStep = ({ formData, handleInputChange }) => {
      return (
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="space-y-3">
          <CardHeader className="p-0 mb-3">
            <CardTitle className="text-lg text-keroluxe-black dark:text-keroluxe-white flex items-center">
              <Banknote className="mr-2 h-5 w-5 text-keroluxe-gold" /> Banking Details
            </CardTitle>
            <CardDescription className="text-keroluxe-grey dark:text-neutral-400 text-xs">For weekly payouts (Moniepoint Only).</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 p-0">
            <div>
              <Label htmlFor="bankName">Bank Name</Label>
              <Input id="bankName" name="bankName" value={formData.bankName} disabled className="mt-1 bg-neutral-200 dark:bg-neutral-600 cursor-not-allowed text-keroluxe-black dark:text-keroluxe-white"/>
            </div>
            <div>
              <Label htmlFor="accountNumber">Account Number</Label>
              <Input id="accountNumber" name="accountNumber" value={formData.accountNumber} onChange={handleInputChange} required className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
            </div>
            <div>
              <Label htmlFor="accountName">Account Name</Label>
              <Input id="accountName" name="accountName" value={formData.accountName} onChange={handleInputChange} required className="mt-1 bg-keroluxe-off-white dark:bg-neutral-700 text-keroluxe-black dark:text-keroluxe-white"/>
            </div>
          </CardContent>
        </motion.div>
      );
    };

    export default BankingStep;