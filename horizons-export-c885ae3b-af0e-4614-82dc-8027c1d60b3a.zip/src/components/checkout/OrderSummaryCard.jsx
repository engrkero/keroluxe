import React from 'react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Separator } from '@/components/ui/separator';

    const OrderSummaryCard = ({ cart }) => {
      const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
      const shippingCost = subtotal > 25000 || subtotal === 0 ? 0 : 2500; // Example: Free shipping over ₦25000, else ₦2500
      const total = subtotal + shippingCost;

      return (
        <Card className="sticky top-24 shadow-xl bg-keroluxe-off-white dark:bg-neutral-800 border-keroluxe-grey/20 dark:border-neutral-700">
          <CardHeader>
            <CardTitle className="text-2xl font-serif text-keroluxe-black dark:text-keroluxe-white">Order Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="max-h-48 overflow-y-auto space-y-2 pr-2">
              {cart.map(item => (
                <div key={`${item.id}-${item.selectedSize}-${item.selectedColor}`} className="flex justify-between items-center text-sm">
                  <span className="text-keroluxe-grey dark:text-neutral-300 truncate max-w-[150px]">{item.name} (x{item.quantity})</span>
                  <span className="text-keroluxe-black dark:text-keroluxe-white font-medium">₦{(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>
            <Separator className="bg-keroluxe-grey/30 dark:bg-neutral-700 my-2" />
            <div className="flex justify-between text-keroluxe-black dark:text-keroluxe-white">
              <span>Subtotal</span>
              <span>₦{subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-keroluxe-black dark:text-keroluxe-white">
              <span>Shipping</span>
              <span>{shippingCost === 0 ? 'Free' : `₦${shippingCost.toFixed(2)}`}</span>
            </div>
            <Separator className="bg-keroluxe-grey/30 dark:bg-neutral-700 my-2" />
            <div className="flex justify-between text-xl font-semibold text-keroluxe-black dark:text-keroluxe-white">
              <span>Total</span>
              <span>₦{total.toFixed(2)}</span>
            </div>
          </CardContent>
        </Card>
      );
    };

    export default OrderSummaryCard;