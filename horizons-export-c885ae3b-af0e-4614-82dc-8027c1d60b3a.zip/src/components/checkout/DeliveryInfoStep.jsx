import React from 'react';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Checkbox } from '@/components/ui/checkbox';
    import { motion } from 'framer-motion';

    const DeliveryInfoStep = ({ formData, handleInputChange, setFormData }) => {
      return (
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
          <h2 className="text-2xl font-semibold font-serif text-keroluxe-black dark:text-keroluxe-white">Delivery Information</h2>
          <div>
            <Label htmlFor="email" className="text-keroluxe-grey dark:text-neutral-300">Email Address</Label>
            <Input type="email" name="email" id="email" value={formData.email} onChange={handleInputChange} placeholder="you@example.com" required className="bg-white/80 dark:bg-neutral-700/80 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="firstName" className="text-keroluxe-grey dark:text-neutral-300">First Name</Label>
              <Input type="text" name="firstName" id="firstName" value={formData.firstName} onChange={handleInputChange} required className="bg-white/80 dark:bg-neutral-700/80 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
            </div>
            <div>
              <Label htmlFor="lastName" className="text-keroluxe-grey dark:text-neutral-300">Last Name</Label>
              <Input type="text" name="lastName" id="lastName" value={formData.lastName} onChange={handleInputChange} required className="bg-white/80 dark:bg-neutral-700/80 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
            </div>
          </div>
          <div>
            <Label htmlFor="address" className="text-keroluxe-grey dark:text-neutral-300">Address</Label>
            <Input type="text" name="address" id="address" value={formData.address} onChange={handleInputChange} placeholder="123 Main St" required className="bg-white/80 dark:bg-neutral-700/80 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
          </div>
          <div>
            <Label htmlFor="apartment" className="text-keroluxe-grey dark:text-neutral-300">Apartment, suite, etc. (optional)</Label>
            <Input type="text" name="apartment" id="apartment" value={formData.apartment} onChange={handleInputChange} className="bg-white/80 dark:bg-neutral-700/80 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="city" className="text-keroluxe-grey dark:text-neutral-300">City</Label>
              <Input type="text" name="city" id="city" value={formData.city} onChange={handleInputChange} required className="bg-white/80 dark:bg-neutral-700/80 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
            </div>
            <div>
              <Label htmlFor="state" className="text-keroluxe-grey dark:text-neutral-300">State / Province</Label>
              <Input type="text" name="state" id="state" value={formData.state} onChange={handleInputChange} required className="bg-white/80 dark:bg-neutral-700/80 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
            </div>
            <div>
              <Label htmlFor="zipCode" className="text-keroluxe-grey dark:text-neutral-300">ZIP / Postal Code</Label>
              <Input type="text" name="zipCode" id="zipCode" value={formData.zipCode} onChange={handleInputChange} required className="bg-white/80 dark:bg-neutral-700/80 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
            </div>
          </div>
           <div>
            <Label htmlFor="phone" className="text-keroluxe-grey dark:text-neutral-300">Phone</Label>
            <Input type="tel" name="phone" id="phone" value={formData.phone} onChange={handleInputChange} required className="bg-white/80 dark:bg-neutral-700/80 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="saveInfo" 
              name="saveInfo" 
              checked={formData.saveInfo} 
              onCheckedChange={(checked) => setFormData(prev => ({...prev, saveInfo: Boolean(checked)}))} 
              className="border-keroluxe-gold data-[state=checked]:bg-keroluxe-gold data-[state=checked]:text-white" 
            />
            <Label htmlFor="saveInfo" className="text-sm text-keroluxe-grey dark:text-neutral-400">Save this information for next time</Label>
          </div>
        </motion.div>
      );
    };

    export default DeliveryInfoStep;