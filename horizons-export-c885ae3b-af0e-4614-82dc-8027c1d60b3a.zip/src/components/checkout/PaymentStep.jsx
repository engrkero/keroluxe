import React from 'react';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
    import { motion } from 'framer-motion';
    import { CreditCard, Lock, DollarSign, Bitcoin } from 'lucide-react';

    const MoniepointIcon = () => <DollarSign className="mr-2 h-5 w-5 text-blue-600" />;
    const FlutterwaveIcon = () => <DollarSign className="mr-2 h-5 w-5 text-orange-500" />;
    const PaystackIcon = () => <DollarSign className="mr-2 h-5 w-5 text-green-500" />;
    const OPayIcon = () => <DollarSign className="mr-2 h-5 w-5 text-green-700" />;


    const PaymentStep = ({ formData, handleInputChange, handlePaymentMethodChange }) => {
      const paymentOptions = [
        { value: 'creditCard', label: 'Credit/Debit Card', icon: <CreditCard className="mr-2 h-5 w-5 text-keroluxe-black dark:text-keroluxe-white" /> },
        { value: 'moniepoint', label: 'Moniepoint', icon: <MoniepointIcon /> },
        { value: 'flutterwave', label: 'Flutterwave', icon: <FlutterwaveIcon /> },
        { value: 'paystack', label: 'Paystack', icon: <PaystackIcon /> },
        { value: 'opay', label: 'OPay', icon: <OPayIcon /> },
        { value: 'crypto', label: 'Cryptocurrency', icon: <Bitcoin className="mr-2 h-5 w-5 text-keroluxe-gold" /> },
      ];

      return (
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
          <h2 className="text-2xl font-semibold font-serif text-keroluxe-black dark:text-keroluxe-white">Payment Details</h2>
          <RadioGroup name="paymentMethod" value={formData.paymentMethod} onValueChange={handlePaymentMethodChange} className="space-y-3">
            {paymentOptions.map(option => (
              <Label 
                key={option.value} 
                htmlFor={option.value} 
                className={`flex items-center p-4 border rounded-md cursor-pointer transition-colors hover:bg-keroluxe-gold/10 dark:hover:bg-keroluxe-gold/5 text-keroluxe-black dark:text-keroluxe-white ${formData.paymentMethod === option.value ? 'bg-keroluxe-gold/20 dark:bg-keroluxe-gold/10 border-keroluxe-gold dark:border-keroluxe-gold' : 'border-keroluxe-grey/30 dark:border-neutral-700'}`}
              >
                <RadioGroupItem value={option.value} id={option.value} className="mr-3 border-keroluxe-gold text-keroluxe-gold focus:ring-keroluxe-gold dark:border-neutral-500" />
                {option.icon} {option.label}
              </Label>
            ))}
          </RadioGroup>

          {formData.paymentMethod === 'creditCard' && (
            <div className="space-y-4 pt-4 border-t border-keroluxe-grey/20 dark:border-neutral-700 mt-4">
              <div>
                <Label htmlFor="cardName" className="text-keroluxe-grey dark:text-neutral-300">Name on Card</Label>
                <Input type="text" name="cardName" id="cardName" value={formData.cardName} onChange={handleInputChange} required className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
              </div>
              <div>
                <Label htmlFor="cardNumber" className="text-keroluxe-grey dark:text-neutral-300">Card Number</Label>
                <Input type="text" name="cardNumber" id="cardNumber" value={formData.cardNumber} onChange={handleInputChange} placeholder="•••• •••• •••• ••••" required className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="cardExpiry" className="text-keroluxe-grey dark:text-neutral-300">Expiry Date (MM/YY)</Label>
                  <Input type="text" name="cardExpiry" id="cardExpiry" value={formData.cardExpiry} onChange={handleInputChange} placeholder="MM/YY" required className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
                </div>
                <div>
                  <Label htmlFor="cardCVC" className="text-keroluxe-grey dark:text-neutral-300">CVC</Label>
                  <Input type="text" name="cardCVC" id="cardCVC" value={formData.cardCVC} onChange={handleInputChange} placeholder="•••" required className="bg-keroluxe-white dark:bg-neutral-700 border-keroluxe-grey/30 dark:border-neutral-600 focus:border-keroluxe-gold dark:focus:border-keroluxe-gold text-keroluxe-black dark:text-keroluxe-white" />
                </div>
              </div>
              <div className="flex items-center text-sm text-green-600 dark:text-green-400">
                <Lock className="mr-1 h-4 w-4" /> Secure SSL Encryption
              </div>
            </div>
          )}
          {['moniepoint', 'flutterwave', 'paystack', 'opay', 'crypto'].includes(formData.paymentMethod) && (
            <div className="pt-4 border-t border-keroluxe-grey/20 dark:border-neutral-700 mt-4 text-center">
              <p className="text-keroluxe-grey dark:text-neutral-300">You will be redirected to {formData.paymentMethod.charAt(0).toUpperCase() + formData.paymentMethod.slice(1)} to complete your payment.</p>
            </div>
          )}
        </motion.div>
      );
    };
    export default PaymentStep;