import React from 'react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Separator } from '@/components/ui/separator';
    import { AlertCircle, CheckCircle2 } from 'lucide-react';

    const ReviewOrderStep = ({ cart, formData, paymentMethodDetails, onPlaceOrder, isPlacingOrder, placeOrderError }) => {
      const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
      const shippingCost = subtotal > 25000 || subtotal === 0 ? 0 : 2500;
      const total = subtotal + shippingCost;

      const formatAddress = (addressObj) => {
        if (!addressObj) return "Not provided";
        const parts = [
          addressObj.addressLine1,
          addressObj.addressLine2,
          addressObj.city,
          addressObj.state,
          addressObj.postalCode,
          addressObj.country
        ].filter(Boolean);
        return parts.join(', ') || "Not provided";
      };


      return (
        <div className="space-y-8">
          <h2 className="text-2xl font-semibold font-serif text-keroluxe-gold">Review Your Order</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-keroluxe-off-white dark:bg-neutral-800">
              <CardHeader>
                <CardTitle className="text-keroluxe-black dark:text-keroluxe-white">Shipping Details</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-keroluxe-grey dark:text-neutral-300 space-y-1">
                <p><strong>Name:</strong> {formData.firstName} {formData.lastName}</p>
                <p><strong>Email:</strong> {formData.email}</p>
                <p><strong>Phone:</strong> {formData.phone}</p>
                <p><strong>Address:</strong> {formatAddress(formData.deliveryAddress)}</p>
              </CardContent>
            </Card>

            <Card className="bg-keroluxe-off-white dark:bg-neutral-800">
              <CardHeader>
                <CardTitle className="text-keroluxe-black dark:text-keroluxe-white">Payment Information</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-keroluxe-grey dark:text-neutral-300 space-y-1">
                <p><strong>Method:</strong> {paymentMethodDetails?.name || 'Not Selected'}</p>
                {paymentMethodDetails?.details && <p>{paymentMethodDetails.details}</p>}
              </CardContent>
            </Card>
          </div>

          <Card className="bg-keroluxe-off-white dark:bg-neutral-800">
            <CardHeader>
              <CardTitle className="text-keroluxe-black dark:text-keroluxe-white">Order Items</CardTitle>
            </CardHeader>
            <CardContent>
              {cart.map(item => (
                <div key={`${item.id}-${item.selectedSize}-${item.selectedColor}`} className="flex justify-between items-center py-3 border-b border-keroluxe-grey/20 dark:border-neutral-700 last:border-b-0">
                  <div className="flex items-center space-x-3">
                    <img  src={item.images?.[0] || `https://source.unsplash.com/random/64x64/?${item.name?.replace(/\s/g, ',') || 'fashion'}`} alt={item.name} className="w-16 h-16 object-cover rounded-md"/>
                    <div>
                      <p className="font-semibold text-keroluxe-black dark:text-keroluxe-white">{item.name}</p>
                      <p className="text-xs text-keroluxe-grey dark:text-neutral-400">
                        {item.selectedSize && `Size: ${item.selectedSize}`} {item.selectedColor && `Color: ${item.selectedColor}`} (Qty: {item.quantity})
                      </p>
                    </div>
                  </div>
                  <p className="font-semibold text-keroluxe-black dark:text-keroluxe-white">₦{(item.price * item.quantity).toFixed(2)}</p>
                </div>
              ))}
              <Separator className="my-4 bg-keroluxe-grey/30 dark:bg-neutral-600"/>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-keroluxe-grey dark:text-neutral-300">
                  <span>Subtotal:</span>
                  <span>₦{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-keroluxe-grey dark:text-neutral-300">
                  <span>Shipping:</span>
                  <span>{shippingCost === 0 ? 'Free' : `₦${shippingCost.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between text-lg font-bold text-keroluxe-black dark:text-keroluxe-white">
                  <span>Total:</span>
                  <span>₦{total.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {placeOrderError && (
            <div className="bg-red-100 dark:bg-red-900/30 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-300 px-4 py-3 rounded-md relative" role="alert">
              <strong className="font-bold mr-1">Order Placement Failed:</strong>
              <span className="block sm:inline">{placeOrderError}</span>
            </div>
          )}
          
          <Button 
            onClick={onPlaceOrder} 
            disabled={isPlacingOrder} 
            size="lg" 
            className="w-full btn-primary text-lg py-3"
          >
            {isPlacingOrder ? (
              <>
                <AlertCircle className="mr-2 h-5 w-5 animate-spin" /> Placing Order...
              </>
            ) : (
              <>
                <CheckCircle2 className="mr-2 h-5 w-5" /> Place Order
              </>
            )}
          </Button>
        </div>
      );
    };

    export default ReviewOrderStep;