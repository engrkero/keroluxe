import React, { useState, useEffect, useCallback } from 'react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Link } from 'react-router-dom';
    import { ChevronLeft, ChevronRight } from 'lucide-react';
    import { heroSlides } from '@/data/products';
    import { cn } from '@/lib/utils';

    const HeroCarousel = () => {
      const [currentIndex, setCurrentIndex] = useState(0);

      const nextSlide = useCallback(() => {
        setCurrentIndex((prevIndex) => (prevIndex === heroSlides.length - 1 ? 0 : prevIndex + 1));
      }, []);

      const prevSlide = () => {
        setCurrentIndex((prevIndex) => (prevIndex === 0 ? heroSlides.length - 1 : prevIndex - 1));
      };

      useEffect(() => {
        const timer = setTimeout(nextSlide, 7000); 
        return () => clearTimeout(timer);
      }, [currentIndex, nextSlide]);

      const currentSlideData = heroSlides[currentIndex];
      // Ensure imageUrlPlaceholder is always a non-empty string for Unsplash
      const placeholderQuery = currentSlideData.imageUrlPlaceholder || 'luxury fashion item';
      const slideImageSrc = currentSlideData.imageUrl || `https://source.unsplash.com/1600x900/?${encodeURIComponent(placeholderQuery)}`;

      return (
        <div className="relative w-full h-[65vh] md:h-[85vh] lg:h-screen overflow-hidden group bg-keroluxe-off-white dark:bg-neutral-900">
          <AnimatePresence initial={false} mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.8, ease: [0.43, 0.13, 0.23, 0.96] }}
              className="absolute inset-0"
            >
              <img  
                alt={currentSlideData.alt || currentSlideData.title} 
                src={slideImageSrc} 
                className="w-full h-full object-cover" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent dark:from-black/80 dark:via-black/50"></div>
            </motion.div>
          </AnimatePresence>

          <div className="absolute inset-0 flex flex-col items-center justify-end text-center p-6 pb-16 md:pb-24 z-10">
            <motion.h1
              key={`title-${currentIndex}`}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.6, ease: "easeOut" }}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold font-serif text-keroluxe-white mb-4 md:mb-6"
              style={{ textShadow: '2px 2px 6px rgba(0,0,0,0.7)' }}
            >
              {currentSlideData.title}
            </motion.h1>
            <motion.p
              key={`desc-${currentIndex}`}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.6, ease: "easeOut" }}
              className="text-base sm:text-lg md:text-xl text-keroluxe-off-white max-w-lg md:max-w-2xl mb-6 md:mb-10"
              style={{ textShadow: '1px 1px 4px rgba(0,0,0,0.6)' }}
            >
              {currentSlideData.description}
            </motion.p>
            <motion.div
              key={`button-${currentIndex}`}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.8, duration: 0.6, ease: "easeOut" }}
            >
              <Button asChild size="lg" className={cn(
                "bg-keroluxe-gold text-keroluxe-black hover:bg-keroluxe-white hover:text-keroluxe-black",
                "dark:bg-keroluxe-gold dark:text-keroluxe-black dark:hover:bg-keroluxe-white dark:hover:text-keroluxe-black",
                "px-10 py-3 text-lg md:text-xl font-semibold rounded-lg shadow-xl transition-all duration-300 transform hover:scale-105 hover:shadow-2xl focus:ring-4 focus:ring-keroluxe-gold/50"
              )}>
                <Link to={currentSlideData.link}>{currentSlideData.buttonText}</Link>
              </Button>
            </motion.div>
          </div>

          <Button
            variant="ghost"
            size="icon"
            onClick={prevSlide}
            className="absolute left-3 sm:left-5 top-1/2 -translate-y-1/2 z-20 text-keroluxe-white bg-black/40 hover:bg-keroluxe-gold hover:text-keroluxe-black rounded-full p-2 opacity-0 group-hover:opacity-100 transition-all duration-300 transform group-hover:scale-110"
            aria-label="Previous slide"
          >
            <ChevronLeft className="h-7 w-7 sm:h-8 sm:w-8" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={nextSlide}
            className="absolute right-3 sm:right-5 top-1/2 -translate-y-1/2 z-20 text-keroluxe-white bg-black/40 hover:bg-keroluxe-gold hover:text-keroluxe-black rounded-full p-2 opacity-0 group-hover:opacity-100 transition-all duration-300 transform group-hover:scale-110"
            aria-label="Next slide"
          >
            <ChevronRight className="h-7 w-7 sm:h-8 sm:w-8" />
          </Button>

          <div className="absolute bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 z-20 flex space-x-2.5">
            {heroSlides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={cn(
                  "h-3 w-3 sm:h-3.5 sm:w-3.5 rounded-full transition-all duration-300 ease-in-out",
                  currentIndex === index ? "bg-keroluxe-gold scale-125 shadow-md ring-2 ring-keroluxe-white/50" : "bg-keroluxe-white/60 hover:bg-keroluxe-white"
                )}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      );
    };

    export default HeroCarousel;